(function($){
    function initDigjyWidget($scope){
        $scope.find('.digjy-buy-now, .digjy-checkout-shell, .digjy-embedded-card-shell, .digjy-dashboard, .digjy-elementor-widget').each(function(){
            $(this).addClass('digjy-elementor-ready');
        });
    }

    $(window).on('elementor/frontend/init', function(){
        if (window.elementorFrontend && window.elementorFrontend.hooks) {
            elementorFrontend.hooks.addAction('frontend/element_ready/global', initDigjyWidget);
            elementorFrontend.hooks.addAction('frontend/element_ready/digjy-stores-widget.default', initDigjyWidget);
        }
    });
})(jQuery);
