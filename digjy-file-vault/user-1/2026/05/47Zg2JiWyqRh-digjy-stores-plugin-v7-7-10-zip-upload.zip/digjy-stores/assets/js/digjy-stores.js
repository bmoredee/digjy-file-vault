jQuery(function($){

  function digjyInitShadowHosts(){
    window.DigjyStoresShadowRoots = window.DigjyStoresShadowRoots || [];
    document.querySelectorAll('.digjy-shadow-host[data-digjy-shadow="1"]:not([data-digjy-shadow-ready="1"])').forEach(function(host){
      host.setAttribute('data-digjy-shadow-ready','1');
      if(!host.attachShadow){ return; }
      var tpl = host.querySelector('template');
      if(!tpl){ return; }
      var root = host.shadowRoot || host.attachShadow({mode:'open'});
      root.appendChild(tpl.content.cloneNode(true));
      window.DigjyStoresShadowRoots.push(root);
    });
  }
  digjyInitShadowHosts();
  window.DigjyStoresEventTarget = function($){
    digjyInitShadowHosts();
    return $([document].concat(window.DigjyStoresShadowRoots || []));
  };
  var $digjyEventTarget = window.DigjyStoresEventTarget($);

  const embeddedRoots = {};

  function escapeHtml(str){
    return $('<div>').text(str || '').html();
  }

  function statusMetaHtml(data){
    const prep = data && data.preparation ? data.preparation : {};
    let html = '';
    if(data && data.txId){ html += '<p><strong>Tx ID:</strong> ' + escapeHtml(data.txId) + '</p>'; }
    if(prep.currency){ html += '<p><strong>Currency:</strong> ' + escapeHtml(prep.currency) + '</p>'; }
    if(prep.payerAddress){ html += '<p><strong>Payer Wallet:</strong> ' + escapeHtml(prep.payerAddress) + '</p>'; }
    if(prep.amount){ html += '<p><strong>Amount:</strong> ' + escapeHtml(prep.amount) + '</p>'; }
    if(prep.serializedTransaction){ html += '<p><strong>Solana Transaction:</strong> <code class="digjy-code-block">' + escapeHtml(prep.serializedTransaction) + '</code></p>'; }
    if(prep.message){ html += '<p><strong>Verification Message:</strong> <code class="digjy-code-block">' + escapeHtml(prep.message) + '</code></p>'; }
    if(data.status === 'awaiting-payment' && prep.serializedTransaction){ html += '<p><button type="button" class="digjy-btn digjy-sign-solana">Sign & Submit in Phantom</button></p>'; }
    return html;
  }

  function renderStatus($container, payload){
    const $wrap = $container.find('.digjy-status-wrap').first();
    const data = payload && payload.status ? payload.status : {};
    $wrap.show();
    $wrap.find('.digjy-status-code').text(data.status || 'created');
    $wrap.find('.digjy-status-label').text(data.label || 'Status updated.');
    $wrap.find('.digjy-status-meta').html(statusMetaHtml(data));
    $container.data('internal-order-id', payload.internal_order_id || $container.data('internal-order-id'));
    $container.data('crossmint-order-id', payload.crossmint_order_id || $container.data('crossmint-order-id'));
    $container.data('client-secret', payload.client_secret || $container.data('client-secret'));
    $container.data('status-payload', payload);
    if(payload.download_url && (data.status === 'paid' || data.status === 'completed' || data.status === 'delivered' || data.status === 'succeeded')){
      $wrap.find('.digjy-status-actions').html('<a class="digjy-btn" href="' + escapeHtml(payload.download_url) + '">Download</a> <button type="button" class="digjy-btn digjy-refresh-status">Refresh Status</button>');
    }
  }

  function pollStatus($container){
    const internalOrderId = $container.data('internal-order-id');
    if(!internalOrderId){ return; }
    $.post(DigjyStores.ajaxUrl, {
      action: 'digjy_get_checkout_status',
      nonce: DigjyStores.nonce,
      internal_order_id: internalOrderId
    }).done(function(res){
      if(res.success){
        renderStatus($container, res.data);
      }
    });
  }

  function startPolling($container){
    const existing = $container.data('poller');
    if(existing){ window.clearInterval(existing); }
    const poller = window.setInterval(function(){ pollStatus($container); }, DigjyStores.pollInterval || 4000);
    $container.data('poller', poller);
  }

  async function connectPhantom($form){
    const provider = window.phantom && window.phantom.solana ? window.phantom.solana : window.solana;
    if(!provider || !provider.isPhantom){
      $form.find('.digjy-response').html('<div class="digjy-error">' + DigjyStores.i18n.phantomRequired + '</div>');
      return null;
    }
    const resp = await provider.connect();
    const address = resp.publicKey.toString();
    $form.find('[name="payer_address"]').val(address);
    $form.find('[name="digjy_wallet_provider"]').val('phantom');
    $form.find('[name="digjy_wallet_address"]').val(address);
    if($form.find('.digjy-wallet-status').length){ $form.find('.digjy-wallet-status').text('Connected Phantom: ' + address); }
    return provider;
  }


  async function connectMetamask($form){
    if(!window.ethereum || !window.ethereum.request){
      $form.find('.digjy-wallet-status').text('Metamask wallet was not found in this browser.');
      return null;
    }
    const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
    const address = accounts && accounts[0] ? accounts[0] : '';
    $form.find('[name="digjy_wallet_provider"]').val('metamask');
    $form.find('[name="digjy_wallet_address"]').val(address);
    $form.find('.digjy-wallet-status').text(address ? ('Connected Metamask: ' + address) : 'Unable to read Metamask address.');
    return address;
  }

  async function signAndSubmitSolana($container){
    const provider = await connectPhantom($container.closest('.digjy-checkout-shell').find('.digjy-checkout-form'));
    if(!provider){ return; }
    const payload = $container.data('status-payload') || {};
    const status = payload.status || {};
    const prep = status.preparation || {};
    const serialized = prep.serializedTransaction;
    if(!serialized){ return; }

    $container.find('.digjy-response').text(DigjyStores.i18n.signingTransaction);
    try {
      const web3 = await import('https://esm.sh/@solana/web3.js?bundle');
      const conn = new web3.Connection(DigjyStores.solanaRpcUrl || 'https://api.mainnet-beta.solana.com', 'confirmed');
      const bytes = Uint8Array.from(atob(serialized), c => c.charCodeAt(0));
      let transaction;
      try {
        transaction = web3.VersionedTransaction.deserialize(bytes);
      } catch (e) {
        transaction = web3.Transaction.from(bytes);
      }
      const signed = await provider.signTransaction(transaction);
      $container.find('.digjy-response').text(DigjyStores.i18n.submittingTransaction);
      const raw = signed.serialize();
      const txid = await conn.sendRawTransaction(raw, {skipPreflight:false, maxRetries:3});
      await conn.confirmTransaction(txid, 'confirmed');
      $.post(DigjyStores.ajaxUrl, {
        action: 'digjy_record_wallet_tx',
        nonce: DigjyStores.nonce,
        internal_order_id: $container.data('internal-order-id'),
        tx_id: txid
      });
      $container.find('.digjy-response').html('<div class="digjy-success">Solana transaction submitted: ' + escapeHtml(txid) + '</div>');
      setTimeout(function(){ pollStatus($container); }, 1500);
    } catch (err) {
      $container.find('.digjy-response').html('<div class="digjy-error">' + escapeHtml(err && err.message ? err.message : 'Transaction failed.') + '</div>');
    }
  }

  async function mountEmbeddedCard($shell, orderId, clientSecret){
    const mountEl = $shell.find('.digjy-embedded-mount').get(0);
    if(!mountEl){ return; }
    if(!DigjyStores.crossmintClientApiKey){
      $shell.find('.digjy-response').html('<div class="digjy-error">Crossmint client API key is missing.</div>');
      return;
    }
    try {
      const React = await import('https://esm.sh/react@18?bundle');
      const ReactDOM = await import('https://esm.sh/react-dom@18/client?bundle');
      const CrossmintUI = await import('https://esm.sh/@crossmint/client-sdk-react-ui?bundle');
      const rootKey = 'r' + orderId;
      if(embeddedRoots[rootKey]){
        embeddedRoots[rootKey].unmount();
      }
      const root = ReactDOM.createRoot(mountEl);
      embeddedRoots[rootKey] = root;
      root.render(
        React.createElement(
          CrossmintUI.CrossmintProvider,
          { apiKey: DigjyStores.crossmintClientApiKey },
          React.createElement(CrossmintUI.CrossmintEmbeddedCheckout, {
            orderId: orderId,
            clientSecret: clientSecret,
            payment: {
              fiat: { enabled: true },
              crypto: { enabled: false }
            }
          })
        )
      );
    } catch (err) {
      $shell.find('.digjy-response').html('<div class="digjy-error">' + DigjyStores.i18n.embeddedInitFailed + ' ' + escapeHtml(err && err.message ? err.message : '') + '</div>');
    }
  }


  $digjyEventTarget.on('click', '.digjy-toggle-message-form', function(){
    const target = $(this).data('target');
    const $form = $(this).closest('.digjy-stores-container').find('#' + target);
    $form.slideToggle(150);
  });

  $digjyEventTarget.on('change', '.digjy-checkout-form input[name="payment_method"]', function(){
    const $form = $(this).closest('.digjy-checkout-form');
    const method = $(this).val();
    $form.find('.digjy-pay-option').removeClass('active');
    $(this).closest('.digjy-pay-option').addClass('active');
    $form.find('.digjy-payment-panel').hide();
    $form.find('.digjy-payment-panel[data-method="' + method + '"]').show();
  });

  $digjyEventTarget.on('click', '.digjy-connect-phantom', async function(){
    const $form = $(this).closest('.digjy-checkout-form');
    try { await connectPhantom($form); } catch (err) {
      $form.find('.digjy-response').html('<div class="digjy-error">' + escapeHtml(err && err.message ? err.message : DigjyStores.i18n.phantomRequired) + '</div>');
    }
  });

  $digjyEventTarget.on('submit', '.digjy-checkout-form', function(e){
    e.preventDefault();
    const $form = $(this);
    const $shell = $form.closest('.digjy-checkout-shell');
    const $resp = $form.find('.digjy-response');
    const method = $form.find('[name="payment_method"]:checked').val() || 'card';
    const payerAddress = $form.find('[name="payer_address"]').val();

    if(method === 'solana' && !payerAddress){
      $resp.html('<div class="digjy-error">' + DigjyStores.i18n.walletRequired + '</div>');
      return;
    }

    $resp.text(DigjyStores.i18n.creatingCheckout);
    $.post(DigjyStores.ajaxUrl, {
      action: 'digjy_create_checkout',
      nonce: DigjyStores.nonce,
      product_id: $form.data('product-id'),
      buyer_email: $form.find('[name="buyer_email"]').val(),
      payer_address: payerAddress,
      recipient_wallet: $form.find('[name="recipient_wallet"]').val(),
      payment_method: method
    }).done(function(res){
      if(res.success){
        const d = res.data || {};
        const intro = method === 'card' ? DigjyStores.i18n.cardReady : DigjyStores.i18n.connectWallet;
        $resp.html('<div class="digjy-success">' + intro + '<br>Crossmint Order ID: ' + escapeHtml(d.crossmint_order_id || '') + '</div>');
        renderStatus($shell, d);
        startPolling($shell);
      } else {
        $resp.html('<div class="digjy-error">'+ (res.data && res.data.message ? escapeHtml(res.data.message) : DigjyStores.i18n.checkoutFailed) +'</div>');
      }
    }).fail(function(xhr){
      const msg = xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message ? xhr.responseJSON.data.message : DigjyStores.i18n.checkoutFailed;
      $resp.html('<div class="digjy-error">'+ escapeHtml(msg) +'</div>');
    });
  });

  $digjyEventTarget.on('submit', '.digjy-embedded-card-form', function(e){
    e.preventDefault();
    const $form = $(this);
    const $shell = $form.closest('.digjy-embedded-card-shell');
    const $resp = $form.find('.digjy-response');
    $resp.text(DigjyStores.i18n.creatingCheckout);
    $.post(DigjyStores.ajaxUrl, {
      action: 'digjy_create_checkout',
      nonce: DigjyStores.nonce,
      product_id: $form.data('product-id'),
      buyer_email: $form.find('[name="buyer_email"]').val(),
      recipient_wallet: $form.find('[name="recipient_wallet"]').val(),
      payment_method: 'card'
    }).done(async function(res){
      if(res.success){
        const d = res.data || {};
        $resp.html('<div class="digjy-success">Embedded card checkout ready.</div>');
        renderStatus($shell, d);
        startPolling($shell);
        await mountEmbeddedCard($shell, d.crossmint_order_id, d.client_secret);
      } else {
        $resp.html('<div class="digjy-error">'+ (res.data && res.data.message ? escapeHtml(res.data.message) : DigjyStores.i18n.checkoutFailed) +'</div>');
      }
    }).fail(function(xhr){
      const msg = xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message ? xhr.responseJSON.data.message : DigjyStores.i18n.checkoutFailed;
      $resp.html('<div class="digjy-error">'+ escapeHtml(msg) +'</div>');
    });
  });

  $digjyEventTarget.on('click', '.digjy-buy-now', function(){
    const productId = $(this).data('product-id');
    const target = $('.digjy-checkout-form[data-product-id="'+ productId +'"]');
    if(target.length){ $('html, body').animate({scrollTop: target.offset().top - 80}, 300); }
  });

  $digjyEventTarget.on('click', '.digjy-refresh-status', function(){
    const $container = $(this).closest('.digjy-checkout-shell, .digjy-embedded-card-shell, .digjy-order-history-card');
    $container.find('.digjy-response').text(DigjyStores.i18n.checkingStatus);
    pollStatus($container);
  });

  $digjyEventTarget.on('click', '.digjy-sign-solana', function(){
    const $container = $(this).closest('.digjy-checkout-shell, .digjy-order-history-card');
    signAndSubmitSolana($container);
  });

  $('.digjy-order-history-card').each(function(){
    startPolling($(this));
  });


  function renderDmMessages($shell, items){
    const $thread = $shell.find('.digjy-dm-thread');
    if(!$thread.length){ return; }
    if(!items || !items.length){ $thread.html('<p>No messages yet.</p>'); return; }
    let html='';
    items.forEach(function(item){
      const mine = parseInt(item.sender_id,10) === parseInt(DigjyStores.currentUserId || 0,10);
      html += '<div class="digjy-dm-bubble ' + (mine ? 'mine' : 'theirs') + '"><div class="digjy-dm-text">' + escapeHtml(item.content || '') + '</div><div class="digjy-dm-time">' + escapeHtml(item.created_at || '') + '</div></div>';
    });
    $thread.html(html);
    $thread.scrollTop($thread.prop('scrollHeight'));
  }
  function loadDm($shell, otherId){
    if(!otherId){ return; }
    $shell.find('.digjy-dm-form [name="recipient_id"]').val(otherId);
    $.post(DigjyStores.ajaxUrl, {action:'digjy_dm_fetch', nonce:DigjyStores.nonce, user_id:otherId}).done(function(res){ if(res.success){ renderDmMessages($shell, res.data.messages || []); } });
  }
  $digjyEventTarget.on('click','.digjy-dm-conversation', function(){ const $btn=$(this), $shell=$btn.closest('.digjy-dm-shell'); $shell.find('.digjy-dm-conversation').removeClass('active'); $btn.addClass('active'); loadDm($shell, $btn.data('user-id')); });
  $digjyEventTarget.on('submit','.digjy-dm-form', function(e){ e.preventDefault(); const $form=$(this), $shell=$form.closest('.digjy-dm-shell'); $.post(DigjyStores.ajaxUrl,{action:'digjy_dm_send',nonce:DigjyStores.nonce,recipient_id:$form.find('[name="recipient_id"]').val(),message:$form.find('[name="message"]').val()}).done(function(res){ if(res.success){ $form.find('[name="message"]').val(''); renderDmMessages($shell, res.data.messages || []); } }); });
  $('.digjy-dm-shell').each(function(){ const $shell=$(this); const active=$shell.data('active-user'); if(active){ loadDm($shell, active); } const poller=setInterval(function(){ const id=$shell.find('.digjy-dm-form [name="recipient_id"]').val(); if(id){ loadDm($shell, id); } }, 4000); $shell.data('dmPoller', poller); });


  $digjyEventTarget.on('click', '.digjy-wallet-connect', async function(){
    const $btn = $(this);
    const $form = $btn.closest('form');
    const wallet = $btn.data('wallet');
    try {
      if(wallet === 'phantom'){
        await connectPhantom($form);
      } else if(wallet === 'metamask'){
        await connectMetamask($form);
      }
    } catch (err) {
      $form.find('.digjy-wallet-status').text(err && err.message ? err.message : 'Wallet connection failed.');
    }
  });


  function mediaMarkupFromUpload(data){
    const url = data && data.url ? data.url : '';
    const mime = (data && data.mime ? data.mime : '').toLowerCase();
    const safeUrl = escapeHtml(url);
    if(!url){ return ''; }
    if(mime.indexOf('image/') === 0){
      return '<p><img src="' + safeUrl + '" alt="" /></p>';
    }
    if(mime.indexOf('video/') === 0){
      return '<p><video controls src="' + safeUrl + '"></video></p>';
    }
    if(mime.indexOf('audio/') === 0){
      return '<p><audio controls src="' + safeUrl + '"></audio></p>';
    }
    return '<p><a href="' + safeUrl + '" target="_blank" rel="noopener">' + escapeHtml((data && data.name) ? data.name : 'Download media') + '</a></p>';
  }

  $digjyEventTarget.on('click', '.digjy-add-media-btn', function(e){
    e.preventDefault();
    const $wrap = $(this).closest('.digjy-description-field');
    $wrap.find('.digjy-description-media-input').trigger('click');
  });

  $digjyEventTarget.on('change', '.digjy-description-media-input', function(){
    const input = this;
    const file = input.files && input.files[0] ? input.files[0] : null;
    const $wrap = $(input).closest('.digjy-description-field');
    const $status = $wrap.find('.digjy-description-media-status');
    const $textarea = $wrap.find('textarea');
    if(!file){ return; }
    const formData = new window.FormData();
    formData.append('action', 'digjy_upload_description_media');
    formData.append('nonce', DigjyStores.nonce);
    formData.append('media', file);
    $status.text('Uploading media...');
    $.ajax({
      url: DigjyStores.ajaxUrl,
      method: 'POST',
      data: formData,
      processData: false,
      contentType: false
    }).done(function(res){
      if(res.success && res.data){
        const current = $textarea.val() || '';
        const addition = mediaMarkupFromUpload(res.data);
        $textarea.val(current + (current ? "\n\n" : '') + addition);
        $status.text('Media uploaded and inserted.');
      } else {
        $status.text(res.data && res.data.message ? res.data.message : 'Media upload failed.');
      }
    }).fail(function(xhr){
      const msg = xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message ? xhr.responseJSON.data.message : 'Media upload failed.';
      $status.text(msg);
    }).always(function(){
      input.value = '';
    });
  });

  $digjyEventTarget.on('click', '.digjy-generate-store-seo', function(){
    const $btn = $(this);
    const $form = $btn.closest('.digjy-store-edit-form');
    const $seo = $form.find('.digjy-store-seo-field');
    const $name = $form.find('[name="digjy_store_name"]');
    const $desc = $form.find('[name="digjy_store_description"]');
    const original = $btn.text();
    $btn.prop('disabled', true).text('Generating...');
    $.post(DigjyStores.ajaxUrl, {
      action: 'digjy_generate_store_seo',
      nonce: DigjyStores.nonce,
      store_name: $name.val(),
      store_description: $desc.val()
    }).done(function(res){
      if(res.success && res.data && res.data.seo){
        $seo.val(res.data.seo);
      } else {
        alert(res.data && res.data.message ? res.data.message : 'SEO generation failed.');
      }
    }).fail(function(xhr){
      const msg = xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message ? xhr.responseJSON.data.message : 'SEO generation failed.';
      alert(msg);
    }).always(function(){
      $btn.prop('disabled', false).text(original);
    });
  });

});


(function($){
  var $digjyEventTarget = window.DigjyStoresEventTarget ? window.DigjyStoresEventTarget($) : $(document);
  function getStore(key){ try { return JSON.parse(localStorage.getItem(key) || '[]'); } catch(e){ return []; } }
  function setStore(key,val){ localStorage.setItem(key, JSON.stringify(val)); }
  function normalizeItem(raw){
    if (!raw) return null;
    return { id: parseInt(raw.id || raw.product_id || 0,10), title: raw.title || 'Digital Product', url: raw.url || '#', image: raw.image || '', price: parseFloat(raw.price || 0), excerpt: raw.excerpt || '', saved_at: raw.saved_at || Date.now() };
  }
  function addItem(key,item){ item=normalizeItem(item); if(!item || !item.id) return; var arr=getStore(key).filter(function(x){return parseInt(x.id,10)!==item.id;}); arr.unshift(item); setStore(key, arr.slice(0,100)); }
  function escapeHtml(v){ return $('<div>').text(v == null ? '' : String(v)).html(); }
  function buildShareUrl(items){
    try {
      var compact = items.slice(0,25).map(function(i){ return {id:i.id,title:i.title,url:i.url,image:i.image,price:i.price,excerpt:i.excerpt}; });
      return window.location.origin + window.location.pathname + '#digjy-list=' + encodeURIComponent(btoa(unescape(encodeURIComponent(JSON.stringify(compact)))));
    } catch(e){ return window.location.href; }
  }
  function loadSharedListFromHash(){
    var hash = window.location.hash || '';
    if(hash.indexOf('#digjy-list=') !== 0) return;
    try {
      var encoded = decodeURIComponent(hash.replace('#digjy-list=',''));
      var items = JSON.parse(decodeURIComponent(escape(atob(encoded))));
      if(Array.isArray(items) && items.length){ setStore('digjy_dig_list', items.map(normalizeItem).filter(Boolean)); }
    } catch(e){}
  }
  window.DigjyStoresSavedProducts = { addItem:addItem, getStore:getStore, setStore:setStore };
  function cardHtml(item,type,checkoutUrl){
    var img = item.image ? '<img src="'+escapeHtml(item.image)+'" alt="" class="digjy-saved-product-img" />' : '<div class="digjy-saved-product-placeholder">DIGJY</div>';
    var price = '$' + (parseFloat(item.price||0).toFixed(2));
    var checkout = checkoutUrl ? checkoutUrl + (checkoutUrl.indexOf('?')>=0 ? '&' : '?') + 'product_id=' + encodeURIComponent(item.id) : item.url;
    var actions = '<a class="digjy-btn" href="'+escapeHtml(item.url)+'">View</a> ';
    if(type === 'dig_list') actions += '<button type="button" class="digjy-btn digjy-add-to-cart" data-product-id="'+item.id+'">Add To Cart</button> ';
    if(type === 'cart') actions += '<a class="digjy-btn" href="'+escapeHtml(checkout)+'">Checkout</a> ';
    actions += '<button type="button" class="digjy-btn digjy-remove-saved" data-list-type="'+type+'" data-product-id="'+item.id+'">Remove</button>';
    return '<div class="digjy-card digjy-saved-product-card" data-title="'+escapeHtml(item.title)+'" data-price="'+parseFloat(item.price||0)+'">'+img+'<h4>'+ escapeHtml(item.title) +'</h4><p><strong>'+price+'</strong></p><p>'+ escapeHtml(item.excerpt||'') +'</p><div class="digjy-product-card-actions">'+actions+'</div></div>';
  }
  function filteredItems($wrap, items){
    var q = String($wrap.find('.digjy-dig-list-search').val() || '').toLowerCase();
    var sort = $wrap.find('.digjy-dig-list-sort').val() || 'recent';
    var out = items.filter(function(item){ return !q || String(item.title + ' ' + (item.excerpt||'')).toLowerCase().indexOf(q) >= 0; });
    out.sort(function(a,b){
      if(sort === 'price_low') return parseFloat(a.price||0)-parseFloat(b.price||0);
      if(sort === 'price_high') return parseFloat(b.price||0)-parseFloat(a.price||0);
      if(sort === 'az') return String(a.title||'').localeCompare(String(b.title||''));
      return parseInt(b.saved_at||0,10)-parseInt(a.saved_at||0,10);
    });
    return out;
  }
  function renderSaved($wrap){
    var type=$wrap.data('digjy-list-type');
    var grid=$wrap.find('.digjy-saved-products-grid');
    var empty=$wrap.find('.digjy-saved-products-empty');
    var items=getStore('digjy_'+type);
    $wrap.find('.digjy-dig-list-count').text(items.length + (items.length === 1 ? ' item' : ' items'));
    var visible = filteredItems($wrap, items);
    if(!visible.length){ grid.empty(); empty.show(); return; }
    empty.hide();
    var checkout=$wrap.data('checkout-url') || '';
    grid.html(visible.map(function(item){ return cardHtml(item,type,checkout); }).join(''));
  }
  $(function(){
    function digjyFindAll(selector){ var $found = $(selector); (window.DigjyStoresShadowRoots || []).forEach(function(root){ $found = $found.add($(root).find(selector)); }); return $found; }
    loadSharedListFromHash();
    digjyFindAll('.digjy-saved-products-ui').each(function(){ renderSaved($(this)); });
    $digjyEventTarget.on('input change','.digjy-dig-list-search,.digjy-dig-list-sort',function(){ renderSaved($(this).closest('.digjy-saved-products-ui')); });
    $digjyEventTarget.on('click','.digjy-remove-saved',function(){ var type=$(this).data('list-type'), id=parseInt($(this).data('product-id'),10); var key='digjy_'+type; setStore(key, getStore(key).filter(function(x){ return parseInt(x.id,10)!==id; })); digjyFindAll('.digjy-saved-products-ui[data-digjy-list-type="'+type+'"]').each(function(){ renderSaved($(this)); }); });
    $digjyEventTarget.on('click','.digjy-clear-list',function(){ var $wrap=$(this).closest('.digjy-saved-products-ui'); var type=$wrap.data('digjy-list-type'); if(confirm('Clear this list?')){ setStore('digjy_'+type, []); renderSaved($wrap); } });
    $digjyEventTarget.on('click','.digjy-share-list',function(){ var $wrap=$(this).closest('.digjy-saved-products-ui'); var type=$wrap.data('digjy-list-type'); var url=buildShareUrl(getStore('digjy_'+type)); $wrap.find('.digjy-share-url').val(url); $wrap.find('.digjy-dig-list-share-panel').show(); });
    $digjyEventTarget.on('click','.digjy-copy-share-url',function(){ var input=$(this).siblings('.digjy-share-url')[0]; if(input){ input.select(); document.execCommand('copy'); alert('List link copied.'); } });
    $digjyEventTarget.on('click','.digjy-move-all-to-cart',function(){ var items=getStore('digjy_dig_list'); items.forEach(function(item){ addItem('digjy_cart', item); }); alert('Saved products added to cart.'); });
    $digjyEventTarget.on('click','.digjy-add-to-cart',function(){ var id=parseInt($(this).data('product-id'),10); var item=null; getStore('digjy_dig_list').concat(getStore('digjy_recently_viewed')).some(function(x){ if(parseInt(x.id,10)===id){ item=x; return true; } return false; }); if(item){ addItem('digjy_cart',item); alert('Added to cart.'); } });
    $digjyEventTarget.on('click','.digjy-save-dig-list,.digjy-save-cart',function(){ var raw=$(this).attr('data-product'); if(!raw) return; try{ var item=JSON.parse(raw); addItem($(this).hasClass('digjy-save-cart') ? 'digjy_cart' : 'digjy_dig_list', item); alert($(this).hasClass('digjy-save-cart') ? 'Added to cart.' : 'Added to My Dig List.'); }catch(e){} });
    digjyFindAll('.digjy-product-context').each(function(){ var raw=$(this).attr('data-product'); if(raw){ try{ addItem('digjy_recently_viewed', JSON.parse(raw)); }catch(e){} } });
  });
})(jQuery);
