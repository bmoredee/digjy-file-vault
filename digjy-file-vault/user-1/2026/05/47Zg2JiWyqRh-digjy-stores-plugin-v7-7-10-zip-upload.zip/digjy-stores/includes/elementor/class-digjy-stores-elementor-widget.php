<?php
if (!defined('ABSPATH')) {
    exit;
}

class Digjy_Stores_Elementor_Widget extends \Elementor\Widget_Base {
    public function get_name() {
        return 'digjy-stores-widget';
    }

    public function get_title() {
        return __('Digjy Stores', 'digjy-stores');
    }

    public function get_icon() {
        return 'eicon-products';
    }

    public function get_categories() {
        return ['digjy-stores'];
    }

    public function get_keywords() {
        return ['digjy', 'stores', 'marketplace', 'checkout', 'crossmint', 'solana'];
    }

    public function get_style_depends() {
        return ['digjy-stores'];
    }

    public function get_script_depends() {
        return ['digjy-stores', 'digjy-stores-elementor'];
    }

    protected function register_controls() {
        $this->start_controls_section(
            'section_content',
            [
                'label' => __('Content', 'digjy-stores'),
            ]
        );

        $this->add_control(
            'widget_type',
            [
                'label' => __('Widget Type', 'digjy-stores'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'buy_now',
                'options' => [
                    'buy_now' => __('Buy Now Button', 'digjy-stores'),
                    'digital_checkout' => __('Digital Checkout', 'digjy-stores'),
                    'embedded_card' => __('Embedded Card Checkout', 'digjy-stores'),
                    'product_price' => __('Product Price', 'digjy-stores'),
                    'nft_info' => __('NFT Information', 'digjy-stores'),
                    'nft_lazy_data' => __('NFT Lazy-Mint Data', 'digjy-stores'),
                    'nft_minted_data' => __('NFT Minted Data', 'digjy-stores'),
                    'seller_register' => __('Seller Register', 'digjy-stores'),
                    'customer_register' => __('Customer Register', 'digjy-stores'),
                    'customer_login' => __('Customer Login', 'digjy-stores'),
                    'store_login' => __('Store Login', 'digjy-stores'),
                    'my_account' => __('My Account Dashboard', 'digjy-stores'),
                    'vendor_dashboard' => __('Vendor Dashboard', 'digjy-stores'),
                    'store_list' => __('Store List', 'digjy-stores'),
                    'customer_downloads' => __('Customer Downloads', 'digjy-stores'),
                    'order_history' => __('Order History', 'digjy-stores'),
                    'contact_store_owner' => __('Contact Store Owner Button', 'digjy-stores'),
                    'follow_button' => __('Follow / Unfollow Button', 'digjy-stores'),
                    'wallet' => __('Wallet System', 'digjy-stores'),
                    'messages' => __('Marketplace Messages', 'digjy-stores'),
                    'review_section' => __('Review Section', 'digjy-stores'),
                    'edit_store_form' => __('Edit Store Form', 'digjy-stores'),
                ],
            ]
        );

        $this->add_control(
            'product_id',
            [
                'label' => __('Product ID', 'digjy-stores'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 0,
                'min' => 0,
            ]
        );

        $this->add_control(
            'button_label',
            [
                'label' => __('Button Label', 'digjy-stores'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Buy Now', 'digjy-stores'),
                'condition' => [
                    'widget_type' => 'buy_now',
                ],
            ]
        );

        $this->add_control(
            'currency_symbol',
            [
                'label' => __('Currency Symbol', 'digjy-stores'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => '$',
                'condition' => [
                    'widget_type' => 'product_price',
                ],
            ]
        );

        $this->add_control(
            'nft_type',
            [
                'label' => __('NFT Data Type', 'digjy-stores'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'all',
                'options' => [
                    'all' => __('All', 'digjy-stores'),
                    'lazy' => __('Lazy Minted', 'digjy-stores'),
                    'minted' => __('Minted', 'digjy-stores'),
                ],
                'condition' => [
                    'widget_type' => 'nft_info',
                ],
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        if (!class_exists('Elementor\Plugin')) {
            return;
        }
        $settings = $this->get_settings_for_display();
        $widget_type = $settings['widget_type'] ?? 'buy_now';
        $product_id = absint($settings['product_id'] ?? 0);
        $button_label = sanitize_text_field($settings['button_label'] ?? __('Buy Now', 'digjy-stores'));
        $currency_symbol = sanitize_text_field($settings['currency_symbol'] ?? '$');
        $nft_type = sanitize_text_field($settings['nft_type'] ?? 'all');

        $shortcode = '';
        switch ($widget_type) {
            case 'buy_now':
                $shortcode = sprintf('[digjy_buy_now product_id="%d" label="%s"]', $product_id, esc_attr($button_label));
                break;
            case 'digital_checkout':
                $shortcode = sprintf('[digjy_digital_checkout product_id="%d"]', $product_id);
                break;
            case 'embedded_card':
                $shortcode = sprintf('[digjy_crossmint_embedded_card product_id="%d"]', $product_id);
                break;
            case 'product_price':
                $shortcode = sprintf('[digjy_product_price product_id="%d" currency_symbol="%s"]', $product_id, esc_attr($currency_symbol));
                break;
            case 'nft_info':
                $shortcode = sprintf('[digjy_nft_info product_id="%d" type="%s"]', $product_id, esc_attr($nft_type));
                break;
            case 'nft_lazy_data':
                $shortcode = sprintf('[digjy_nft_lazy_data product_id="%d"]', $product_id);
                break;
            case 'nft_minted_data':
                $shortcode = sprintf('[digjy_nft_minted_data product_id="%d"]', $product_id);
                break;
            case 'seller_register':
                $shortcode = '[digjy_seller_register]';
                break;
            case 'customer_register':
                $shortcode = '[digjy_customer_register]';
                break;
            case 'customer_login':
                $shortcode = '[digjy_customer_login]';
                break;
            case 'store_login':
                $shortcode = '[digjy_store_login]';
                break;
            case 'my_account':
                $shortcode = '[digjy_my_account]';
                break;
            case 'vendor_dashboard':
                $shortcode = '[digjy_vendor_dashboard]';
                break;
            case 'store_list':
                $shortcode = '[digjy_store_list]';
                break;
            case 'customer_downloads':
                $shortcode = '[digjy_customer_downloads]';
                break;
            case 'order_history':
                $shortcode = '[digjy_order_history]';
                break;
            case 'contact_store_owner':
                $shortcode = sprintf('[digjy_contact_store_owner_button product_id="%d"]', $product_id);
                break;
            case 'follow_button':
                $shortcode = sprintf('[digjy_follow_button product_id="%d"]', $product_id);
                break;
            case 'wallet':
                $shortcode = '[digjy_wallet]';
                break;
            case 'messages':
                $shortcode = '[digjy_messages]';
                break;
            case 'review_section':
                $shortcode = sprintf('[digjy_review_section product_id="%d"]', $product_id);
                break;
            case 'edit_store_form':
                $shortcode = '[digjy_edit_store_form]';
                break;
        }

        $output = do_shortcode($shortcode);
        if ($output === '') {
            return;
        }

        echo '<div class="digjy-elementor-widget digjy-stores-container" data-widget-type="' . esc_attr($widget_type) . '">' . $output . '</div>';
    }

    protected function content_template() {}
}
