<?php
if (!defined('ABSPATH')) {
    exit;
}

class Digjy_Stores_Vendors {
    public function __construct() {
        add_action('init', [__CLASS__, 'register_post_types']);
        add_filter('post_type_link', [$this, 'filter_store_permalink'], 10, 2);
        add_action('init', [$this, 'handle_registration']);
        add_action('init', [$this, 'handle_customer_registration']);
        add_action('init', [$this, 'handle_customer_login']);
        add_action('init', [$this, 'handle_store_login']);
        add_action('init', [$this, 'handle_customer_account_update']);
        add_action('show_user_profile', [$this, 'render_vendor_profile_fields']);
        add_action('edit_user_profile', [$this, 'render_vendor_profile_fields']);
        add_action('personal_options_update', [$this, 'save_vendor_profile_fields']);
        add_action('edit_user_profile_update', [$this, 'save_vendor_profile_fields']);
    }

    public static function register_post_types() {
        register_post_type('digjy_store', [
            'labels' => ['name' => __('Stores', 'digjy-stores'), 'singular_name' => __('Store', 'digjy-stores')],
            'public' => true,
            'show_in_menu' => true,
            'supports' => ['title', 'editor', 'thumbnail', 'author', 'excerpt'],
            'rewrite' => ['slug' => 'store', 'with_front' => false],
            'has_archive' => true,
            'show_in_rest' => true,
        ]);
    }


    public function filter_store_permalink($permalink, $post) {
        if (!$post || 'digjy_store' !== $post->post_type) {
            return $permalink;
        }
        return home_url(user_trailingslashit('store/' . $post->post_name));
    }

    public function handle_registration() {
        if (empty($_POST['digjy_seller_register_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['digjy_seller_register_nonce'])), 'digjy_seller_register')) {
            return;
        }

        $email = sanitize_email($_POST['email'] ?? '');
        $username = sanitize_user($_POST['username'] ?? '');
        $password = (string) ($_POST['password'] ?? '');
        $store_name = sanitize_text_field($_POST['store_name'] ?? '');
        $wallet = sanitize_text_field($_POST['seller_wallet'] ?? '');

        if (!$email || !$username || !$password || !$store_name) {
            digjy_stores_safe_redirect(add_query_arg('digjy_error', 'missing_fields', wp_get_referer() ?: home_url('/')));
        }
        if (username_exists($username) || email_exists($email)) {
            digjy_stores_safe_redirect(add_query_arg('digjy_error', 'duplicate_user', wp_get_referer() ?: home_url('/')));
        }

        $user_id = wp_create_user($username, $password, $email);
        if (is_wp_error($user_id)) {
            digjy_stores_safe_redirect(add_query_arg('digjy_error', 'create_failed', wp_get_referer() ?: home_url('/')));
        }

        $user = new WP_User($user_id);
        $user->set_role('digjy_store_owner');
        $user->add_role('digjy_seller');

        if (!empty($wallet)) {
            update_user_meta($user_id, 'digjy_seller_wallet', $wallet);
        } else {
            $wallet_result = $this->maybe_create_crossmint_wallet($user_id, $email);
            if (is_array($wallet_result)) {
                if (!empty($wallet_result['address'])) {
                    update_user_meta($user_id, 'digjy_seller_wallet', sanitize_text_field($wallet_result['address']));
                }
                if (!empty($wallet_result['locator'])) {
                    update_user_meta($user_id, 'digjy_seller_wallet_locator', sanitize_text_field($wallet_result['locator']));
                }
            } elseif (is_wp_error($wallet_result)) {
                update_user_meta($user_id, 'digjy_wallet_provisioning_error', $wallet_result->get_error_message());
            }
        }

        $store_id = wp_insert_post([
            'post_type' => 'digjy_store',
            'post_status' => 'publish',
            'post_title' => $store_name,
            'post_author' => $user_id,
            'post_content' => __('Welcome to my store.', 'digjy-stores'),
        ]);
        if ($store_id) {
            update_user_meta($user_id, 'digjy_store_id', $store_id);
        }

        wp_set_current_user($user_id);
        wp_set_auth_cookie($user_id);
        digjy_stores_safe_redirect(add_query_arg('digjy_registered', '1', wp_get_referer() ?: home_url('/')));
    }


    public function handle_customer_registration() {
        if (empty($_POST['digjy_customer_register_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['digjy_customer_register_nonce'])), 'digjy_customer_register')) {
            return;
        }

        $email = sanitize_email($_POST['email'] ?? '');
        $username = sanitize_user($_POST['username'] ?? '');
        $password = (string) ($_POST['password'] ?? '');
        $first_name = sanitize_text_field($_POST['first_name'] ?? '');
        $last_name = sanitize_text_field($_POST['last_name'] ?? '');

        if (!$email || !$username || !$password) {
            digjy_stores_safe_redirect(add_query_arg('digjy_error', 'missing_fields', wp_get_referer() ?: home_url('/')));
        }
        if (username_exists($username) || email_exists($email)) {
            digjy_stores_safe_redirect(add_query_arg('digjy_error', 'duplicate_user', wp_get_referer() ?: home_url('/')));
        }

        $user_id = wp_create_user($username, $password, $email);
        if (is_wp_error($user_id)) {
            digjy_stores_safe_redirect(add_query_arg('digjy_error', 'create_failed', wp_get_referer() ?: home_url('/')));
        }

        wp_update_user([
            'ID' => $user_id,
            'role' => 'digjy_customer',
            'first_name' => $first_name,
            'last_name' => $last_name,
            'display_name' => trim($first_name . ' ' . $last_name) ?: $username,
        ]);

        update_user_meta($user_id, 'digjy_customer_created', current_time('mysql'));

        wp_set_current_user($user_id);
        wp_set_auth_cookie($user_id);
        digjy_stores_safe_redirect(add_query_arg('digjy_registered', '1', wp_get_referer() ?: home_url('/')));
    }

    public function handle_store_login() {
        if (empty($_POST['digjy_store_login_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['digjy_store_login_nonce'])), 'digjy_store_login')) {
            return;
        }

        $creds = [
            'user_login' => sanitize_text_field($_POST['log'] ?? ''),
            'user_password' => (string) ($_POST['pwd'] ?? ''),
            'remember' => !empty($_POST['rememberme']),
        ];

        $user = wp_signon($creds, is_ssl());
        if (is_wp_error($user)) {
            digjy_stores_safe_redirect(add_query_arg('digjy_error', 'login_failed', wp_get_referer() ?: home_url('/')));
        }

        $roles = (array) $user->roles;
        if (!in_array('digjy_seller', $roles, true) && !in_array('digjy_store_owner', $roles, true) && !user_can($user, 'manage_options')) {
            wp_logout();
            digjy_stores_safe_redirect(add_query_arg('digjy_error', 'not_store_user', wp_get_referer() ?: home_url('/')));
        }

        $redirect = wp_get_referer() ?: home_url('/');
        if (!empty($_POST['digjy_store_redirect'])) {
            $dashboard_page = get_page_by_path('vendor-dashboard');
            if ($dashboard_page instanceof WP_Post) {
                $redirect = get_permalink($dashboard_page);
            }
        }

        digjy_stores_safe_redirect(add_query_arg('digjy_logged_in', '1', $redirect));
    }

    public function handle_customer_login() {
        if (empty($_POST['digjy_customer_login_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['digjy_customer_login_nonce'])), 'digjy_customer_login')) {
            return;
        }

        $creds = [
            'user_login' => sanitize_text_field($_POST['log'] ?? ''),
            'user_password' => (string) ($_POST['pwd'] ?? ''),
            'remember' => !empty($_POST['rememberme']),
        ];

        $user = wp_signon($creds, is_ssl());
        if (is_wp_error($user)) {
            digjy_stores_safe_redirect(add_query_arg('digjy_error', 'login_failed', wp_get_referer() ?: home_url('/')));
        }

        digjy_stores_safe_redirect(add_query_arg('digjy_logged_in', '1', wp_get_referer() ?: home_url('/')));
    }

    public function handle_customer_account_update() {
        if (empty($_POST['digjy_customer_account_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['digjy_customer_account_nonce'])), 'digjy_customer_account')) {
            return;
        }
        if (!is_user_logged_in()) {
            return;
        }

        $user_id = get_current_user_id();
        $userdata = [
            'ID' => $user_id,
            'first_name' => sanitize_text_field($_POST['account_first_name'] ?? ''),
            'last_name' => sanitize_text_field($_POST['account_last_name'] ?? ''),
            'user_email' => sanitize_email($_POST['account_email'] ?? ''),
        ];
        $display_name = trim(($userdata['first_name'] ?? '') . ' ' . ($userdata['last_name'] ?? ''));
        if ($display_name) {
            $userdata['display_name'] = $display_name;
        }
        if (!empty($_POST['account_password'])) {
            $userdata['user_pass'] = (string) $_POST['account_password'];
        }

        $result = wp_update_user($userdata);
        if (is_wp_error($result)) {
            digjy_stores_safe_redirect(add_query_arg('digjy_error', 'account_update_failed', wp_get_referer() ?: home_url('/')));
        }

        digjy_stores_safe_redirect(add_query_arg('digjy_account_updated', '1', wp_get_referer() ?: home_url('/')));
    }

    private function maybe_create_crossmint_wallet($user_id, $email) {
        $settings = Digjy_Stores::get_settings();
        if (empty($settings['auto_create_wallets']) || empty($settings['crossmint_api_key']) || empty($email)) {
            return null;
        }

        $environment = ($settings['crossmint_environment'] ?? 'production') === 'staging' ? 'https://staging.crossmint.com/api/2025-06-09/wallets' : 'https://www.crossmint.com/api/2025-06-09/wallets';
        $chain_type = sanitize_text_field($settings['wallet_chain_type'] ?? 'solana');
        $body = [
            'chainType' => $chain_type,
            'type' => 'smart',
            'owner' => 'email:' . $email,
            'config' => [
                'adminSigner' => [
                    'type' => 'email',
                    'email' => $email,
                ],
            ],
        ];

        $response = wp_remote_post($environment, [
            'timeout' => 30,
            'headers' => [
                'Content-Type' => 'application/json',
                'X-API-KEY' => $settings['crossmint_api_key'],
                'x-idempotency-key' => 'digjy-wallet-' . $user_id,
            ],
            'body' => wp_json_encode($body),
        ]);

        if (is_wp_error($response)) {
            return $response;
        }
        $code = (int) wp_remote_retrieve_response_code($response);
        $payload = json_decode(wp_remote_retrieve_body($response), true);
        if ($code < 200 || $code >= 300) {
            return new WP_Error('crossmint_wallet_create_failed', $payload['message'] ?? __('Unable to auto-create the seller wallet.', 'digjy-stores'));
        }

        update_user_meta($user_id, 'digjy_wallet_payload', wp_json_encode($payload));
        return [
            'address' => $payload['address'] ?? '',
            'locator' => $payload['locator'] ?? ($payload['walletLocator'] ?? ''),
        ];
    }

    public function render_vendor_profile_fields($user) {
        ?>
        <h2><?php esc_html_e('Digjy Seller Settings', 'digjy-stores'); ?></h2>
        <table class="form-table">
            <tr><th><label for="digjy_seller_wallet"><?php esc_html_e('Seller Wallet', 'digjy-stores'); ?></label></th><td><input type="text" name="digjy_seller_wallet" id="digjy_seller_wallet" class="regular-text" value="<?php echo esc_attr(get_user_meta($user->ID, 'digjy_seller_wallet', true)); ?>" /></td></tr>
            <tr><th><label for="digjy_seller_wallet_locator"><?php esc_html_e('Wallet Locator', 'digjy-stores'); ?></label></th><td><input type="text" readonly name="digjy_seller_wallet_locator" id="digjy_seller_wallet_locator" class="regular-text" value="<?php echo esc_attr(get_user_meta($user->ID, 'digjy_seller_wallet_locator', true)); ?>" /></td></tr>
            <tr><th><?php esc_html_e('Wallet Provisioning Status', 'digjy-stores'); ?></th><td><?php echo esc_html(get_user_meta($user->ID, 'digjy_wallet_provisioning_error', true) ?: __('Ready', 'digjy-stores')); ?></td></tr>
        </table>
        <?php
    }

    public function save_vendor_profile_fields($user_id) {
        if (!current_user_can('edit_user', $user_id)) {
            return;
        }
        if (isset($_POST['digjy_seller_wallet'])) {
            update_user_meta($user_id, 'digjy_seller_wallet', sanitize_text_field(wp_unslash($_POST['digjy_seller_wallet'])));
        }
    }

    public static function get_store_by_user($user_id) {
        $store_id = (int) get_user_meta($user_id, 'digjy_store_id', true);
        return $store_id ? get_post($store_id) : null;
    }
}
