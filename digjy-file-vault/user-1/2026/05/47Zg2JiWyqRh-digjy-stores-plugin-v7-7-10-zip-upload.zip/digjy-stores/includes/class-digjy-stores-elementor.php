<?php
if (!defined('ABSPATH')) {
    exit;
}

class Digjy_Stores_Elementor {
    public function __construct() {
        add_action('elementor/loaded', [$this, 'init']);
    }

    public function init() {
        add_action('elementor/elements/categories_registered', [$this, 'register_category']);
        add_action('elementor/widgets/register', [$this, 'register_widgets']);
        add_action('elementor/frontend/after_register_scripts', [$this, 'register_frontend_assets']);
    }

    public function register_category($elements_manager) {
        $elements_manager->add_category(
            'digjy-stores',
            [
                'title' => __('Digjy Stores', 'digjy-stores'),
                'icon'  => 'fa fa-shopping-bag',
            ]
        );
    }

    public function register_widgets($widgets_manager) {
        require_once DIGJY_STORES_PATH . 'includes/elementor/class-digjy-stores-elementor-widget.php';
        $widgets_manager->register(new \Digjy_Stores_Elementor_Widget());
    }

    public function register_frontend_assets() {
        if (!wp_script_is('digjy-stores', 'registered') && file_exists(DIGJY_STORES_PATH . 'assets/js/digjy-stores.js')) {
            wp_register_script('digjy-stores', DIGJY_STORES_URL . 'assets/js/digjy-stores.js', ['jquery'], DIGJY_STORES_VERSION, true);
        }

        if (file_exists(DIGJY_STORES_PATH . 'assets/js/digjy-stores-elementor.js')) {
            wp_register_script(
                'digjy-stores-elementor',
                DIGJY_STORES_URL . 'assets/js/digjy-stores-elementor.js',
                ['elementor-frontend', 'digjy-stores'],
                DIGJY_STORES_VERSION,
                true
            );
        }
    }
}
