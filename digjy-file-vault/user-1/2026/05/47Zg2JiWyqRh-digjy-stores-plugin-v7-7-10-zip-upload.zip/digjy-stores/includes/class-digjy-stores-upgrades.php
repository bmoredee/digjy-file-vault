<?php
if (!defined('ABSPATH')) { exit; }

class Digjy_Stores_Upgrades {
    public function __construct() {
        add_action('init', [__CLASS__, 'register_post_types']);
        add_action('wp_ajax_digjy_dm_fetch', [$this, 'ajax_dm_fetch']);
        add_action('wp_ajax_digjy_dm_send', [$this, 'ajax_dm_send']);
        add_action('rest_api_init', [$this, 'register_routes']);
    }

    public static function register_post_types() {
        register_post_type('digjy_mint_request', [
            'labels' => ['name' => __('Mint Requests', 'digjy-stores'), 'singular_name' => __('Mint Request', 'digjy-stores')],
            'public' => false,
            'show_ui' => true,
            'show_in_menu' => 'edit.php?post_type=digjy_product',
            'supports' => ['title', 'editor', 'author'],
        ]);
    }

    private function get_thread($user_id, $other_id) {
        $msgs = get_posts([
            'post_type' => 'digjy_message', 'post_status' => 'publish', 'posts_per_page' => 100, 'orderby' => 'date', 'order' => 'ASC',
            'meta_query' => [
                'relation' => 'OR',
                ['relation' => 'AND', ['key' => '_digjy_message_sender_id', 'value' => $user_id], ['key' => '_digjy_message_recipient_id', 'value' => $other_id]],
                ['relation' => 'AND', ['key' => '_digjy_message_sender_id', 'value' => $other_id], ['key' => '_digjy_message_recipient_id', 'value' => $user_id]],
            ],
        ]);
        $items = [];
        foreach ($msgs as $m) {
            $items[] = [
                'id' => (int) $m->ID,
                'content' => wp_strip_all_tags($m->post_content),
                'subject' => $m->post_title,
                'sender_id' => (int) get_post_meta($m->ID, '_digjy_message_sender_id', true),
                'recipient_id' => (int) get_post_meta($m->ID, '_digjy_message_recipient_id', true),
                'created_at' => get_the_date('c', $m),
            ];
        }
        return $items;
    }

    private function insert_message($sender_id, $recipient_id, $message, $subject = 'Direct Message') {
        $message = wp_kses_post($message);
        if (!$sender_id || !$recipient_id || !$message) {
            return new WP_Error('digjy_dm_error', __('A recipient and message are required.', 'digjy-stores'));
        }
        $id = wp_insert_post([
            'post_type' => 'digjy_message',
            'post_status' => 'publish',
            'post_title' => sanitize_text_field($subject),
            'post_content' => $message,
            'post_author' => $sender_id,
        ], true);
        if (is_wp_error($id)) {
            return $id;
        }
        update_post_meta($id, '_digjy_message_sender_id', $sender_id);
        update_post_meta($id, '_digjy_message_recipient_id', $recipient_id);
        update_post_meta($id, '_digjy_message_status', 'unread');
        return $id;
    }

    public function ajax_dm_fetch() {
        check_ajax_referer('digjy_stores_nonce', 'nonce');
        if (!is_user_logged_in()) { wp_send_json_error(['message' => 'Login required'], 403); }
        $other = absint($_POST['user_id'] ?? 0);
        wp_send_json_success(['messages' => $this->get_thread(get_current_user_id(), $other)]);
    }

    public function ajax_dm_send() {
        check_ajax_referer('digjy_stores_nonce', 'nonce');
        if (!is_user_logged_in()) { wp_send_json_error(['message' => 'Login required'], 403); }
        $other = absint($_POST['recipient_id'] ?? 0);
        $msg = wp_unslash($_POST['message'] ?? '');
        $id = $this->insert_message(get_current_user_id(), $other, $msg);
        if (is_wp_error($id)) { wp_send_json_error(['message' => $id->get_error_message()], 400); }
        wp_send_json_success(['id' => $id, 'messages' => $this->get_thread(get_current_user_id(), $other)]);
    }

    public function register_routes() {
        register_rest_route('digjy-stores/v1', '/dm/conversations', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$this, 'rest_conversations'],
            'permission_callback' => function(){ return is_user_logged_in(); },
        ]);
        register_rest_route('digjy-stores/v1', '/dm/messages', [
            [
                'methods' => WP_REST_Server::READABLE,
                'callback' => [$this, 'rest_messages'],
                'permission_callback' => function(){ return is_user_logged_in(); },
            ],
            [
                'methods' => WP_REST_Server::CREATABLE,
                'callback' => [$this, 'rest_send_message'],
                'permission_callback' => function(){ return is_user_logged_in(); },
            ],
        ]);
    }

    public function rest_conversations() {
        $user_id = get_current_user_id();
        $messages = get_posts(['post_type' => 'digjy_message', 'post_status' => 'publish', 'posts_per_page' => 200, 'orderby' => 'date', 'order' => 'DESC', 'meta_query' => ['relation' => 'OR', ['key' => '_digjy_message_recipient_id', 'value' => $user_id], ['key' => '_digjy_message_sender_id', 'value' => $user_id]]]);
        $out = [];
        foreach ($messages as $m) {
            $s = (int) get_post_meta($m->ID, '_digjy_message_sender_id', true);
            $r = (int) get_post_meta($m->ID, '_digjy_message_recipient_id', true);
            $other = $s === $user_id ? $r : $s;
            if (!$other || isset($out[$other])) { continue; }
            $u = get_user_by('id', $other);
            $out[$other] = ['user_id' => $other, 'name' => $u ? $u->display_name : 'Unknown', 'snippet' => wp_trim_words(wp_strip_all_tags($m->post_content), 8), 'updated_at' => get_the_date('c', $m)];
        }
        return new WP_REST_Response(['items' => array_values($out)], 200);
    }

    public function rest_messages(WP_REST_Request $r) {
        $other = absint($r->get_param('user_id'));
        return new WP_REST_Response(['items' => $this->get_thread(get_current_user_id(), $other)], 200);
    }

    public function rest_send_message(WP_REST_Request $r) {
        $id = $this->insert_message(get_current_user_id(), absint($r->get_param('recipient_id')), (string) $r->get_param('message'), (string) ($r->get_param('subject') ?: 'Direct Message'));
        if (is_wp_error($id)) { return $id; }
        return new WP_REST_Response(['success' => true, 'id' => $id], 201);
    }
}
