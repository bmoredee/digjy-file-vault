<?php
if (!defined('ABSPATH')) {
    exit;
}

class Digjy_Stores_API {
    public function __construct() {
        add_action('init', [$this, 'register_post_types']);
        add_action('rest_api_init', [$this, 'register_routes']);
    }

    public static function register_post_types() {
        register_post_type('digjy_review', [
            'labels' => ['name' => __('Reviews', 'digjy-stores'), 'singular_name' => __('Review', 'digjy-stores')],
            'public' => false,
            'show_ui' => true,
            'show_in_menu' => 'edit.php?post_type=digjy_product',
            'supports' => ['title', 'editor', 'author'],
            'capability_type' => 'post',
            'show_in_rest' => false,
        ]);
    }

    public function register_routes() {
        $namespace = 'digjy-stores/v1';

        register_rest_route($namespace, '/auth/register', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [$this, 'register_user'],
            'permission_callback' => '__return_true',
        ]);
        register_rest_route($namespace, '/auth/login', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [$this, 'login_user'],
            'permission_callback' => '__return_true',
        ]);
        register_rest_route($namespace, '/auth/me', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$this, 'get_me'],
            'permission_callback' => [$this, 'require_logged_in'],
        ]);

        register_rest_route($namespace, '/products', [
            [
                'methods' => WP_REST_Server::READABLE,
                'callback' => [$this, 'get_products'],
                'permission_callback' => '__return_true',
            ],
            [
                'methods' => WP_REST_Server::CREATABLE,
                'callback' => [$this, 'create_product'],
                'permission_callback' => [$this, 'require_store_owner'],
            ],
        ]);
        register_rest_route($namespace, '/products/(?P<id>\d+)', [
            [
                'methods' => WP_REST_Server::READABLE,
                'callback' => [$this, 'get_product'],
                'permission_callback' => '__return_true',
            ],
            [
                'methods' => WP_REST_Server::EDITABLE,
                'callback' => [$this, 'update_product'],
                'permission_callback' => [$this, 'require_store_owner'],
            ],
        ]);

        register_rest_route($namespace, '/stores', [
            [
                'methods' => WP_REST_Server::READABLE,
                'callback' => [$this, 'get_stores'],
                'permission_callback' => '__return_true',
            ],
            [
                'methods' => WP_REST_Server::CREATABLE,
                'callback' => [$this, 'create_store'],
                'permission_callback' => [$this, 'require_store_owner'],
            ],
        ]);
        register_rest_route($namespace, '/stores/(?P<id>\d+)', [
            [
                'methods' => WP_REST_Server::READABLE,
                'callback' => [$this, 'get_store'],
                'permission_callback' => '__return_true',
            ],
            [
                'methods' => WP_REST_Server::EDITABLE,
                'callback' => [$this, 'update_store'],
                'permission_callback' => [$this, 'require_store_owner'],
            ],
        ]);

        register_rest_route($namespace, '/wallet', [
            [
                'methods' => WP_REST_Server::READABLE,
                'callback' => [$this, 'get_wallet'],
                'permission_callback' => [$this, 'require_logged_in'],
            ],
            [
                'methods' => WP_REST_Server::CREATABLE,
                'callback' => [$this, 'wallet_action'],
                'permission_callback' => [$this, 'require_logged_in'],
            ],
        ]);

        register_rest_route($namespace, '/reviews', [
            [
                'methods' => WP_REST_Server::READABLE,
                'callback' => [$this, 'get_reviews'],
                'permission_callback' => '__return_true',
            ],
            [
                'methods' => WP_REST_Server::CREATABLE,
                'callback' => [$this, 'create_review'],
                'permission_callback' => [$this, 'require_logged_in'],
            ],
        ]);
        register_rest_route($namespace, '/reviews/(?P<id>\d+)', [
            [
                'methods' => WP_REST_Server::READABLE,
                'callback' => [$this, 'get_review'],
                'permission_callback' => '__return_true',
            ],
            [
                'methods' => WP_REST_Server::EDITABLE,
                'callback' => [$this, 'update_review'],
                'permission_callback' => [$this, 'require_logged_in'],
            ],
        ]);

        register_rest_route($namespace, '/orders', [
            [
                'methods' => WP_REST_Server::READABLE,
                'callback' => [$this, 'get_orders'],
                'permission_callback' => [$this, 'require_logged_in'],
            ],
            [
                'methods' => WP_REST_Server::CREATABLE,
                'callback' => [$this, 'create_order'],
                'permission_callback' => [$this, 'require_logged_in'],
            ],
        ]);
        register_rest_route($namespace, '/orders/(?P<id>\d+)', [
            [
                'methods' => WP_REST_Server::READABLE,
                'callback' => [$this, 'get_order'],
                'permission_callback' => [$this, 'require_logged_in'],
            ],
            [
                'methods' => WP_REST_Server::EDITABLE,
                'callback' => [$this, 'update_order'],
                'permission_callback' => [$this, 'require_logged_in'],
            ],
        ]);

        register_rest_route($namespace, '/messages', [
            [
                'methods' => WP_REST_Server::READABLE,
                'callback' => [$this, 'get_messages'],
                'permission_callback' => [$this, 'require_logged_in'],
            ],
            [
                'methods' => WP_REST_Server::CREATABLE,
                'callback' => [$this, 'create_message'],
                'permission_callback' => [$this, 'require_logged_in'],
            ],
        ]);

        register_rest_route($namespace, '/follows', [
            [
                'methods' => WP_REST_Server::READABLE,
                'callback' => [$this, 'get_follows'],
                'permission_callback' => [$this, 'require_logged_in'],
            ],
            [
                'methods' => WP_REST_Server::CREATABLE,
                'callback' => [$this, 'toggle_follow'],
                'permission_callback' => [$this, 'require_logged_in'],
            ],
        ]);
    }

    public function require_logged_in() {
        return is_user_logged_in();
    }

    public function require_store_owner() {
        if (!is_user_logged_in()) {
            return false;
        }
        $user = wp_get_current_user();
        return in_array('digjy_store_owner', (array) $user->roles, true) || in_array('digjy_seller', (array) $user->roles, true) || user_can($user, 'manage_options');
    }

    private function error($message, $status = 400) {
        return new WP_Error('digjy_api_error', $message, ['status' => $status]);
    }

    private function get_json($request, $key, $default = null) {
        $value = $request->get_param($key);
        return $value !== null ? $value : $default;
    }

    private function serialize_user($user) {
        if (!$user) {
            return null;
        }
        return [
            'id' => (int) $user->ID,
            'username' => $user->user_login,
            'email' => $user->user_email,
            'display_name' => $user->display_name,
            'roles' => array_values((array) $user->roles),
            'store_id' => (int) get_user_meta($user->ID, 'digjy_store_id', true),
            'wallet_balance' => (float) get_user_meta($user->ID, 'digjy_wallet_balance', true),
            'seller_wallet' => get_user_meta($user->ID, 'digjy_seller_wallet', true),
        ];
    }

    private function serialize_product($post) {
        return [
            'id' => (int) $post->ID,
            'title' => $post->post_title,
            'description' => $post->post_content,
            'excerpt' => $post->post_excerpt,
            'status' => $post->post_status,
            'author_id' => (int) $post->post_author,
            'product_type' => get_post_meta($post->ID, '_digjy_product_type', true) ?: 'regular',
            'price' => (float) get_post_meta($post->ID, '_digjy_price', true),
            'file_url' => get_post_meta($post->ID, '_digjy_file_url', true),
            'sku' => get_post_meta($post->ID, '_digjy_sku', true),
            'license' => get_post_meta($post->ID, '_digjy_license', true),
            'asset_mode' => get_post_meta($post->ID, '_digjy_asset_mode', true),
            'chain' => get_post_meta($post->ID, '_digjy_chain', true),
            'collection_locator' => get_post_meta($post->ID, '_digjy_collection_locator', true),
            'token_id' => get_post_meta($post->ID, '_digjy_token_id', true),
            'contract_address' => get_post_meta($post->ID, '_digjy_contract_address', true),
            'owner' => get_post_meta($post->ID, '_digjy_owner', true),
            'txid' => get_post_meta($post->ID, '_digjy_txid', true),
            'onchain_status' => get_post_meta($post->ID, '_digjy_onchain_status', true),
            'recipient_wallet' => get_post_meta($post->ID, '_digjy_recipient_wallet', true),
            'metadata_uri' => get_post_meta($post->ID, '_digjy_metadata_uri', true),
            'royalty_percent' => (float) get_post_meta($post->ID, '_digjy_royalty_percent', true),
            'royalty_recipient' => get_post_meta($post->ID, '_digjy_royalty_recipient', true),
            'buyer_creator_royalty_percent' => (int) get_post_meta($post->ID, '_digjy_buyer_creator_royalty_percent', true),
            'nft_template_id' => get_post_meta($post->ID, '_digjy_nft_template_id', true),
            'nft_name' => get_post_meta($post->ID, '_digjy_nft_name', true),
            'nft_symbol' => get_post_meta($post->ID, '_digjy_nft_symbol', true),
            'nft_image' => get_post_meta($post->ID, '_digjy_nft_image', true),
            'nft_supply' => (int) get_post_meta($post->ID, '_digjy_nft_supply', true),
            'permalink' => get_permalink($post),
            'review_summary' => $this->get_review_summary((int) $post->ID),
        ];
    }

    private function get_review_summary($product_id) {
        $reviews = get_posts([
            'post_type' => 'digjy_review',
            'post_status' => 'publish',
            'posts_per_page' => 100,
            'meta_key' => '_digjy_review_product_id',
            'meta_value' => absint($product_id),
        ]);
        $total = count($reviews);
        $sum = 0;
        foreach ($reviews as $review) {
            $sum += max(1, min(5, (int) get_post_meta($review->ID, '_digjy_review_rating', true)));
        }
        return [
            'average' => $total ? round($sum / $total, 1) : 0,
            'count' => $total,
        ];
    }

    private function serialize_store($post) {
        $owner = get_user_by('id', $post->post_author);
        return [
            'id' => (int) $post->ID,
            'title' => $post->post_title,
            'description' => $post->post_content,
            'excerpt' => $post->post_excerpt,
            'status' => $post->post_status,
            'author_id' => (int) $post->post_author,
            'owner' => $this->serialize_user($owner),
            'permalink' => get_permalink($post),
            'followers_count' => count((array) get_user_meta($post->post_author, 'digjy_followers', true)),
        ];
    }

    private function serialize_order($post) {
        return [
            'id' => (int) $post->ID,
            'title' => $post->post_title,
            'status' => get_post_meta($post->ID, '_digjy_order_status', true),
            'status_label' => get_post_meta($post->ID, '_digjy_status_label', true),
            'product_id' => (int) get_post_meta($post->ID, '_digjy_product_id', true),
            'seller_id' => (int) get_post_meta($post->ID, '_digjy_seller_id', true),
            'buyer_email' => get_post_meta($post->ID, '_digjy_buyer_email', true),
            'payment_method' => get_post_meta($post->ID, '_digjy_payment_method', true),
            'product_type' => get_post_meta($post->ID, '_digjy_product_type', true) ?: 'regular',
            'price' => (float) get_post_meta($post->ID, '_digjy_price', true),
            'marketplace_amount' => (float) get_post_meta($post->ID, '_digjy_marketplace_amount', true),
            'seller_amount' => (float) get_post_meta($post->ID, '_digjy_seller_amount', true),
            'crossmint_order_id' => get_post_meta($post->ID, '_digjy_crossmint_order_id', true),
            'download_url' => function_exists('digjy_stores') && isset(digjy_stores()->checkout) ? digjy_stores()->checkout->get_download_url($post->ID) : '',
            'created_at' => get_the_date('c', $post),
        ];
    }

    private function serialize_review($post) {
        return [
            'id' => (int) $post->ID,
            'title' => $post->post_title,
            'content' => $post->post_content,
            'status' => $post->post_status,
            'author_id' => (int) $post->post_author,
            'product_id' => (int) get_post_meta($post->ID, '_digjy_review_product_id', true),
            'store_id' => (int) get_post_meta($post->ID, '_digjy_review_store_id', true),
            'rating' => (int) get_post_meta($post->ID, '_digjy_review_rating', true),
            'verified_owner' => $this->user_has_purchased_product((int) $post->post_author, (int) get_post_meta($post->ID, '_digjy_review_product_id', true)),
            'created_at' => get_the_date('c', $post),
        ];
    }

    private function serialize_wallet_transaction($post) {
        return [
            'id' => (int) $post->ID,
            'title' => $post->post_title,
            'content' => $post->post_content,
            'type' => get_post_meta($post->ID, '_digjy_wallet_type', true),
            'amount' => (float) get_post_meta($post->ID, '_digjy_wallet_amount', true),
            'meta' => json_decode((string) get_post_meta($post->ID, '_digjy_wallet_meta', true), true),
            'created_at' => get_the_date('c', $post),
        ];
    }

    private function ensure_product_owner($product_id, $user_id) {
        $post = get_post($product_id);
        if (!$post || 'digjy_product' !== $post->post_type) {
            return $this->error(__('Product not found.', 'digjy-stores'), 404);
        }
        if ((int) $post->post_author !== (int) $user_id && !current_user_can('manage_options')) {
            return $this->error(__('You cannot edit this product.', 'digjy-stores'), 403);
        }
        return $post;
    }

    private function ensure_store_owner($store_id, $user_id) {
        $post = get_post($store_id);
        if (!$post || 'digjy_store' !== $post->post_type) {
            return $this->error(__('Store not found.', 'digjy-stores'), 404);
        }
        if ((int) $post->post_author !== (int) $user_id && !current_user_can('manage_options')) {
            return $this->error(__('You cannot edit this store.', 'digjy-stores'), 403);
        }
        return $post;
    }

    public function register_user(WP_REST_Request $request) {
        $type = sanitize_key((string) $this->get_json($request, 'account_type', 'customer'));
        $email = sanitize_email((string) $this->get_json($request, 'email', ''));
        $username = sanitize_user((string) $this->get_json($request, 'username', ''));
        $password = (string) $this->get_json($request, 'password', '');
        $first_name = sanitize_text_field((string) $this->get_json($request, 'first_name', ''));
        $last_name = sanitize_text_field((string) $this->get_json($request, 'last_name', ''));
        $store_name = sanitize_text_field((string) $this->get_json($request, 'store_name', ''));
        $seller_wallet = sanitize_text_field((string) $this->get_json($request, 'seller_wallet', ''));

        if (!$email || !$username || !$password) {
            return $this->error(__('Email, username, and password are required.', 'digjy-stores'), 400);
        }
        if (username_exists($username) || email_exists($email)) {
            return $this->error(__('That username or email is already in use.', 'digjy-stores'), 409);
        }

        $user_id = wp_create_user($username, $password, $email);
        if (is_wp_error($user_id)) {
            return $user_id;
        }

        $display_name = trim($first_name . ' ' . $last_name) ?: $username;
        wp_update_user([
            'ID' => $user_id,
            'first_name' => $first_name,
            'last_name' => $last_name,
            'display_name' => $display_name,
            'role' => $type === 'store_owner' ? 'digjy_store_owner' : 'digjy_customer',
        ]);

        if ($type === 'store_owner') {
            $user = new WP_User($user_id);
            $user->add_role('digjy_seller');
            if ($seller_wallet) {
                update_user_meta($user_id, 'digjy_seller_wallet', $seller_wallet);
            }
            $store_id = wp_insert_post([
                'post_type' => 'digjy_store',
                'post_status' => 'publish',
                'post_title' => $store_name ?: sprintf(__('%s Store', 'digjy-stores'), $display_name),
                'post_author' => $user_id,
                'post_content' => __('Welcome to my store.', 'digjy-stores'),
            ]);
            if ($store_id && !is_wp_error($store_id)) {
                update_user_meta($user_id, 'digjy_store_id', $store_id);
            }
        } else {
            update_user_meta($user_id, 'digjy_customer_created', current_time('mysql'));
        }

        wp_set_current_user($user_id);
        wp_set_auth_cookie($user_id, true);
        return new WP_REST_Response([
            'success' => true,
            'user' => $this->serialize_user(get_user_by('id', $user_id)),
            'rest_nonce' => wp_create_nonce('wp_rest'),
        ], 201);
    }

    public function login_user(WP_REST_Request $request) {
        $login = sanitize_text_field((string) $this->get_json($request, 'login', ''));
        $password = (string) $this->get_json($request, 'password', '');
        $remember = (bool) $this->get_json($request, 'remember', true);
        if (!$login || !$password) {
            return $this->error(__('Login and password are required.', 'digjy-stores'), 400);
        }
        $creds = [
            'user_login' => $login,
            'user_password' => $password,
            'remember' => $remember,
        ];
        $user = wp_signon($creds, is_ssl());
        if (is_wp_error($user)) {
            return $this->error(__('Invalid credentials.', 'digjy-stores'), 401);
        }
        wp_set_current_user($user->ID);
        wp_set_auth_cookie($user->ID, $remember);
        return new WP_REST_Response([
            'success' => true,
            'user' => $this->serialize_user($user),
            'rest_nonce' => wp_create_nonce('wp_rest'),
        ], 200);
    }

    public function get_me() {
        return new WP_REST_Response(['user' => $this->serialize_user(wp_get_current_user())], 200);
    }

    public function get_products(WP_REST_Request $request) {
        $args = [
            'post_type' => 'digjy_product',
            'post_status' => 'publish',
            'posts_per_page' => min(100, max(1, (int) $request->get_param('per_page') ?: 20)),
            'paged' => max(1, (int) $request->get_param('page') ?: 1),
        ];
        if ($request->get_param('author_id')) {
            $args['author'] = absint($request->get_param('author_id'));
        }
        $posts = get_posts($args);
        return new WP_REST_Response(['items' => array_map([$this, 'serialize_product'], $posts)], 200);
    }

    public function get_product(WP_REST_Request $request) {
        $post = get_post((int) $request['id']);
        if (!$post || 'digjy_product' !== $post->post_type) {
            return $this->error(__('Product not found.', 'digjy-stores'), 404);
        }
        return new WP_REST_Response(['item' => $this->serialize_product($post)], 200);
    }

    public function create_product(WP_REST_Request $request) {
        $user_id = get_current_user_id();
        $title = sanitize_text_field((string) $this->get_json($request, 'title', ''));
        if (!$title) {
            return $this->error(__('Product title is required.', 'digjy-stores'), 400);
        }
        $post_id = wp_insert_post([
            'post_type' => 'digjy_product',
            'post_status' => sanitize_key((string) $this->get_json($request, 'status', 'publish')),
            'post_title' => $title,
            'post_content' => wp_kses_post((string) $this->get_json($request, 'description', '')),
            'post_excerpt' => sanitize_textarea_field((string) $this->get_json($request, 'excerpt', '')),
            'post_author' => $user_id,
        ], true);
        if (is_wp_error($post_id)) {
            return $post_id;
        }
        $this->update_product_meta_from_request($post_id, $request);
        return new WP_REST_Response(['item' => $this->serialize_product(get_post($post_id))], 201);
    }

    public function update_product(WP_REST_Request $request) {
        $post = $this->ensure_product_owner((int) $request['id'], get_current_user_id());
        if (is_wp_error($post)) {
            return $post;
        }
        $update = ['ID' => $post->ID];
        foreach (['title' => 'post_title', 'description' => 'post_content', 'excerpt' => 'post_excerpt', 'status' => 'post_status'] as $input => $field) {
            if ($request->get_param($input) !== null) {
                $update[$field] = $field === 'post_content' ? wp_kses_post((string) $request->get_param($input)) : (($field === 'post_excerpt') ? sanitize_textarea_field((string) $request->get_param($input)) : sanitize_text_field((string) $request->get_param($input)));
            }
        }
        wp_update_post($update);
        $this->update_product_meta_from_request($post->ID, $request, true);
        return new WP_REST_Response(['item' => $this->serialize_product(get_post($post->ID))], 200);
    }

    private function update_product_meta_from_request($post_id, WP_REST_Request $request, $partial = false) {
        $map = [
            'price' => ['_digjy_price', 'float'],
            'file_url' => ['_digjy_file_url', 'url'],
            'sku' => ['_digjy_sku', 'text'],
            'license' => ['_digjy_license', 'textarea'],
            'asset_mode' => ['_digjy_asset_mode', 'text'],
            'chain' => ['_digjy_chain', 'text'],
            'collection_locator' => ['_digjy_collection_locator', 'text'],
            'token_id' => ['_digjy_token_id', 'text'],
            'contract_address' => ['_digjy_contract_address', 'text'],
            'owner' => ['_digjy_owner', 'text'],
            'txid' => ['_digjy_txid', 'text'],
            'onchain_status' => ['_digjy_onchain_status', 'text'],
            'recipient_wallet' => ['_digjy_recipient_wallet', 'text'],
            'metadata_uri' => ['_digjy_metadata_uri', 'url'],
            'royalty_percent' => ['_digjy_royalty_percent', 'float'],
            'royalty_recipient' => ['_digjy_royalty_recipient', 'text'],
            'buyer_creator_royalty_percent' => ['_digjy_buyer_creator_royalty_percent', 'float'],
            'nft_template_id' => ['_digjy_nft_template_id', 'text'],
            'nft_name' => ['_digjy_nft_name', 'text'],
            'nft_symbol' => ['_digjy_nft_symbol', 'text'],
            'nft_image' => ['_digjy_nft_image', 'url'],
            'nft_supply' => ['_digjy_nft_supply', 'float'],
        ];
        foreach ($map as $input => $config) {
            if ($partial && $request->get_param($input) === null) {
                continue;
            }
            $value = $request->get_param($input);
            switch ($config[1]) {
                case 'float': $value = (float) $value; break;
                case 'url': $value = esc_url_raw((string) $value); break;
                case 'textarea': $value = sanitize_textarea_field((string) $value); break;
                default: $value = sanitize_text_field((string) $value); break;
            }
            update_post_meta($post_id, $config[0], $value);
        }
    }

    public function get_stores(WP_REST_Request $request) {
        $args = [
            'post_type' => 'digjy_store',
            'post_status' => 'publish',
            'posts_per_page' => min(100, max(1, (int) $request->get_param('per_page') ?: 20)),
            'paged' => max(1, (int) $request->get_param('page') ?: 1),
        ];
        $posts = get_posts($args);
        return new WP_REST_Response(['items' => array_map([$this, 'serialize_store'], $posts)], 200);
    }

    public function get_store(WP_REST_Request $request) {
        $post = get_post((int) $request['id']);
        if (!$post || 'digjy_store' !== $post->post_type) {
            return $this->error(__('Store not found.', 'digjy-stores'), 404);
        }
        return new WP_REST_Response(['item' => $this->serialize_store($post)], 200);
    }

    public function create_store(WP_REST_Request $request) {
        $user_id = get_current_user_id();
        $existing_store_id = (int) get_user_meta($user_id, 'digjy_store_id', true);
        if ($existing_store_id) {
            return $this->error(__('This user already has a store.', 'digjy-stores'), 409);
        }
        $title = sanitize_text_field((string) $this->get_json($request, 'title', ''));
        if (!$title) {
            return $this->error(__('Store title is required.', 'digjy-stores'), 400);
        }
        $post_id = wp_insert_post([
            'post_type' => 'digjy_store',
            'post_status' => sanitize_key((string) $this->get_json($request, 'status', 'publish')),
            'post_title' => $title,
            'post_content' => wp_kses_post((string) $this->get_json($request, 'description', '')),
            'post_excerpt' => sanitize_textarea_field((string) $this->get_json($request, 'excerpt', '')),
            'post_author' => $user_id,
        ], true);
        if (is_wp_error($post_id)) {
            return $post_id;
        }
        update_user_meta($user_id, 'digjy_store_id', $post_id);
        return new WP_REST_Response(['item' => $this->serialize_store(get_post($post_id))], 201);
    }

    public function update_store(WP_REST_Request $request) {
        $post = $this->ensure_store_owner((int) $request['id'], get_current_user_id());
        if (is_wp_error($post)) {
            return $post;
        }
        $update = ['ID' => $post->ID];
        foreach (['title' => 'post_title', 'description' => 'post_content', 'excerpt' => 'post_excerpt', 'status' => 'post_status'] as $input => $field) {
            if ($request->get_param($input) !== null) {
                $update[$field] = $field === 'post_content' ? wp_kses_post((string) $request->get_param($input)) : (($field === 'post_excerpt') ? sanitize_textarea_field((string) $request->get_param($input)) : sanitize_text_field((string) $request->get_param($input)));
            }
        }
        wp_update_post($update);
        return new WP_REST_Response(['item' => $this->serialize_store(get_post($post->ID))], 200);
    }

    public function get_wallet() {
        $user_id = get_current_user_id();
        $txs = get_posts([
            'post_type' => 'digjy_wallet_tx',
            'post_status' => 'publish',
            'posts_per_page' => 50,
            'orderby' => 'date',
            'order' => 'DESC',
            'author' => $user_id,
        ]);
        return new WP_REST_Response([
            'balance' => (float) get_user_meta($user_id, 'digjy_wallet_balance', true),
            'transactions' => array_map([$this, 'serialize_wallet_transaction'], $txs),
        ], 200);
    }

    public function wallet_action(WP_REST_Request $request) {
        $user_id = get_current_user_id();
        $action = sanitize_key((string) $this->get_json($request, 'action', ''));
        $amount = round((float) $this->get_json($request, 'amount', 0), 2);
        if (!$action || $amount <= 0) {
            return $this->error(__('Action and a positive amount are required.', 'digjy-stores'), 400);
        }
        $balance = (float) get_user_meta($user_id, 'digjy_wallet_balance', true);
        if ($action === 'deposit') {
            update_user_meta($user_id, 'digjy_wallet_balance', $balance + $amount);
            $this->insert_wallet_tx($user_id, 'deposit', $amount, __('API deposit recorded.', 'digjy-stores'));
        } elseif ($action === 'withdraw_request') {
            $this->insert_wallet_tx($user_id, 'withdraw_request', -$amount, __('Withdrawal request submitted by API.', 'digjy-stores'));
        } elseif ($action === 'transfer') {
            $recipient_value = sanitize_text_field((string) $this->get_json($request, 'recipient', ''));
            $recipient = get_user_by('login', $recipient_value);
            if (!$recipient && is_email($recipient_value)) {
                $recipient = get_user_by('email', $recipient_value);
            }
            if (!$recipient || $recipient->ID === $user_id) {
                return $this->error(__('A valid recipient is required.', 'digjy-stores'), 400);
            }
            if ($balance < $amount) {
                return $this->error(__('Insufficient wallet balance.', 'digjy-stores'), 400);
            }
            update_user_meta($user_id, 'digjy_wallet_balance', $balance - $amount);
            update_user_meta($recipient->ID, 'digjy_wallet_balance', (float) get_user_meta($recipient->ID, 'digjy_wallet_balance', true) + $amount);
            $this->insert_wallet_tx($user_id, 'transfer_out', -$amount, sprintf(__('Transfer sent to %s.', 'digjy-stores'), $recipient->user_login), ['recipient_id' => $recipient->ID]);
            $this->insert_wallet_tx($recipient->ID, 'transfer_in', $amount, sprintf(__('Transfer received from %s.', 'digjy-stores'), wp_get_current_user()->user_login), ['sender_id' => $user_id]);
        } else {
            return $this->error(__('Unsupported wallet action.', 'digjy-stores'), 400);
        }
        return $this->get_wallet();
    }

    private function insert_wallet_tx($user_id, $type, $amount, $note = '', $meta = []) {
        $tx_id = wp_insert_post([
            'post_type' => 'digjy_wallet_tx',
            'post_status' => 'publish',
            'post_title' => sprintf('%s %s', ucfirst(str_replace('_', ' ', $type)), current_time('mysql')),
            'post_content' => wp_kses_post($note),
            'post_author' => absint($user_id),
        ]);
        if ($tx_id && !is_wp_error($tx_id)) {
            update_post_meta($tx_id, '_digjy_wallet_user_id', absint($user_id));
            update_post_meta($tx_id, '_digjy_wallet_type', sanitize_text_field($type));
            update_post_meta($tx_id, '_digjy_wallet_amount', round((float) $amount, 2));
            update_post_meta($tx_id, '_digjy_wallet_meta', wp_json_encode($meta));
        }
        return $tx_id;
    }

    private function user_has_purchased_product($user_id, $product_id) {
        $user = get_user_by('id', absint($user_id));
        if (!$user || !$product_id) {
            return false;
        }
        $orders = get_posts([
            'post_type' => 'digjy_order',
            'post_status' => 'publish',
            'posts_per_page' => 1,
            'meta_query' => [
                'relation' => 'AND',
                ['key' => '_digjy_product_id', 'value' => absint($product_id)],
                ['key' => '_digjy_buyer_email', 'value' => $user->user_email],
            ],
        ]);
        return !empty($orders);
    }

    public function get_reviews(WP_REST_Request $request) {
        $meta_query = [];
        if ($request->get_param('product_id')) {
            $meta_query[] = ['key' => '_digjy_review_product_id', 'value' => absint($request->get_param('product_id'))];
        }
        if ($request->get_param('store_id')) {
            $meta_query[] = ['key' => '_digjy_review_store_id', 'value' => absint($request->get_param('store_id'))];
        }
        $posts = get_posts([
            'post_type' => 'digjy_review',
            'post_status' => 'publish',
            'posts_per_page' => 100,
            'meta_query' => $meta_query,
        ]);
        return new WP_REST_Response(['items' => array_map([$this, 'serialize_review'], $posts)], 200);
    }

    public function get_review(WP_REST_Request $request) {
        $post = get_post((int) $request['id']);
        if (!$post || 'digjy_review' !== $post->post_type) {
            return $this->error(__('Review not found.', 'digjy-stores'), 404);
        }
        return new WP_REST_Response(['item' => $this->serialize_review($post)], 200);
    }

    public function create_review(WP_REST_Request $request) {
        $product_id = absint($this->get_json($request, 'product_id', 0));
        $store_id = absint($this->get_json($request, 'store_id', 0));
        $rating = max(1, min(5, (int) $this->get_json($request, 'rating', 5)));
        $content = wp_kses_post((string) $this->get_json($request, 'content', ''));
        if (!$product_id && !$store_id) {
            return $this->error(__('A product_id or store_id is required.', 'digjy-stores'), 400);
        }
        if ($product_id && !$this->user_has_purchased_product(get_current_user_id(), $product_id) && !current_user_can('manage_options')) {
            return $this->error(__('Only customers who purchased this product can leave a review.', 'digjy-stores'), 403);
        }
        if (!$content) {
            return $this->error(__('Review content is required.', 'digjy-stores'), 400);
        }
        $post_id = wp_insert_post([
            'post_type' => 'digjy_review',
            'post_status' => 'publish',
            'post_title' => sanitize_text_field((string) $this->get_json($request, 'title', __('Marketplace Review', 'digjy-stores'))),
            'post_content' => $content,
            'post_author' => get_current_user_id(),
        ], true);
        if (is_wp_error($post_id)) {
            return $post_id;
        }
        update_post_meta($post_id, '_digjy_review_product_id', $product_id);
        update_post_meta($post_id, '_digjy_review_store_id', $store_id);
        update_post_meta($post_id, '_digjy_review_rating', $rating);
        return new WP_REST_Response(['item' => $this->serialize_review(get_post($post_id))], 201);
    }

    public function update_review(WP_REST_Request $request) {
        $post = get_post((int) $request['id']);
        if (!$post || 'digjy_review' !== $post->post_type) {
            return $this->error(__('Review not found.', 'digjy-stores'), 404);
        }
        if ((int) $post->post_author !== get_current_user_id() && !current_user_can('manage_options')) {
            return $this->error(__('You cannot edit this review.', 'digjy-stores'), 403);
        }
        $update = ['ID' => $post->ID];
        if ($request->get_param('title') !== null) {
            $update['post_title'] = sanitize_text_field((string) $request->get_param('title'));
        }
        if ($request->get_param('content') !== null) {
            $update['post_content'] = wp_kses_post((string) $request->get_param('content'));
        }
        wp_update_post($update);
        if ($request->get_param('rating') !== null) {
            update_post_meta($post->ID, '_digjy_review_rating', max(1, min(5, (int) $request->get_param('rating'))));
        }
        return new WP_REST_Response(['item' => $this->serialize_review(get_post($post->ID))], 200);
    }

    public function get_orders() {
        $user = wp_get_current_user();
        $roles = (array) $user->roles;
        $args = [
            'post_type' => 'digjy_order',
            'post_status' => 'publish',
            'posts_per_page' => 100,
            'orderby' => 'date',
            'order' => 'DESC',
        ];
        if (in_array('digjy_store_owner', $roles, true) || in_array('digjy_seller', $roles, true)) {
            $args['meta_key'] = '_digjy_seller_id';
            $args['meta_value'] = $user->ID;
        } elseif (!user_can($user, 'manage_options')) {
            $args['meta_key'] = '_digjy_buyer_email';
            $args['meta_value'] = $user->user_email;
        }
        $posts = get_posts($args);
        return new WP_REST_Response(['items' => array_map([$this, 'serialize_order'], $posts)], 200);
    }

    public function get_order(WP_REST_Request $request) {
        $post = get_post((int) $request['id']);
        if (!$post || 'digjy_order' !== $post->post_type) {
            return $this->error(__('Order not found.', 'digjy-stores'), 404);
        }
        if (!$this->user_can_view_order($post)) {
            return $this->error(__('You cannot view this order.', 'digjy-stores'), 403);
        }
        return new WP_REST_Response(['item' => $this->serialize_order($post)], 200);
    }

    public function create_order(WP_REST_Request $request) {
        $product_id = absint($this->get_json($request, 'product_id', 0));
        $product = get_post($product_id);
        if (!$product || 'digjy_product' !== $product->post_type) {
            return $this->error(__('Product not found.', 'digjy-stores'), 404);
        }
        $buyer = wp_get_current_user();
        $price = (float) get_post_meta($product_id, '_digjy_price', true);
        $order_id = wp_insert_post([
            'post_type' => 'digjy_order',
            'post_status' => 'publish',
            'post_title' => sprintf(__('Order for %s', 'digjy-stores'), $product->post_title),
        ], true);
        if (is_wp_error($order_id)) {
            return $order_id;
        }
        update_post_meta($order_id, '_digjy_product_id', $product_id);
        update_post_meta($order_id, '_digjy_seller_id', (int) $product->post_author);
        update_post_meta($order_id, '_digjy_buyer_email', $buyer->user_email);
        update_post_meta($order_id, '_digjy_order_status', sanitize_text_field((string) $this->get_json($request, 'status', 'pending')));
        update_post_meta($order_id, '_digjy_status_label', sanitize_text_field((string) $this->get_json($request, 'status_label', 'Pending')));
        update_post_meta($order_id, '_digjy_payment_method', sanitize_text_field((string) $this->get_json($request, 'payment_method', 'manual')));
        update_post_meta($order_id, '_digjy_price', $price);
        update_post_meta($order_id, '_digjy_marketplace_amount', round($price * 0.10, 2));
        update_post_meta($order_id, '_digjy_seller_amount', round($price * 0.90, 2));
        return new WP_REST_Response(['item' => $this->serialize_order(get_post($order_id))], 201);
    }

    public function update_order(WP_REST_Request $request) {
        $post = get_post((int) $request['id']);
        if (!$post || 'digjy_order' !== $post->post_type) {
            return $this->error(__('Order not found.', 'digjy-stores'), 404);
        }
        $user = wp_get_current_user();
        $seller_id = (int) get_post_meta($post->ID, '_digjy_seller_id', true);
        $buyer_email = (string) get_post_meta($post->ID, '_digjy_buyer_email', true);
        $can_edit = user_can($user, 'manage_options') || (int) $user->ID === $seller_id || $user->user_email === $buyer_email;
        if (!$can_edit) {
            return $this->error(__('You cannot update this order.', 'digjy-stores'), 403);
        }
        if ($request->get_param('status') !== null) {
            update_post_meta($post->ID, '_digjy_order_status', sanitize_text_field((string) $request->get_param('status')));
        }
        if ($request->get_param('status_label') !== null) {
            update_post_meta($post->ID, '_digjy_status_label', sanitize_text_field((string) $request->get_param('status_label')));
        }
        if ($request->get_param('payment_method') !== null) {
            update_post_meta($post->ID, '_digjy_payment_method', sanitize_text_field((string) $request->get_param('payment_method')));
        }
        return new WP_REST_Response(['item' => $this->serialize_order(get_post($post->ID))], 200);
    }


    public function get_messages() {
        $user_id = get_current_user_id();
        $posts = get_posts([
            'post_type' => 'digjy_message',
            'post_status' => 'publish',
            'posts_per_page' => 100,
            'orderby' => 'date',
            'order' => 'DESC',
            'meta_query' => [
                'relation' => 'OR',
                ['key' => '_digjy_message_recipient_id', 'value' => $user_id],
                ['key' => '_digjy_message_sender_id', 'value' => $user_id],
            ],
        ]);
        $items = array_map(function($post){
            return [
                'id' => (int) $post->ID,
                'title' => $post->post_title,
                'content' => $post->post_content,
                'sender_id' => (int) get_post_meta($post->ID, '_digjy_message_sender_id', true),
                'recipient_id' => (int) get_post_meta($post->ID, '_digjy_message_recipient_id', true),
                'created_at' => get_the_date('c', $post),
            ];
        }, $posts);
        return new WP_REST_Response(['items' => $items], 200);
    }

    public function create_message(WP_REST_Request $request) {
        $recipient_id = absint($this->get_json($request, 'recipient_id', 0));
        $content = wp_kses_post((string) $this->get_json($request, 'content', ''));
        $title = sanitize_text_field((string) $this->get_json($request, 'title', __('Marketplace Message', 'digjy-stores')));
        if (!$recipient_id || !$content || $recipient_id === get_current_user_id()) {
            return $this->error(__('A valid recipient and message content are required.', 'digjy-stores'), 400);
        }
        $post_id = wp_insert_post([
            'post_type' => 'digjy_message',
            'post_status' => 'publish',
            'post_title' => $title,
            'post_content' => $content,
            'post_author' => get_current_user_id(),
        ], true);
        if (is_wp_error($post_id)) {
            return $post_id;
        }
        update_post_meta($post_id, '_digjy_message_sender_id', get_current_user_id());
        update_post_meta($post_id, '_digjy_message_recipient_id', $recipient_id);
        update_post_meta($post_id, '_digjy_message_subject', $title);
        update_post_meta($post_id, '_digjy_message_read', 0);
        return new WP_REST_Response(['item' => [
            'id' => (int) $post_id,
            'title' => $title,
            'content' => $content,
            'sender_id' => get_current_user_id(),
            'recipient_id' => $recipient_id,
        ]], 201);
    }

    public function get_follows() {
        $user_id = get_current_user_id();
        $following = get_user_meta($user_id, 'digjy_following', true);
        $followers = get_user_meta($user_id, 'digjy_followers', true);
        return new WP_REST_Response([
            'following' => is_array($following) ? array_values(array_map('absint', $following)) : [],
            'followers' => is_array($followers) ? array_values(array_map('absint', $followers)) : [],
        ], 200);
    }

    public function toggle_follow(WP_REST_Request $request) {
        $target_user_id = absint($this->get_json($request, 'target_user_id', 0));
        $user_id = get_current_user_id();
        if (!$target_user_id || $target_user_id === $user_id) {
            return $this->error(__('A valid target_user_id is required.', 'digjy-stores'), 400);
        }
        $following = get_user_meta($user_id, 'digjy_following', true);
        $followers = get_user_meta($target_user_id, 'digjy_followers', true);
        $following = is_array($following) ? array_values(array_map('absint', $following)) : [];
        $followers = is_array($followers) ? array_values(array_map('absint', $followers)) : [];
        $following_now = false;
        if (in_array($target_user_id, $following, true)) {
            $following = array_values(array_diff($following, [$target_user_id]));
            $followers = array_values(array_diff($followers, [$user_id]));
        } else {
            $following[] = $target_user_id;
            $followers[] = $user_id;
            $following = array_values(array_unique($following));
            $followers = array_values(array_unique($followers));
            $following_now = true;
        }
        update_user_meta($user_id, 'digjy_following', $following);
        update_user_meta($target_user_id, 'digjy_followers', $followers);
        return new WP_REST_Response([
            'following' => $following_now,
            'followers_count' => count($followers),
            'target_user_id' => $target_user_id,
        ], 200);
    }

    private function user_can_view_order($post) {
        $user = wp_get_current_user();
        if (user_can($user, 'manage_options')) {
            return true;
        }
        $seller_id = (int) get_post_meta($post->ID, '_digjy_seller_id', true);
        $buyer_email = (string) get_post_meta($post->ID, '_digjy_buyer_email', true);
        return (int) $user->ID === $seller_id || $user->user_email === $buyer_email;
    }
}
