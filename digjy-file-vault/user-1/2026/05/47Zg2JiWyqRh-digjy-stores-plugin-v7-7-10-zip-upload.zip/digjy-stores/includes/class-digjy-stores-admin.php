<?php
if (!defined('ABSPATH')) {
    exit;
}

class Digjy_Stores_Admin {
    public function __construct() {
        add_action('admin_menu', [$this, 'admin_menu']);
        add_action('admin_init', [$this, 'register_settings']);
        add_action('admin_notices', [$this, 'dependency_notice']);
    }

    public function dependency_notice() {
        if (!current_user_can('manage_options')) {
            return;
        }
        if (version_compare(PHP_VERSION, '7.4', '<')) {
            echo '<div class="notice notice-error"><p>' . esc_html__('Digjy Stores requires PHP 7.4 or newer.', 'digjy-stores') . '</p></div>';
        }
    }

    public function admin_menu() {
        add_menu_page(__('Digjy Stores', 'digjy-stores'), __('Digjy Stores', 'digjy-stores'), 'manage_options', 'digjy-stores', [$this, 'settings_page'], 'dashicons-store', 56);
        add_submenu_page('digjy-stores', __('Settings', 'digjy-stores'), __('Settings', 'digjy-stores'), 'manage_options', 'digjy-stores', [$this, 'settings_page']);
        add_submenu_page('digjy-stores', __('Shortcodes', 'digjy-stores'), __('Shortcodes', 'digjy-stores'), 'manage_options', 'digjy-stores-shortcodes', [$this, 'shortcodes_page']);
        add_submenu_page('digjy-stores', __('Payout Ledger', 'digjy-stores'), __('Payout Ledger', 'digjy-stores'), 'manage_options', 'digjy-stores-ledger', [$this, 'ledger_page']);
        add_submenu_page('digjy-stores', __('Sync Center', 'digjy-stores'), __('Sync Center', 'digjy-stores'), 'manage_options', 'digjy-stores-sync', [$this, 'sync_page']);
        add_submenu_page('digjy-stores', __('Webhook Events', 'digjy-stores'), __('Webhook Events', 'digjy-stores'), 'manage_options', 'edit.php?post_type=digjy_webhook_event');
        add_submenu_page('digjy-stores', __('Orders', 'digjy-stores'), __('Orders', 'digjy-stores'), 'manage_options', 'edit.php?post_type=digjy_order');
        add_submenu_page('digjy-stores', __('Products', 'digjy-stores'), __('Products', 'digjy-stores'), 'manage_options', 'edit.php?post_type=digjy_product');
        add_submenu_page('digjy-stores', __('Stores', 'digjy-stores'), __('Stores', 'digjy-stores'), 'manage_options', 'edit.php?post_type=digjy_store');
    }

    public function register_settings() {
        register_setting('digjy_stores_settings_group', 'digjy_stores_settings', [$this, 'sanitize_settings']);
        add_settings_section('digjy_stores_api', __('API & Marketplace Configuration', 'digjy-stores'), '__return_false', 'digjy-stores');
        add_settings_section('digjy_stores_pages', __('Marketplace Page URLs', 'digjy-stores'), [$this, 'render_pages_section_intro'], 'digjy-stores');

        $text_fields = [
            'groq_api_key' => __('GROQ API Key', 'digjy-stores'),
            'crossmint_api_key' => __('Crossmint Server API Key', 'digjy-stores'),
            'crossmint_client_api_key' => __('Crossmint Client API Key (optional)', 'digjy-stores'),
            'crossmint_collection_locator' => __('Crossmint Collection Locator', 'digjy-stores'),
            'marketplace_wallet' => __('Marketplace Wallet / Treasury', 'digjy-stores'),
            'currency' => __('Solana / Crypto Currency', 'digjy-stores'),
            'card_currency' => __('Card Currency', 'digjy-stores'),
            'default_payment_method' => __('Default Payment Method', 'digjy-stores'),
            'webhook_secret' => __('Webhook Secret', 'digjy-stores'),
            'solana_rpc_url' => __('Solana RPC URL', 'digjy-stores'),
            'jsdelivr_github_owner' => __('jsDelivr GitHub Owner', 'digjy-stores'),
            'jsdelivr_github_repo' => __('jsDelivr GitHub Repository', 'digjy-stores'),
            'jsdelivr_github_branch' => __('jsDelivr GitHub Branch', 'digjy-stores'),
            'jsdelivr_github_token' => __('GitHub Token for jsDelivr Uploads', 'digjy-stores'),
            'jsdelivr_upload_folder' => __('jsDelivr Upload Folder', 'digjy-stores'),
        ];

        foreach ($text_fields as $key => $label) {
            add_settings_field($key, $label, [$this, 'render_text_field'], 'digjy-stores', 'digjy_stores_api', ['key' => $key]);
        }


        $page_fields = [
            'checkout_page_url' => __('Checkout Page URL', 'digjy-stores'),
            'thank_you_page_url' => __('Thank You For Purchase Page URL', 'digjy-stores'),
            'dig_list_page_url' => __('My Dig List Page URL', 'digjy-stores'),
            'recently_viewed_page_url' => __('Recently Viewed Page URL', 'digjy-stores'),
            'cart_page_url' => __('My Cart Page URL', 'digjy-stores'),
        ];
        foreach ($page_fields as $key => $label) {
            add_settings_field($key, $label, [$this, 'render_url_field'], 'digjy-stores', 'digjy_stores_pages', ['key' => $key]);
        }

        add_settings_field('crossmint_environment', __('Crossmint Environment', 'digjy-stores'), [$this, 'render_environment_field'], 'digjy-stores', 'digjy_stores_api');
        add_settings_field('marketplace_commission', __('Marketplace Commission %', 'digjy-stores'), [$this, 'render_number_field'], 'digjy-stores', 'digjy_stores_api', ['key' => 'marketplace_commission', 'min' => 0, 'max' => 100]);
        add_settings_field('seller_commission', __('Seller Commission %', 'digjy-stores'), [$this, 'render_number_field'], 'digjy-stores', 'digjy_stores_api', ['key' => 'seller_commission', 'min' => 0, 'max' => 100]);
        add_settings_field('download_expiry_days', __('Protected Download Expiry (days)', 'digjy-stores'), [$this, 'render_number_field'], 'digjy-stores', 'digjy_stores_api', ['key' => 'download_expiry_days', 'min' => 1, 'max' => 365]);
        add_settings_field('download_limit', __('Download Limit Per Paid Order', 'digjy-stores'), [$this, 'render_number_field'], 'digjy-stores', 'digjy_stores_api', ['key' => 'download_limit', 'min' => 1, 'max' => 100]);
        add_settings_field('auto_create_wallets', __('Auto Create Seller Wallets', 'digjy-stores'), [$this, 'render_checkbox_field'], 'digjy-stores', 'digjy_stores_api', ['key' => 'auto_create_wallets']);
        add_settings_field('shadow_dom_isolation', __('Isolation Mode: Shadow DOM', 'digjy-stores'), [$this, 'render_checkbox_field'], 'digjy-stores', 'digjy_stores_api', ['key' => 'shadow_dom_isolation']);
        add_settings_field('asset_detection_engine', __('Asset Detection Engine', 'digjy-stores'), [$this, 'render_checkbox_field'], 'digjy-stores', 'digjy_stores_api', ['key' => 'asset_detection_engine']);
        add_settings_field('wallet_chain_type', __('Wallet Chain Type', 'digjy-stores'), [$this, 'render_text_field'], 'digjy-stores', 'digjy_stores_api', ['key' => 'wallet_chain_type']);
    }

    public function sanitize_settings($input) {
        $output = Digjy_Stores::get_settings();
        foreach (['groq_api_key','crossmint_api_key','crossmint_client_api_key','crossmint_collection_locator','marketplace_wallet','currency','card_currency','default_payment_method','webhook_secret','solana_rpc_url','wallet_chain_type','jsdelivr_github_owner','jsdelivr_github_repo','jsdelivr_github_branch','jsdelivr_github_token','jsdelivr_upload_folder','checkout_page_url','thank_you_page_url','dig_list_page_url','recently_viewed_page_url','cart_page_url'] as $key) {
            $output[$key] = sanitize_text_field($input[$key] ?? '');
        }
        foreach (['checkout_page_url','thank_you_page_url','dig_list_page_url','recently_viewed_page_url','cart_page_url'] as $url_key) {
            $output[$url_key] = esc_url_raw($input[$url_key] ?? '');
        }
        $output['crossmint_environment'] = in_array(($input['crossmint_environment'] ?? 'production'), ['production', 'staging'], true) ? $input['crossmint_environment'] : 'production';
        $output['marketplace_commission'] = max(0, min(100, absint($input['marketplace_commission'] ?? 10)));
        $output['seller_commission'] = max(0, min(100, absint($input['seller_commission'] ?? 90)));
        $output['download_expiry_days'] = max(1, min(365, absint($input['download_expiry_days'] ?? 7)));
        $output['download_limit'] = max(1, min(100, absint($input['download_limit'] ?? 5)));
        $output['auto_create_wallets'] = empty($input['auto_create_wallets']) ? 0 : 1;
        $output['shadow_dom_isolation'] = empty($input['shadow_dom_isolation']) ? 0 : 1;
        $output['asset_detection_engine'] = empty($input['asset_detection_engine']) ? 0 : 1;

        if (($output['marketplace_commission'] + $output['seller_commission']) !== 100) {
            add_settings_error('digjy_stores_settings', 'commission_split', __('Marketplace and seller commissions must total 100%.', 'digjy-stores'));
        }
        return $output;
    }

    public function render_pages_section_intro() {
        echo '<p>' . esc_html__('Assign the public pages used by Digjy Stores. Add the matching shortcode to each page, then paste that page URL here.', 'digjy-stores') . '</p>';
        echo '<ul style="list-style:disc;margin-left:20px;">';
        echo '<li><code>[digjy_digital_checkout]</code> ' . esc_html__('for Checkout', 'digjy-stores') . '</li>';
        echo '<li><code>[digjy_thank_you_downloads]</code> ' . esc_html__('for Thank You / Downloads / Purchase Notes', 'digjy-stores') . '</li>';
        echo '<li><code>[digjy_dig_list]</code> ' . esc_html__('for My Dig List', 'digjy-stores') . '</li>';
        echo '<li><code>[digjy_recently_viewed]</code> ' . esc_html__('for Recently Viewed', 'digjy-stores') . '</li>';
        echo '<li><code>[digjy_cart]</code> ' . esc_html__('for My Cart', 'digjy-stores') . '</li>';
        echo '</ul>';
    }

    public function render_url_field($args) {
        $settings = Digjy_Stores::get_settings();
        $key = $args['key'];
        printf('<input type="url" class="regular-text" name="digjy_stores_settings[%1$s]" value="%2$s" placeholder="https://www.digjy.com/page-slug" />', esc_attr($key), esc_url($settings[$key] ?? ''));
    }

    public function render_text_field($args) {
        $settings = Digjy_Stores::get_settings();
        $key = $args['key'];
        printf('<input type="text" class="regular-text" name="digjy_stores_settings[%1$s]" value="%2$s" />', esc_attr($key), esc_attr($settings[$key] ?? ''));
    }

    public function render_number_field($args) {
        $settings = Digjy_Stores::get_settings();
        $key = $args['key'];
        printf('<input type="number" min="%1$d" max="%2$d" class="small-text" name="digjy_stores_settings[%3$s]" value="%4$s" />', (int) $args['min'], (int) $args['max'], esc_attr($key), esc_attr($settings[$key] ?? ''));
    }


    public function render_checkbox_field($args) {
        $settings = Digjy_Stores::get_settings();
        $key = $args['key'];
        printf('<label><input type="checkbox" name="digjy_stores_settings[%1$s]" value="1" %2$s /> %3$s</label>', esc_attr($key), checked(!empty($settings[$key]), true, false), esc_html__('Enabled', 'digjy-stores'));
        if ('shadow_dom_isolation' === $key) { echo '<p class="description">' . esc_html__('Renders Digjy shortcode UI inside a Shadow DOM boundary to prevent CSS bleed into Elementor headers, footers, templates, and theme styling.', 'digjy-stores') . '</p>'; }
        if ('asset_detection_engine' === $key) { echo '<p class="description">' . esc_html__('Keeps Digjy frontend assets registered and loads them only when Digjy shortcodes/widgets are rendered on the current page.', 'digjy-stores') . '</p>'; }
    }

    public function render_environment_field() {
        $settings = Digjy_Stores::get_settings();
        $env = $settings['crossmint_environment'] ?? 'production';
        ?>
        <select name="digjy_stores_settings[crossmint_environment]">
            <option value="production" <?php selected($env, 'production'); ?>><?php esc_html_e('Production', 'digjy-stores'); ?></option>
            <option value="staging" <?php selected($env, 'staging'); ?>><?php esc_html_e('Staging', 'digjy-stores'); ?></option>
        </select>
        <?php
    }

    public function sync_page() {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('You do not have permission to access this page.', 'digjy-stores'));
        }
        $recent_orders = get_posts(['post_type' => 'digjy_order', 'post_status' => 'publish', 'posts_per_page' => 15, 'orderby' => 'date', 'order' => 'DESC']);
        $recent_products = get_posts(['post_type' => 'digjy_product', 'post_status' => 'publish', 'posts_per_page' => 15, 'orderby' => 'date', 'order' => 'DESC']);
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('Digjy Stores Sync Center', 'digjy-stores'); ?></h1>
            <?php if (!empty($_GET['digjy_synced_orders'])) : ?>
                <div class="notice notice-success"><p><?php echo esc_html(sprintf(__('Synced %d orders from Crossmint.', 'digjy-stores'), absint($_GET['digjy_synced_orders']))); ?></p></div>
            <?php endif; ?>
            <p><?php esc_html_e('Use this page to manually refresh Crossmint order states and push the latest on-chain / delivery data back into your marketplace orders and products.', 'digjy-stores'); ?></p>
            <p><a class="button button-primary" href="<?php echo esc_url(admin_url('admin-post.php?action=digjy_sync_orders&_wpnonce=' . wp_create_nonce('digjy_sync_orders'))); ?>"><?php esc_html_e('Sync Recent Orders Now', 'digjy-stores'); ?></a></p>
            <h2><?php esc_html_e('Recent Products', 'digjy-stores'); ?></h2>
            <table class="widefat striped"><thead><tr><th><?php esc_html_e('Product', 'digjy-stores'); ?></th><th><?php esc_html_e('NFT Status', 'digjy-stores'); ?></th><th><?php esc_html_e('Action', 'digjy-stores'); ?></th></tr></thead><tbody>
            <?php foreach ($recent_products as $product) : ?>
                <tr>
                    <td><a href="<?php echo esc_url(get_edit_post_link($product->ID)); ?>"><?php echo esc_html($product->post_title); ?></a></td>
                    <td><?php echo esc_html(get_post_meta($product->ID, '_digjy_onchain_status', true) ?: __('Unknown', 'digjy-stores')); ?></td>
                    <td><a class="button" href="<?php echo esc_url(admin_url('admin-post.php?action=digjy_sync_product&product_id=' . $product->ID . '&_wpnonce=' . wp_create_nonce('digjy_sync_product_' . $product->ID))); ?>"><?php esc_html_e('Sync Product Metadata', 'digjy-stores'); ?></a></td>
                </tr>
            <?php endforeach; ?>
            </tbody></table>
            <h2 style="margin-top:24px;"><?php esc_html_e('Recent Orders', 'digjy-stores'); ?></h2>
            <table class="widefat striped"><thead><tr><th><?php esc_html_e('Order', 'digjy-stores'); ?></th><th><?php esc_html_e('Crossmint Order ID', 'digjy-stores'); ?></th><th><?php esc_html_e('Status', 'digjy-stores'); ?></th></tr></thead><tbody>
            <?php foreach ($recent_orders as $order) : ?>
                <tr>
                    <td><a href="<?php echo esc_url(get_edit_post_link($order->ID)); ?>"><?php echo esc_html($order->post_title); ?></a></td>
                    <td><code><?php echo esc_html(get_post_meta($order->ID, '_digjy_crossmint_order_id', true)); ?></code></td>
                    <td><?php echo esc_html(get_post_meta($order->ID, '_digjy_order_status', true)); ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody></table>
        </div>
        <?php
    }

    public function settings_page() {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('You do not have permission to access this page.', 'digjy-stores'));
        }
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('Digjy Stores Settings', 'digjy-stores'); ?></h1>
            <p><?php esc_html_e('Configure GROQ, Crossmint, commissions, embedded card checkout, Solana wallet signing support, webhook verification, wallet provisioning, and protected downloads.', 'digjy-stores'); ?></p>
            <p><strong><?php esc_html_e('Webhook URL:', 'digjy-stores'); ?></strong> <code><?php echo esc_html(rest_url('digjy-stores/v1/crossmint-webhook')); ?></code></p>
            <p><strong><?php esc_html_e('Recommended defaults:', 'digjy-stores'); ?></strong> <code>default_payment_method=solana</code>, <code>currency=sol</code>, <code>card_currency=usd</code>, <code>wallet_chain_type=solana</code></p><p><strong><?php esc_html_e('jsDelivr uploads:', 'digjy-stores'); ?></strong> <?php esc_html_e('Use a public GitHub repository. Digjy Stores uploads files to GitHub through the Contents API, then serves them from jsDelivr.', 'digjy-stores'); ?></p>
            <form method="post" action="options.php">
                <?php settings_fields('digjy_stores_settings_group'); do_settings_sections('digjy-stores'); submit_button(); ?>
            </form>
        </div>
        <?php
    }

    public function shortcodes_page() {
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('Digjy Stores Shortcodes', 'digjy-stores'); ?></h1>
            <div class="card" style="max-width:1000px;padding:20px;">
                <p><code>[digjy_buy_now product_id="123" label="Buy Now"]</code> — <?php esc_html_e('Displays a Buy Now button for a digital product.', 'digjy-stores'); ?></p>
                <p><code>[digjy_digital_checkout product_id="123"]</code> — <?php esc_html_e('Displays the card vs Solana checkout form with payment status UI.', 'digjy-stores'); ?></p>
                <p><code>[digjy_vendor_dashboard]</code> — <?php esc_html_e('Displays the seller dashboard with products, earnings, orders, and frontend product management.', 'digjy-stores'); ?></p>
                <p><code>[digjy_current_store_url]</code> — <?php esc_html_e("Displays the current logged-in store owner's store URL.", 'digjy-stores'); ?></p>
                <p><code>[digjy_store_list]</code> — <?php esc_html_e('Displays public seller stores.', 'digjy-stores'); ?></p>
                <p><code>[digjy_seller_register]</code> — <?php esc_html_e('Displays the free seller registration form.', 'digjy-stores'); ?></p>
                <p><code>[digjy_customer_downloads]</code> — <?php esc_html_e('Displays paid customer downloads when available.', 'digjy-stores'); ?></p>
                <p><code>[digjy_product_price product_id="123" currency_symbol="$"]</code> — <?php esc_html_e('Displays the product price.', 'digjy-stores'); ?></p>
                <p><code>[digjy_nft_info product_id="123" type="all"]</code> — <?php esc_html_e('Displays NFT asset metadata for lazy-minted and minted assets.', 'digjy-stores'); ?></p>
                <p><code>[digjy_nft_lazy_data product_id="123"]</code> — <?php esc_html_e('Displays lazy mint NFT data.', 'digjy-stores'); ?></p>
                <p><code>[digjy_nft_minted_data product_id="123"]</code> — <?php esc_html_e('Displays minted NFT data.', 'digjy-stores'); ?></p>
                <p><code>[digjy_crossmint_embedded_card product_id="123"]</code> — <?php esc_html_e("Creates a card order and mounts Crossmint's embedded checkout in existing-order mode.", 'digjy-stores'); ?></p>
                <p><code>[digjy_order_history]</code> — <?php esc_html_e('Displays customer-facing order history with live payment state refresh.', 'digjy-stores'); ?></p>
                <p><code>[digjy_digital_product_form]</code> — <?php esc_html_e('Regular digital product submission form with jsDelivr file upload.', 'digjy-stores'); ?></p>
                <p><code>[digjy_manage_products]</code> — <?php esc_html_e('Displays a grid of product cards for the current store owner with View, Edit, and Delete actions.', 'digjy-stores'); ?></p>
            </div>
        </div>
        <?php
    }

    public function ledger_page() {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('You do not have permission to access this page.', 'digjy-stores'));
        }
        $orders = get_posts([
            'post_type' => 'digjy_order',
            'post_status' => 'publish',
            'posts_per_page' => 200,
            'meta_key' => '_digjy_order_status',
            'meta_value' => 'paid',
        ]);
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('Payout Ledger', 'digjy-stores'); ?></h1>
            <p><a class="button button-primary" href="<?php echo esc_url(add_query_arg('digjy_export_ledger', '1', admin_url('admin.php?page=digjy-stores-ledger'))); ?>"><?php esc_html_e('Export CSV', 'digjy-stores'); ?></a></p>
            <table class="widefat striped">
                <thead><tr><th><?php esc_html_e('Order', 'digjy-stores'); ?></th><th><?php esc_html_e('Seller', 'digjy-stores'); ?></th><th><?php esc_html_e('Seller Amount', 'digjy-stores'); ?></th><th><?php esc_html_e('Marketplace Amount', 'digjy-stores'); ?></th><th><?php esc_html_e('Status', 'digjy-stores'); ?></th></tr></thead>
                <tbody>
                <?php foreach ($orders as $order) : ?>
                    <tr>
                        <td><?php echo esc_html($order->post_title); ?></td>
                        <td><?php echo esc_html(get_the_author_meta('display_name', (int) get_post_meta($order->ID, '_digjy_seller_id', true))); ?></td>
                        <td><?php echo esc_html(number_format((float) get_post_meta($order->ID, '_digjy_seller_amount', true), 2)); ?></td>
                        <td><?php echo esc_html(number_format((float) get_post_meta($order->ID, '_digjy_marketplace_amount', true), 2)); ?></td>
                        <td><?php echo esc_html(get_post_meta($order->ID, '_digjy_payout_status', true) ?: 'unpaid'); ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php

        if (isset($_GET['digjy_export_ledger'])) {
            $this->export_ledger_csv($orders);
        }
    }

    private function export_ledger_csv($orders) {
        if (headers_sent()) {
            return;
        }
        digjy_stores_clean_output_buffers();
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="digjy-payout-ledger.csv"');
        $out = fopen('php://output', 'w');
        fputcsv($out, ['Order ID', 'Order Title', 'Seller ID', 'Seller', 'Seller Amount', 'Marketplace Amount', 'Payout Status']);
        foreach ($orders as $order) {
            $seller_id = (int) get_post_meta($order->ID, '_digjy_seller_id', true);
            fputcsv($out, [
                $order->ID,
                $order->post_title,
                $seller_id,
                get_the_author_meta('display_name', $seller_id),
                get_post_meta($order->ID, '_digjy_seller_amount', true),
                get_post_meta($order->ID, '_digjy_marketplace_amount', true),
                get_post_meta($order->ID, '_digjy_payout_status', true) ?: 'unpaid',
            ]);
        }
        fclose($out);
        exit;
    }
}
