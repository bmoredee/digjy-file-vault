<?php
if (!defined('ABSPATH')) {
    exit;
}

class Digjy_Stores_Products {
    public function __construct() {
        add_action('init', [__CLASS__, 'register_post_types']);
        add_action('add_meta_boxes', [$this, 'register_meta_boxes']);
        add_action('save_post_digjy_product', [$this, 'save_product_meta']);
        add_filter('manage_digjy_product_posts_columns', [$this, 'columns']);
        add_action('manage_digjy_product_posts_custom_column', [$this, 'column_content'], 10, 2);
        add_filter('pre_get_posts', [$this, 'limit_vendor_product_queries']);
    }

    public static function register_post_types() {
        register_post_type('digjy_product', [
            'labels' => ['name' => __('Digital Products', 'digjy-stores'), 'singular_name' => __('Digital Product', 'digjy-stores')],
            'public' => true,
            'show_in_menu' => true,
            'supports' => ['title', 'editor', 'thumbnail', 'author', 'excerpt'],
            'rewrite' => ['slug' => 'digital-product'],
            'has_archive' => true,
            'show_in_rest' => true,
            'map_meta_cap' => true,
        ]);
        register_taxonomy('digjy_product_category', 'digjy_product', [
            'labels' => ['name' => __('Product Categories', 'digjy-stores'), 'singular_name' => __('Product Category', 'digjy-stores')],
            'public' => true,
            'hierarchical' => true,
            'show_ui' => true,
            'show_admin_column' => true,
            'show_in_rest' => true,
            'rewrite' => ['slug' => 'digital-product-category'],
        ]);
        register_taxonomy_for_object_type('post_tag', 'digjy_product');

        $default_terms = ['Templates', 'Ebooks', 'Graphics', 'Marketing', 'Courses'];
        foreach ($default_terms as $term_name) {
            if (!term_exists($term_name, 'digjy_product_category')) {
                wp_insert_term($term_name, 'digjy_product_category');
            }
        }

        register_post_type('digjy_order', [
            'labels' => ['name' => __('Digjy Orders', 'digjy-stores'), 'singular_name' => __('Digjy Order', 'digjy-stores')],
            'public' => false,
            'show_ui' => true,
            'show_in_menu' => false,
            'supports' => ['title'],
            'capability_type' => 'post',
            'map_meta_cap' => true,
        ]);
    }

    public function limit_vendor_product_queries($query) {
        if (!is_admin() || !$query->is_main_query()) {
            return;
        }
        global $pagenow;
        if ('edit.php' !== $pagenow || 'digjy_product' !== $query->get('post_type')) {
            return;
        }
        if (current_user_can('manage_options')) {
            return;
        }
        if (current_user_can('edit_posts')) {
            $query->set('author', get_current_user_id());
        }
    }

    public function register_meta_boxes() {
        add_meta_box('digjy_product_details', __('Product Details', 'digjy-stores'), [$this, 'product_details_meta_box'], 'digjy_product', 'normal', 'high');
    }

    public function product_details_meta_box($post) {
        wp_nonce_field('digjy_product_meta', 'digjy_product_meta_nonce');
        $meta = self::get_asset_meta($post->ID);
        ?>
        <div class="digjy-meta-grid">
            <p><label><strong><?php esc_html_e('Product Type', 'digjy-stores'); ?></strong></label><br />
            <select name="digjy_product_type">
                <option value="regular" <?php selected($meta['product_type'], 'regular'); ?>><?php esc_html_e('Regular Digital Product', 'digjy-stores'); ?></option>
                <option value="minted_digital" <?php selected($meta['product_type'], 'minted_digital'); ?>><?php esc_html_e('Mint Digital Product', 'digjy-stores'); ?></option>
            </select>
            </p>
            <p><label><strong><?php esc_html_e('Price', 'digjy-stores'); ?></strong></label><br /><input type="number" step="0.01" min="0" name="digjy_price" value="<?php echo esc_attr($meta['price']); ?>" class="regular-text" /></p>
            <p><label><strong><?php esc_html_e('Secure Download URL', 'digjy-stores'); ?></strong></label><br /><input type="url" name="digjy_file_url" value="<?php echo esc_attr($meta['file_url']); ?>" class="widefat" /></p>
            <p><label><strong><?php esc_html_e('SKU', 'digjy-stores'); ?></strong></label><br /><input type="text" name="digjy_sku" value="<?php echo esc_attr($meta['sku']); ?>" class="regular-text" /></p>
            <p><label><strong><?php esc_html_e('License / Terms', 'digjy-stores'); ?></strong></label><br /><textarea name="digjy_license" class="widefat" rows="4"><?php echo esc_textarea($meta['license']); ?></textarea></p>
            <hr />
            <h3><?php esc_html_e('Crossmint / NFT Data', 'digjy-stores'); ?></h3>
            <p><label><strong><?php esc_html_e('Asset Mode', 'digjy-stores'); ?></strong></label><br />
                <select name="digjy_asset_mode">
                    <option value="lazy_minted" <?php selected($meta['asset_mode'], 'lazy_minted'); ?>><?php esc_html_e('Lazy Minted', 'digjy-stores'); ?></option>
                    <option value="minted" <?php selected($meta['asset_mode'], 'minted'); ?>><?php esc_html_e('Already Minted', 'digjy-stores'); ?></option>
                    <option value="both" <?php selected($meta['asset_mode'], 'both'); ?>><?php esc_html_e('Supports Both', 'digjy-stores'); ?></option>
                </select>
            </p>
            <p><label><strong><?php esc_html_e('Chain', 'digjy-stores'); ?></strong></label><br /><input type="text" name="digjy_chain" value="<?php echo esc_attr($meta['chain']); ?>" class="regular-text" placeholder="solana" /></p>
            <p><label><strong><?php esc_html_e('Collection Locator', 'digjy-stores'); ?></strong></label><br /><input type="text" name="digjy_collection_locator" value="<?php echo esc_attr($meta['collection_locator']); ?>" class="widefat" /></p>
            <p><label><strong><?php esc_html_e('Token ID', 'digjy-stores'); ?></strong></label><br /><input type="text" name="digjy_token_id" value="<?php echo esc_attr($meta['token_id']); ?>" class="regular-text" /></p>
            <p><label><strong><?php esc_html_e('Contract / Mint Address', 'digjy-stores'); ?></strong></label><br /><input type="text" name="digjy_contract_address" value="<?php echo esc_attr($meta['contract_address']); ?>" class="widefat" /></p>
            <p><label><strong><?php esc_html_e('Owner Wallet', 'digjy-stores'); ?></strong></label><br /><input type="text" name="digjy_owner" value="<?php echo esc_attr($meta['owner']); ?>" class="widefat" /></p>
            <p><label><strong><?php esc_html_e('Transaction ID', 'digjy-stores'); ?></strong></label><br /><input type="text" name="digjy_txid" value="<?php echo esc_attr($meta['txid']); ?>" class="widefat" /></p>
            <p><label><strong><?php esc_html_e('On-chain Status', 'digjy-stores'); ?></strong></label><br /><input type="text" name="digjy_onchain_status" value="<?php echo esc_attr($meta['onchain_status']); ?>" class="regular-text" placeholder="pending / success" /></p>
            <p><label><strong><?php esc_html_e('Recipient Wallet', 'digjy-stores'); ?></strong></label><br /><input type="text" name="digjy_recipient_wallet" value="<?php echo esc_attr($meta['recipient_wallet']); ?>" class="widefat" /></p>
            <p><label><strong><?php esc_html_e('Metadata URI', 'digjy-stores'); ?></strong></label><br /><input type="url" name="digjy_metadata_uri" value="<?php echo esc_attr($meta['metadata_uri']); ?>" class="widefat" /></p>
            <p><label><strong><?php esc_html_e('Royalty Percent', 'digjy-stores'); ?></strong></label><br /><input type="number" step="0.01" min="0" max="100" name="digjy_royalty_percent" value="<?php echo esc_attr($meta['royalty_percent']); ?>" class="regular-text" /></p>
            <p><label><strong><?php esc_html_e('Royalty Recipient Wallet', 'digjy-stores'); ?></strong></label><br /><input type="text" name="digjy_royalty_recipient" value="<?php echo esc_attr($meta['royalty_recipient']); ?>" class="widefat" /></p>
            <p><label><strong><?php esc_html_e('Buyer Creator Royalty Percent', 'digjy-stores'); ?></strong></label><br /><input type="number" step="1" min="0" max="100" name="digjy_buyer_creator_royalty_percent" value="<?php echo esc_attr($meta['buyer_creator_royalty_percent']); ?>" class="regular-text" /></p>
            <p><label><strong><?php esc_html_e('NFT Template ID', 'digjy-stores'); ?></strong></label><br /><input type="text" name="digjy_nft_template_id" value="<?php echo esc_attr($meta['nft_template_id']); ?>" class="regular-text" /></p>
            <p><label><strong><?php esc_html_e('NFT Name', 'digjy-stores'); ?></strong></label><br /><input type="text" name="digjy_nft_name" value="<?php echo esc_attr($meta['nft_name']); ?>" class="regular-text" /></p>
            <p><label><strong><?php esc_html_e('NFT Symbol', 'digjy-stores'); ?></strong></label><br /><input type="text" name="digjy_nft_symbol" value="<?php echo esc_attr($meta['nft_symbol']); ?>" class="regular-text" /></p>
            <p><label><strong><?php esc_html_e('NFT Image URL', 'digjy-stores'); ?></strong></label><br /><input type="url" name="digjy_nft_image" value="<?php echo esc_attr($meta['nft_image']); ?>" class="widefat" /></p>
            <p><label><strong><?php esc_html_e('NFT Supply', 'digjy-stores'); ?></strong></label><br /><input type="number" step="1" min="1" name="digjy_nft_supply" value="<?php echo esc_attr($meta['nft_supply']); ?>" class="regular-text" /></p>
            <p><label><strong><?php esc_html_e('Last Synced From Crossmint', 'digjy-stores'); ?></strong></label><br /><input type="text" readonly value="<?php echo esc_attr($meta['last_synced_at']); ?>" class="regular-text" /></p>
            <p><a class="button" href="<?php echo esc_url(admin_url('admin-post.php?action=digjy_sync_product&product_id=' . $post->ID . '&_wpnonce=' . wp_create_nonce('digjy_sync_product_' . $post->ID))); ?>"><?php esc_html_e('Sync Product Metadata From Orders', 'digjy-stores'); ?></a></p>
        </div>
        <?php
    }

    public function save_product_meta($post_id) {
        if (!isset($_POST['digjy_product_meta_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['digjy_product_meta_nonce'])), 'digjy_product_meta')) {
            return;
        }
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }

        $map = [
            '_digjy_product_type' => isset($_POST['digjy_product_type']) && sanitize_key(wp_unslash($_POST['digjy_product_type'])) === 'minted_digital' ? 'minted_digital' : 'regular',
            '_digjy_price' => isset($_POST['digjy_price']) ? (float) $_POST['digjy_price'] : 0,
            '_digjy_file_url' => isset($_POST['digjy_file_url']) ? esc_url_raw(wp_unslash($_POST['digjy_file_url'])) : '',
            '_digjy_license' => isset($_POST['digjy_license']) ? sanitize_textarea_field(wp_unslash($_POST['digjy_license'])) : '',
            '_digjy_sku' => isset($_POST['digjy_sku']) ? sanitize_text_field(wp_unslash($_POST['digjy_sku'])) : '',
            '_digjy_asset_mode' => isset($_POST['digjy_asset_mode']) ? sanitize_text_field(wp_unslash($_POST['digjy_asset_mode'])) : 'lazy_minted',
            '_digjy_chain' => isset($_POST['digjy_chain']) ? sanitize_text_field(wp_unslash($_POST['digjy_chain'])) : 'solana',
            '_digjy_collection_locator' => isset($_POST['digjy_collection_locator']) ? sanitize_text_field(wp_unslash($_POST['digjy_collection_locator'])) : '',
            '_digjy_token_id' => isset($_POST['digjy_token_id']) ? sanitize_text_field(wp_unslash($_POST['digjy_token_id'])) : '',
            '_digjy_contract_address' => isset($_POST['digjy_contract_address']) ? sanitize_text_field(wp_unslash($_POST['digjy_contract_address'])) : '',
            '_digjy_owner' => isset($_POST['digjy_owner']) ? sanitize_text_field(wp_unslash($_POST['digjy_owner'])) : '',
            '_digjy_txid' => isset($_POST['digjy_txid']) ? sanitize_text_field(wp_unslash($_POST['digjy_txid'])) : '',
            '_digjy_onchain_status' => isset($_POST['digjy_onchain_status']) ? sanitize_text_field(wp_unslash($_POST['digjy_onchain_status'])) : '',
            '_digjy_recipient_wallet' => isset($_POST['digjy_recipient_wallet']) ? sanitize_text_field(wp_unslash($_POST['digjy_recipient_wallet'])) : '',
            '_digjy_metadata_uri' => isset($_POST['digjy_metadata_uri']) ? esc_url_raw(wp_unslash($_POST['digjy_metadata_uri'])) : '',
            '_digjy_royalty_percent' => isset($_POST['digjy_royalty_percent']) ? (float) $_POST['digjy_royalty_percent'] : 0,
            '_digjy_royalty_recipient' => isset($_POST['digjy_royalty_recipient']) ? sanitize_text_field(wp_unslash($_POST['digjy_royalty_recipient'])) : '',
            '_digjy_buyer_creator_royalty_percent' => isset($_POST['digjy_buyer_creator_royalty_percent']) ? absint($_POST['digjy_buyer_creator_royalty_percent']) : 0,
            '_digjy_nft_template_id' => isset($_POST['digjy_nft_template_id']) ? sanitize_text_field(wp_unslash($_POST['digjy_nft_template_id'])) : '',
            '_digjy_nft_name' => isset($_POST['digjy_nft_name']) ? sanitize_text_field(wp_unslash($_POST['digjy_nft_name'])) : '',
            '_digjy_nft_symbol' => isset($_POST['digjy_nft_symbol']) ? sanitize_text_field(wp_unslash($_POST['digjy_nft_symbol'])) : '',
            '_digjy_nft_image' => isset($_POST['digjy_nft_image']) ? esc_url_raw(wp_unslash($_POST['digjy_nft_image'])) : '',
            '_digjy_nft_supply' => isset($_POST['digjy_nft_supply']) ? absint($_POST['digjy_nft_supply']) : 1,
        ];
        foreach ($map as $key => $value) {
            update_post_meta($post_id, $key, $value);
        }
    }

    public function columns($columns) {
        $columns['product_type'] = __('Product Type', 'digjy-stores');
        $columns['price'] = __('Price', 'digjy-stores');
        $columns['sku'] = __('SKU', 'digjy-stores');
        $columns['asset_mode'] = __('Asset Mode', 'digjy-stores');
        return $columns;
    }

    public function column_content($column, $post_id) {
        if ('product_type' === $column) {
            echo esc_html(get_post_meta($post_id, '_digjy_product_type', true) ?: 'regular');
        }
        if ('price' === $column) {
            echo esc_html(get_post_meta($post_id, '_digjy_price', true));
        }
        if ('sku' === $column) {
            echo esc_html(get_post_meta($post_id, '_digjy_sku', true));
        }
        if ('asset_mode' === $column) {
            echo esc_html(get_post_meta($post_id, '_digjy_asset_mode', true));
        }
    }

    public static function get_price($product_id) {
        return (float) get_post_meta($product_id, '_digjy_price', true);
    }

    public static function get_asset_meta($product_id) {
        return [
            'product_type' => get_post_meta($product_id, '_digjy_product_type', true) ?: 'regular',
            'price' => get_post_meta($product_id, '_digjy_price', true),
            'file_url' => get_post_meta($product_id, '_digjy_file_url', true),
            'license' => get_post_meta($product_id, '_digjy_license', true),
            'sku' => get_post_meta($product_id, '_digjy_sku', true),
            'asset_mode' => get_post_meta($product_id, '_digjy_asset_mode', true) ?: 'lazy_minted',
            'chain' => get_post_meta($product_id, '_digjy_chain', true) ?: 'solana',
            'collection_locator' => get_post_meta($product_id, '_digjy_collection_locator', true),
            'token_id' => get_post_meta($product_id, '_digjy_token_id', true),
            'contract_address' => get_post_meta($product_id, '_digjy_contract_address', true),
            'owner' => get_post_meta($product_id, '_digjy_owner', true),
            'txid' => get_post_meta($product_id, '_digjy_txid', true),
            'onchain_status' => get_post_meta($product_id, '_digjy_onchain_status', true),
            'recipient_wallet' => get_post_meta($product_id, '_digjy_recipient_wallet', true),
            'metadata_uri' => get_post_meta($product_id, '_digjy_metadata_uri', true),
            'royalty_percent' => get_post_meta($product_id, '_digjy_royalty_percent', true),
            'royalty_recipient' => get_post_meta($product_id, '_digjy_royalty_recipient', true),
            'buyer_creator_royalty_percent' => get_post_meta($product_id, '_digjy_buyer_creator_royalty_percent', true),
            'nft_template_id' => get_post_meta($product_id, '_digjy_nft_template_id', true),
            'nft_name' => get_post_meta($product_id, '_digjy_nft_name', true),
            'nft_symbol' => get_post_meta($product_id, '_digjy_nft_symbol', true),
            'nft_image' => get_post_meta($product_id, '_digjy_nft_image', true),
            'nft_supply' => get_post_meta($product_id, '_digjy_nft_supply', true) ?: 1,
            'last_synced_at' => get_post_meta($product_id, '_digjy_last_synced_at', true),
            'proof_type' => get_post_meta($product_id, '_digjy_proof_type', true),
            'wallet_provider' => get_post_meta($product_id, '_digjy_wallet_provider', true),
            'wallet_address' => get_post_meta($product_id, '_digjy_wallet_address', true),
            'admin_fee' => get_post_meta($product_id, '_digjy_admin_fee', true),
        ];
    }
}
