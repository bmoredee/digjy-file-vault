<?php
if (!defined('ABSPATH')) {
    exit;
}

class Digjy_Stores_Sync {
    private $checkout;

    public function __construct($checkout) {
        $this->checkout = $checkout;
        add_action('init', [__CLASS__, 'register_post_types']);
        add_action('admin_post_digjy_sync_orders', [$this, 'handle_sync_orders']);
        add_action('admin_post_digjy_sync_product', [$this, 'handle_sync_product']);
        add_action('digjy_stores_hourly_sync', [$this, 'run_scheduled_sync']);
    }

    public static function register_post_types() {
        register_post_type('digjy_webhook_event', [
            'labels' => ['name' => __('Webhook Events', 'digjy-stores'), 'singular_name' => __('Webhook Event', 'digjy-stores')],
            'public' => false,
            'show_ui' => true,
            'show_in_menu' => false,
            'supports' => ['title'],
            'capability_type' => 'post',
            'map_meta_cap' => true,
        ]);
    }

    public static function schedule() {
        if (!wp_next_scheduled('digjy_stores_hourly_sync')) {
            wp_schedule_event(time() + 300, 'hourly', 'digjy_stores_hourly_sync');
        }
    }

    public static function unschedule() {
        $timestamp = wp_next_scheduled('digjy_stores_hourly_sync');
        if ($timestamp) {
            wp_unschedule_event($timestamp, 'digjy_stores_hourly_sync');
        }
    }

    public static function log_webhook_event($event_type, $payload, $verified = true, $matched_order_id = 0) {
        $title = sprintf('%s — %s', sanitize_text_field($event_type ?: 'crossmint.event'), current_time('mysql'));
        $post_id = wp_insert_post([
            'post_type' => 'digjy_webhook_event',
            'post_status' => 'publish',
            'post_title' => $title,
        ]);
        if ($post_id && !is_wp_error($post_id)) {
            update_post_meta($post_id, '_digjy_event_type', sanitize_text_field($event_type ?: 'crossmint.event'));
            update_post_meta($post_id, '_digjy_event_verified', $verified ? 1 : 0);
            update_post_meta($post_id, '_digjy_event_matched_order', absint($matched_order_id));
            update_post_meta($post_id, '_digjy_event_payload', wp_json_encode($payload));
        }
        return $post_id;
    }

    public function run_scheduled_sync() {
        $orders = get_posts([
            'post_type' => 'digjy_order',
            'post_status' => 'publish',
            'posts_per_page' => 25,
            'orderby' => 'date',
            'order' => 'DESC',
            'meta_query' => [
                [
                    'key' => '_digjy_crossmint_order_id',
                    'compare' => 'EXISTS',
                ],
            ],
        ]);
        foreach ($orders as $order) {
            $this->checkout->sync_order_with_crossmint($order->ID, true);
        }
    }

    public function handle_sync_orders() {
        if (!current_user_can('manage_options') || !wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['_wpnonce'] ?? '')), 'digjy_sync_orders')) {
            wp_die(esc_html__('Invalid request.', 'digjy-stores'));
        }
        $count = 0;
        $orders = get_posts([
            'post_type' => 'digjy_order',
            'post_status' => 'publish',
            'posts_per_page' => 100,
            'orderby' => 'date',
            'order' => 'DESC',
            'meta_query' => [[ 'key' => '_digjy_crossmint_order_id', 'compare' => 'EXISTS' ]],
        ]);
        foreach ($orders as $order) {
            $result = $this->checkout->sync_order_with_crossmint($order->ID, true);
            if (!is_wp_error($result)) {
                $count++;
            }
        }
        wp_safe_redirect(add_query_arg('digjy_synced_orders', $count, admin_url('admin.php?page=digjy-stores-sync')));
        exit;
    }

    public function handle_sync_product() {
        $product_id = isset($_GET['product_id']) ? absint($_GET['product_id']) : 0;
        if (!$product_id || !current_user_can('edit_post', $product_id) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['_wpnonce'] ?? '')), 'digjy_sync_product_' . $product_id)) {
            wp_die(esc_html__('Invalid request.', 'digjy-stores'));
        }
        $result = $this->checkout->sync_product_from_related_orders($product_id);
        $redirect = admin_url('post.php?post=' . $product_id . '&action=edit');
        if (is_wp_error($result)) {
            $redirect = add_query_arg('digjy_sync_error', rawurlencode($result->get_error_message()), $redirect);
        } else {
            $redirect = add_query_arg('digjy_product_synced', '1', $redirect);
        }
        wp_safe_redirect($redirect);
        exit;
    }
}
