<?php
if (!defined('ABSPATH')) {
    exit;
}

class Digjy_Stores_Checkout {
    public function __construct() {
        add_action('wp_ajax_digjy_create_checkout', [$this, 'ajax_create_checkout']);
        add_action('wp_ajax_nopriv_digjy_create_checkout', [$this, 'ajax_create_checkout']);
        add_action('wp_ajax_digjy_get_checkout_status', [$this, 'ajax_get_checkout_status']);
        add_action('wp_ajax_nopriv_digjy_get_checkout_status', [$this, 'ajax_get_checkout_status']);
        add_action('wp_ajax_digjy_mark_order_paid', [$this, 'ajax_mark_order_paid']);
        add_action('wp_ajax_digjy_record_wallet_tx', [$this, 'ajax_record_wallet_tx']);
        add_action('wp_ajax_nopriv_digjy_record_wallet_tx', [$this, 'ajax_record_wallet_tx']);
        add_action('init', [$this, 'handle_secure_download']);
        add_action('admin_post_digjy_mark_order_paid', [$this, 'handle_admin_mark_order_paid']);
        add_action('rest_api_init', [__CLASS__, 'register_webhook_endpoint']);
        add_action('add_meta_boxes', [$this, 'register_order_meta_box']);
        add_filter('manage_digjy_order_posts_columns', [$this, 'order_columns']);
        add_action('manage_digjy_order_posts_custom_column', [$this, 'order_column_content'], 10, 2);
    }

    public static function register_download_endpoint() {}

    public static function register_webhook_endpoint() {
        register_rest_route('digjy-stores/v1', '/crossmint-webhook', [
            'methods' => 'POST',
            'callback' => [__CLASS__, 'handle_crossmint_webhook'],
            'permission_callback' => '__return_true',
        ]);
    }

    public function register_order_meta_box() {
        add_meta_box('digjy_order_details', __('Digjy Order Details', 'digjy-stores'), [$this, 'order_meta_box'], 'digjy_order', 'normal', 'high');
    }

    public function order_columns($columns) {
        $columns['buyer_email'] = __('Buyer', 'digjy-stores');
        $columns['status'] = __('Status', 'digjy-stores');
        return $columns;
    }

    public function order_column_content($column, $post_id) {
        if ('buyer_email' === $column) echo esc_html(get_post_meta($post_id, '_digjy_buyer_email', true));
        if ('status' === $column) echo esc_html(get_post_meta($post_id, '_digjy_order_status', true));
    }

    public function order_meta_box($post) {
        $download_url = $this->get_download_url($post->ID); ?>
        <p><strong><?php esc_html_e('Crossmint Order ID:', 'digjy-stores'); ?></strong> <?php echo esc_html(get_post_meta($post->ID, '_digjy_crossmint_order_id', true)); ?></p>
        <p><strong><?php esc_html_e('Buyer Email:', 'digjy-stores'); ?></strong> <?php echo esc_html(get_post_meta($post->ID, '_digjy_buyer_email', true)); ?></p>
        <p><strong><?php esc_html_e('Payment Method:', 'digjy-stores'); ?></strong> <?php echo esc_html(get_post_meta($post->ID, '_digjy_payment_method', true)); ?></p>
        <p><strong><?php esc_html_e('Status:', 'digjy-stores'); ?></strong> <?php echo esc_html(get_post_meta($post->ID, '_digjy_order_status', true)); ?></p>
        <p><strong><?php esc_html_e('Status Label:', 'digjy-stores'); ?></strong> <?php echo esc_html(get_post_meta($post->ID, '_digjy_status_label', true)); ?></p>
        <p><strong><?php esc_html_e('Download URL:', 'digjy-stores'); ?></strong> <?php echo $download_url ? '<a href="' . esc_url($download_url) . '">' . esc_html($download_url) . '</a>' : esc_html__('Not generated yet.', 'digjy-stores'); ?></p>
        <p><strong><?php esc_html_e('Download Count:', 'digjy-stores'); ?></strong> <?php echo esc_html((string) get_post_meta($post->ID, '_digjy_download_count', true)); ?></p>
        <p><a class="button button-primary" href="<?php echo esc_url(admin_url('admin-post.php?action=digjy_mark_order_paid&order_id=' . $post->ID . '&_wpnonce=' . wp_create_nonce('digjy_mark_order_paid_' . $post->ID))); ?>"><?php esc_html_e('Mark Order Paid + Generate Download', 'digjy-stores'); ?></a></p>
        <?php
    }

    public function ajax_create_checkout() {
        check_ajax_referer('digjy_stores_nonce', 'nonce');
        $product_id = isset($_POST['product_id']) ? absint($_POST['product_id']) : 0;
        $buyer_email = sanitize_email($_POST['buyer_email'] ?? '');
        $payer_address = sanitize_text_field($_POST['payer_address'] ?? '');
        $payment_method = sanitize_text_field($_POST['payment_method'] ?? '');
        $recipient_wallet = sanitize_text_field($_POST['recipient_wallet'] ?? '');

        if (!$product_id || !$buyer_email) {
            wp_send_json_error(['message' => __('Missing required checkout data.', 'digjy-stores')], 400);
        }
        $product = get_post($product_id);
        if (!$product || 'digjy_product' !== $product->post_type) {
            wp_send_json_error(['message' => __('Product not found.', 'digjy-stores')], 404);
        }
        $settings = Digjy_Stores::get_settings();
        if (empty($settings['crossmint_api_key'])) {
            wp_send_json_error(['message' => __('Crossmint API key is not configured.', 'digjy-stores')], 400);
        }

        $payment_method = $payment_method ?: ($settings['default_payment_method'] ?: 'solana');
        $normalized_method = $payment_method === 'card' ? 'card' : 'solana';
        if ($normalized_method === 'solana' && empty($payer_address)) {
            wp_send_json_error(['message' => __('Solana wallet address is required for Solana payments.', 'digjy-stores')], 400);
        }

        $price = Digjy_Stores_Products::get_price($product_id);
        $commissions = $this->calculate_commissions($price);
        $seller_id = (int) $product->post_author;
        $seller_wallet = get_user_meta($seller_id, 'digjy_seller_wallet', true);
        $asset = Digjy_Stores_Products::get_asset_meta($product_id);

        $payment_object = [
            'method' => $normalized_method,
            'currency' => $normalized_method === 'card' ? strtolower($settings['card_currency'] ?: 'usd') : strtolower($settings['currency'] ?: 'sol'),
            'receiptEmail' => $buyer_email,
        ];
        if ($normalized_method === 'solana') {
            $payment_object['payerAddress'] = $payer_address;
        }

        $recipient = ['email' => $buyer_email];
        if (!empty($recipient_wallet)) {
            $recipient['walletAddress'] = $recipient_wallet;
        }

        $payload = [
            'payment' => $payment_object,
            'lineItems' => [[
                'collectionLocator' => $asset['collection_locator'] ?: $settings['crossmint_collection_locator'],
                'callData' => [
                    'totalPrice' => (string) $price,
                    'productId' => $product_id,
                    'sellerWallet' => $seller_wallet,
                    'marketplaceWallet' => $settings['marketplace_wallet'],
                    'chain' => $asset['chain'] ?: 'solana',
                    'tokenId' => $asset['token_id'],
                    'contractAddress' => $asset['contract_address'],
                    'metadataUri' => $asset['metadata_uri'],
                    'mintMode' => $asset['asset_mode'],
                ],
                'metadata' => [
                    'name' => $product->post_title,
                    'description' => wp_strip_all_tags($product->post_excerpt ?: wp_trim_words($product->post_content, 30)),
                    'imageUrl' => get_the_post_thumbnail_url($product_id, 'large') ?: '',
                    'sku' => $asset['sku'] ?? get_post_meta($product_id, '_digjy_sku', true),
                ],
            ]],
            'recipient' => $recipient,
            'locale' => determine_locale(),
        ];

        $order = $this->create_crossmint_order($payload, $settings);
        if (is_wp_error($order)) {
            wp_send_json_error(['message' => $order->get_error_message()], 500);
        }

        $status_data = $this->extract_order_status_data($order, $normalized_method);
        $order_id = wp_insert_post([
            'post_type' => 'digjy_order',
            'post_status' => 'publish',
            'post_title' => sprintf(__('Order for %s', 'digjy-stores'), $product->post_title),
        ]);

        if ($order_id) {
            update_post_meta($order_id, '_digjy_product_id', $product_id);
            update_post_meta($order_id, '_digjy_seller_id', $seller_id);
            update_post_meta($order_id, '_digjy_buyer_email', $buyer_email);
            update_post_meta($order_id, '_digjy_crossmint_order_id', sanitize_text_field($order['order']['orderId'] ?? ''));
            update_post_meta($order_id, '_digjy_order_status', sanitize_text_field($status_data['status']));
            update_post_meta($order_id, '_digjy_status_label', sanitize_text_field($status_data['label']));
            update_post_meta($order_id, '_digjy_payment_method', $normalized_method);
            update_post_meta($order_id, '_digjy_client_secret', sanitize_text_field($order['clientSecret'] ?? ''));
            update_post_meta($order_id, '_digjy_price', $price);
            update_post_meta($order_id, '_digjy_marketplace_amount', $commissions['marketplace_amount']);
            update_post_meta($order_id, '_digjy_seller_amount', $commissions['seller_amount']);
            update_post_meta($order_id, '_digjy_payload', wp_json_encode($payload));
            update_post_meta($order_id, '_digjy_asset_snapshot', wp_json_encode($asset));
            update_post_meta($order_id, '_digjy_download_count', 0);
            update_post_meta($order_id, '_digjy_payout_status', 'unpaid');
            update_post_meta($order_id, '_digjy_payment_preparation', wp_json_encode($status_data['preparation']));
        }

        wp_send_json_success([
            'message' => __('Checkout session created.', 'digjy-stores'),
            'order' => $order,
            'internal_order_id' => $order_id,
            'crossmint_order_id' => $order['order']['orderId'] ?? '',
            'client_secret' => $order['clientSecret'] ?? '',
            'commission' => $commissions,
            'payment_method' => $normalized_method,
            'status' => $status_data,
            'card_checkout' => [
                'can_embed' => !empty($settings['crossmint_client_api_key']),
                'client_api_key_configured' => !empty($settings['crossmint_client_api_key']),
            ],
        ]);
    }

    public function ajax_get_checkout_status() {
        check_ajax_referer('digjy_stores_nonce', 'nonce');
        $internal_order_id = isset($_POST['internal_order_id']) ? absint($_POST['internal_order_id']) : 0;
        if (!$internal_order_id) {
            wp_send_json_error(['message' => __('Missing order ID.', 'digjy-stores')], 400);
        }
        $post = get_post($internal_order_id);
        if (!$post || 'digjy_order' !== $post->post_type) {
            wp_send_json_error(['message' => __('Order not found.', 'digjy-stores')], 404);
        }

        $crossmint_order_id = get_post_meta($internal_order_id, '_digjy_crossmint_order_id', true);
        $payment_method = get_post_meta($internal_order_id, '_digjy_payment_method', true) ?: 'solana';
        $settings = Digjy_Stores::get_settings();

        if ($crossmint_order_id && !empty($settings['crossmint_api_key'])) {
            $remote = $this->get_crossmint_order($crossmint_order_id, $settings, get_post_meta($internal_order_id, '_digjy_client_secret', true));
            if (!is_wp_error($remote)) {
                $status_data = $this->extract_order_status_data($remote, $payment_method);
                update_post_meta($internal_order_id, '_digjy_order_status', $status_data['status']);
                update_post_meta($internal_order_id, '_digjy_status_label', $status_data['label']);
                update_post_meta($internal_order_id, '_digjy_payment_preparation', wp_json_encode($status_data['preparation']));
                update_post_meta($internal_order_id, '_digjy_last_status_payload', wp_json_encode($remote));
                if (in_array($status_data['status'], ['completed', 'paid', 'delivered', 'succeeded'], true)) {
                    $this->mark_order_paid($internal_order_id);
                }
                $this->sync_product_meta_from_payload($internal_order_id, $remote);
                wp_send_json_success([
                    'internal_order_id' => $internal_order_id,
                    'crossmint_order_id' => $crossmint_order_id,
                    'status' => $status_data,
                    'download_url' => $this->get_download_url($internal_order_id),
                ]);
            }
        }

        wp_send_json_success([
            'internal_order_id' => $internal_order_id,
            'crossmint_order_id' => $crossmint_order_id,
            'status' => [
                'status' => get_post_meta($internal_order_id, '_digjy_order_status', true),
                'label' => get_post_meta($internal_order_id, '_digjy_status_label', true),
                'preparation' => json_decode((string) get_post_meta($internal_order_id, '_digjy_payment_preparation', true), true),
            ],
            'download_url' => $this->get_download_url($internal_order_id),
        ]);
    }

    public static function handle_crossmint_webhook($request) {
        $settings = Digjy_Stores::get_settings();
        $raw_body = $request->get_body();
        $instance = new self();
        if (!$instance->verify_crossmint_webhook_signature($raw_body, $request, $settings)) {
            return new WP_REST_Response(['message' => 'Invalid webhook signature'], 403);
        }
        $body = json_decode($raw_body, true);
        if (!is_array($body)) {
            $body = $request->get_json_params();
        }
        $event_type = sanitize_text_field($body['type'] ?? $body['event'] ?? $body['eventType'] ?? 'crossmint.webhook');
        $order_id = sanitize_text_field($body['order']['orderId'] ?? $body['orderId'] ?? '');
        if (!$order_id) {
            Digjy_Stores_Sync::log_webhook_event($event_type, $body, true, 0);
            return new WP_REST_Response(['message' => 'Missing orderId'], 400);
        }
        $posts = get_posts(['post_type' => 'digjy_order', 'post_status' => 'publish', 'posts_per_page' => 1, 'meta_key' => '_digjy_crossmint_order_id', 'meta_value' => $order_id]);
        if (!$posts) {
            Digjy_Stores_Sync::log_webhook_event($event_type, $body, true, 0);
            return new WP_REST_Response(['message' => 'Order not found'], 404);
        }
        $post_id = $posts[0]->ID;
        $payment_method = get_post_meta($post_id, '_digjy_payment_method', true) ?: 'solana';
        $status_data = $instance->extract_order_status_data($body, $payment_method);
        update_post_meta($post_id, '_digjy_order_status', $status_data['status']);
        update_post_meta($post_id, '_digjy_status_label', $status_data['label']);
        update_post_meta($post_id, '_digjy_webhook_payload', wp_json_encode($body));
        update_post_meta($post_id, '_digjy_last_webhook_event_type', $event_type);
        update_post_meta($post_id, '_digjy_last_webhook_received_at', current_time('mysql'));
        Digjy_Stores_Sync::log_webhook_event($event_type, $body, true, $post_id);
        $instance->sync_product_meta_from_payload($post_id, $body);
        if (in_array($status_data['status'], ['completed', 'delivered', 'paid', 'succeeded'], true)) {
            $instance->mark_order_paid($post_id);
        }
        return new WP_REST_Response(['received' => true], 200);
    }


    public function ajax_record_wallet_tx() {
        check_ajax_referer('digjy_stores_nonce', 'nonce');
        $internal_order_id = isset($_POST['internal_order_id']) ? absint($_POST['internal_order_id']) : 0;
        $tx_id = sanitize_text_field($_POST['tx_id'] ?? '');
        if (!$internal_order_id || !$tx_id) {
            wp_send_json_error(['message' => __('Missing transaction details.', 'digjy-stores')], 400);
        }
        update_post_meta($internal_order_id, '_digjy_wallet_submitted_txid', $tx_id);
        update_post_meta($internal_order_id, '_digjy_status_label', __('Signed transaction submitted to Solana. Waiting for Crossmint/payment confirmation.', 'digjy-stores'));
        wp_send_json_success(['message' => __('Transaction recorded.', 'digjy-stores')]);
    }

    private function verify_crossmint_webhook_signature($raw_body, $request, $settings) {
        $svix_id = (string) $request->get_header('svix-id');
        $svix_timestamp = (string) $request->get_header('svix-timestamp');
        $svix_signature = (string) $request->get_header('svix-signature');

        if (!empty($svix_id) && !empty($svix_timestamp) && !empty($svix_signature) && !empty($settings['webhook_secret'])) {
            $timestamp = absint($svix_timestamp);
            if ($timestamp && abs(time() - $timestamp) > 300) {
                return false;
            }
            $secret = (string) $settings['webhook_secret'];
            $secret_key = strpos($secret, 'whsec_') === 0 ? base64_decode(substr($secret, 6), true) : $secret;
            if (empty($secret_key)) {
                $secret_key = $secret;
            }
            $signed_content = $svix_id . '.' . $svix_timestamp . '.' . $raw_body;
            $expected = base64_encode(hash_hmac('sha256', $signed_content, $secret_key, true));
            $parts = preg_split('/\s+/', trim($svix_signature));
            foreach ($parts as $part) {
                $candidate = $part;
                if (strpos($candidate, ',') !== false) {
                    $candidate = explode(',', $candidate, 2)[1];
                }
                if (hash_equals((string) $expected, (string) $candidate)) {
                    return true;
                }
            }
            return false;
        }

        $incoming_secret = (string) $request->get_header('x-digjy-webhook-secret');
        if (!empty($settings['webhook_secret'])) {
            return !empty($incoming_secret) && hash_equals((string) $settings['webhook_secret'], $incoming_secret);
        }
        return true;
    }

    public function ajax_mark_order_paid() {
        check_ajax_referer('digjy_stores_nonce', 'nonce');
        if (!current_user_can('manage_options')) wp_send_json_error(['message' => __('You do not have permission to update orders.', 'digjy-stores')], 403);
        $order_id = isset($_POST['order_id']) ? absint($_POST['order_id']) : 0;
        $result = $this->mark_order_paid($order_id);
        if (is_wp_error($result)) wp_send_json_error(['message' => $result->get_error_message()], 500);
        wp_send_json_success(['message' => __('Order marked as paid.', 'digjy-stores')]);
    }

    public function handle_admin_mark_order_paid() {
        $order_id = isset($_GET['order_id']) ? absint($_GET['order_id']) : 0;
        if (!$order_id || !current_user_can('manage_options') || !wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['_wpnonce'] ?? '')), 'digjy_mark_order_paid_' . $order_id)) {
            wp_die(esc_html__('Invalid request.', 'digjy-stores'));
        }
        $this->mark_order_paid($order_id);
        wp_safe_redirect(admin_url('post.php?post=' . $order_id . '&action=edit'));
        exit;
    }

    public function mark_order_paid($order_id) {
        $order_id = absint($order_id);
        if (!$order_id) return new WP_Error('invalid_order', __('Invalid order.', 'digjy-stores'));
        update_post_meta($order_id, '_digjy_order_status', 'paid');
        update_post_meta($order_id, '_digjy_status_label', __('Payment succeeded. Delivery/download ready.', 'digjy-stores'));
        $token = wp_generate_password(32, false, false);
        update_post_meta($order_id, '_digjy_download_token', $token);
        update_post_meta($order_id, '_digjy_paid_at', current_time('mysql'));
        $this->credit_seller_wallet_from_order($order_id);
        return true;
    }

    private function credit_seller_wallet_from_order($order_id) {
        if (get_post_meta($order_id, '_digjy_wallet_credited', true)) {
            return;
        }
        $seller_id = absint(get_post_meta($order_id, '_digjy_seller_id', true));
        $amount = round((float) get_post_meta($order_id, '_digjy_seller_amount', true), 2);
        if (!$seller_id || $amount <= 0) {
            return;
        }
        $balance = (float) get_user_meta($seller_id, 'digjy_wallet_balance', true);
        update_user_meta($seller_id, 'digjy_wallet_balance', $balance + $amount);
        $tx_id = wp_insert_post([
            'post_type' => 'digjy_wallet_tx',
            'post_status' => 'publish',
            'post_title' => sprintf(__('Order credit #%d', 'digjy-stores'), $order_id),
            'post_content' => __('Seller earnings credited from paid marketplace order.', 'digjy-stores'),
            'post_author' => $seller_id,
        ]);
        if ($tx_id && !is_wp_error($tx_id)) {
            update_post_meta($tx_id, '_digjy_wallet_user_id', $seller_id);
            update_post_meta($tx_id, '_digjy_wallet_type', 'sale_credit');
            update_post_meta($tx_id, '_digjy_wallet_amount', $amount);
            update_post_meta($tx_id, '_digjy_wallet_meta', wp_json_encode(['order_id' => $order_id]));
        }
        update_post_meta($order_id, '_digjy_wallet_credited', 1);
    }

    public function handle_secure_download() {
        if (empty($_GET['digjy_download']) || empty($_GET['token'])) return;
        $order_id = absint($_GET['digjy_download']);
        $token = sanitize_text_field(wp_unslash($_GET['token']));
        $saved_token = get_post_meta($order_id, '_digjy_download_token', true);
        if (!$order_id || !$token || !$saved_token || !hash_equals($saved_token, $token)) wp_die(esc_html__('Invalid download link.', 'digjy-stores'));

        $status = get_post_meta($order_id, '_digjy_order_status', true);
        if (!in_array($status, ['paid', 'completed'], true)) wp_die(esc_html__('This order is not paid yet.', 'digjy-stores'));

        $settings = Digjy_Stores::get_settings();
        $count = (int) get_post_meta($order_id, '_digjy_download_count', true);
        $limit = (int) ($settings['download_limit'] ?? 5);
        if ($count >= $limit) wp_die(esc_html__('Download limit reached.', 'digjy-stores'));

        $paid_at = get_post_meta($order_id, '_digjy_paid_at', true);
        $expires = strtotime($paid_at . ' +' . ((int) ($settings['download_expiry_days'] ?? 7)) . ' days');
        if ($paid_at && $expires && time() > $expires) wp_die(esc_html__('Download link has expired.', 'digjy-stores'));

        $product_id = (int) get_post_meta($order_id, '_digjy_product_id', true);
        $file_url = get_post_meta($product_id, '_digjy_file_url', true);
        if (!$file_url) wp_die(esc_html__('Download file not found.', 'digjy-stores'));

        update_post_meta($order_id, '_digjy_download_count', $count + 1);
        $logs = get_post_meta($order_id, '_digjy_download_logs', true);
        if (!is_array($logs)) $logs = [];
        $logs[] = ['time' => current_time('mysql'), 'ip' => sanitize_text_field($_SERVER['REMOTE_ADDR'] ?? '')];
        update_post_meta($order_id, '_digjy_download_logs', $logs);
        wp_safe_redirect(esc_url_raw($file_url));
        exit;
    }

    public function get_download_url($order_id) {
        $token = get_post_meta($order_id, '_digjy_download_token', true);
        if (!$token) return '';
        return add_query_arg(['digjy_download' => $order_id, 'token' => $token], home_url('/'));
    }

    private function calculate_commissions($price) {
        $settings = Digjy_Stores::get_settings();
        $marketplace_percent = (float) ($settings['marketplace_commission'] ?? 10);
        $seller_percent = (float) ($settings['seller_commission'] ?? 90);
        return [
            'marketplace_amount' => round(($price * $marketplace_percent) / 100, 2),
            'seller_amount' => round(($price * $seller_percent) / 100, 2),
        ];
    }

    private function create_crossmint_order($payload, $settings) {
        $base = ($settings['crossmint_environment'] ?? 'production') === 'staging' ? 'https://staging.crossmint.com/api/2022-06-09/orders' : 'https://www.crossmint.com/api/2022-06-09/orders';
        $response = wp_remote_post($base, [
            'timeout' => 30,
            'headers' => [
                'Content-Type' => 'application/json',
                'X-API-KEY' => $settings['crossmint_api_key'],
            ],
            'body' => wp_json_encode($payload),
        ]);
        if (is_wp_error($response)) return $response;
        $code = (int) wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);
        if ($code < 200 || $code >= 300) {
            return new WP_Error('crossmint_error', $body['message'] ?? __('Crossmint order creation failed.', 'digjy-stores'));
        }
        return $body;
    }

    private function get_crossmint_order($crossmint_order_id, $settings, $client_secret = '') {
        $base = ($settings['crossmint_environment'] ?? 'production') === 'staging' ? 'https://staging.crossmint.com/api/2022-06-09/orders/' : 'https://www.crossmint.com/api/2022-06-09/orders/';
        $headers = ['Content-Type' => 'application/json'];
        if (!empty($settings['crossmint_api_key'])) {
            $headers['X-API-KEY'] = $settings['crossmint_api_key'];
        }
        if (!empty($client_secret)) {
            $headers['Authorization'] = $client_secret;
        }
        $response = wp_remote_get($base . rawurlencode($crossmint_order_id), [
            'timeout' => 30,
            'headers' => $headers,
        ]);
        if (is_wp_error($response)) return $response;
        $code = (int) wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);
        if ($code < 200 || $code >= 300) {
            return new WP_Error('crossmint_status_error', $body['message'] ?? __('Unable to fetch Crossmint order status.', 'digjy-stores'));
        }
        return $body;
    }

    public function extract_order_status_data($payload, $payment_method = 'solana') {
        $order = $payload['order'] ?? $payload;
        $payment = $order['payment'] ?? ($payload['payment'] ?? []);
        $delivery = $order['delivery'] ?? ($payload['delivery'] ?? []);
        $status = sanitize_text_field($payment['status'] ?? $order['phase'] ?? 'created');
        $preparation = $payment['preparation'] ?? [];
        $label = $this->humanize_status($status, $payment_method, $preparation, $delivery);

        return [
            'status' => $status,
            'label' => $label,
            'preparation' => [
                'serializedTransaction' => $preparation['serializedTransaction'] ?? '',
                'message' => $preparation['message'] ?? '',
                'instructions' => $preparation['instructions'] ?? [],
                'amount' => $preparation['amount'] ?? '',
                'currency' => $payment['currency'] ?? '',
                'payerAddress' => $payment['payerAddress'] ?? '',
                'clientSecret' => $payload['clientSecret'] ?? '',
            ],
            'raw_phase' => sanitize_text_field($order['phase'] ?? ''),
            'delivery_status' => sanitize_text_field($delivery['status'] ?? ''),
            'txId' => sanitize_text_field($delivery['txId'] ?? ($payment['txId'] ?? '')),
        ];
    }

    private function humanize_status($status, $payment_method, $preparation = [], $delivery = []) {
        $map = [
            'requires-quote' => __('Generating quote for checkout.', 'digjy-stores'),
            'awaiting-payment' => $payment_method === 'card'
                ? __('Card checkout is ready. Complete payment with card.', 'digjy-stores')
                : __('Solana payment is ready. Open your wallet and approve the transaction.', 'digjy-stores'),
            'pending' => __('Payment is being processed.', 'digjy-stores'),
            'processing' => __('Payment is processing.', 'digjy-stores'),
            'requires-recipient-verification' => __('Recipient verification is required before continuing.', 'digjy-stores'),
            'paid' => __('Payment succeeded. Preparing delivery.', 'digjy-stores'),
            'completed' => __('Order completed successfully.', 'digjy-stores'),
            'delivered' => __('Digital asset delivered successfully.', 'digjy-stores'),
            'succeeded' => __('Payment succeeded.', 'digjy-stores'),
            'failed' => __('Payment failed.', 'digjy-stores'),
            'canceled' => __('Checkout was canceled.', 'digjy-stores'),
            'refunded' => __('Payment was refunded.', 'digjy-stores'),
            'created' => __('Checkout created.', 'digjy-stores'),
        ];
        if (!empty($delivery['status']) && $delivery['status'] === 'succeeded') {
            return __('Payment succeeded and delivery completed.', 'digjy-stores');
        }
        if ($payment_method === 'solana' && !empty($preparation['serializedTransaction']) && $status === 'awaiting-payment') {
            return __('Solana transaction prepared. Ask the buyer wallet to sign and submit the transaction.', 'digjy-stores');
        }
        return $map[$status] ?? __('Status updated.', 'digjy-stores');
    }


    public function sync_order_with_crossmint($internal_order_id, $sync_product = false) {
        $internal_order_id = absint($internal_order_id);
        if (!$internal_order_id) {
            return new WP_Error('invalid_order', __('Invalid order.', 'digjy-stores'));
        }
        $crossmint_order_id = get_post_meta($internal_order_id, '_digjy_crossmint_order_id', true);
        if (!$crossmint_order_id) {
            return new WP_Error('missing_crossmint_order', __('This order is not linked to Crossmint yet.', 'digjy-stores'));
        }
        $settings = Digjy_Stores::get_settings();
        $payment_method = get_post_meta($internal_order_id, '_digjy_payment_method', true) ?: 'solana';
        $remote = $this->get_crossmint_order($crossmint_order_id, $settings, get_post_meta($internal_order_id, '_digjy_client_secret', true));
        if (is_wp_error($remote)) {
            return $remote;
        }
        $status_data = $this->extract_order_status_data($remote, $payment_method);
        update_post_meta($internal_order_id, '_digjy_order_status', $status_data['status']);
        update_post_meta($internal_order_id, '_digjy_status_label', $status_data['label']);
        update_post_meta($internal_order_id, '_digjy_payment_preparation', wp_json_encode($status_data['preparation']));
        update_post_meta($internal_order_id, '_digjy_last_status_payload', wp_json_encode($remote));
        update_post_meta($internal_order_id, '_digjy_last_crossmint_sync', current_time('mysql'));
        if (!empty($status_data['txId'])) {
            update_post_meta($internal_order_id, '_digjy_wallet_submitted_txid', sanitize_text_field($status_data['txId']));
        }
        if (in_array($status_data['status'], ['completed', 'paid', 'delivered', 'succeeded'], true)) {
            $this->mark_order_paid($internal_order_id);
        }
        if ($sync_product) {
            $this->sync_product_meta_from_payload($internal_order_id, $remote);
        }
        return $status_data;
    }

    public function sync_product_from_related_orders($product_id) {
        $product_id = absint($product_id);
        if (!$product_id) {
            return new WP_Error('invalid_product', __('Invalid product.', 'digjy-stores'));
        }
        $orders = get_posts([
            'post_type' => 'digjy_order',
            'post_status' => 'publish',
            'posts_per_page' => 20,
            'orderby' => 'date',
            'order' => 'DESC',
            'meta_query' => [[ 'key' => '_digjy_product_id', 'value' => $product_id, 'compare' => '=' ]],
        ]);
        if (!$orders) {
            return new WP_Error('no_related_orders', __('No related orders were found for this product.', 'digjy-stores'));
        }
        $synced = false;
        foreach ($orders as $order) {
            $payload = json_decode((string) get_post_meta($order->ID, '_digjy_last_status_payload', true), true);
            if (!$payload) {
                $payload = json_decode((string) get_post_meta($order->ID, '_digjy_webhook_payload', true), true);
            }
            if ($payload) {
                $this->sync_product_meta_from_payload($order->ID, $payload, $product_id);
                $synced = true;
                break;
            }
        }
        return $synced ? true : new WP_Error('no_sync_payload', __('No Crossmint payload was available to sync this product.', 'digjy-stores'));
    }

    public function sync_product_meta_from_payload($order_id, $payload, $forced_product_id = 0) {
        $order_id = absint($order_id);
        $product_id = $forced_product_id ? absint($forced_product_id) : absint(get_post_meta($order_id, '_digjy_product_id', true));
        if (!$product_id || !get_post($product_id)) {
            return false;
        }

        $order = is_array($payload) ? ($payload['order'] ?? $payload) : [];
        $payment = $order['payment'] ?? [];
        $delivery = $order['delivery'] ?? [];
        $line_items = $order['lineItems'] ?? ($payload['lineItems'] ?? []);
        $line_item = is_array($line_items) && !empty($line_items[0]) ? $line_items[0] : [];
        $call_data = $line_item['callData'] ?? [];
        $on_chain = $delivery['onChain'] ?? ($order['onChain'] ?? []);
        $meta_updates = [
            '_digjy_chain' => sanitize_text_field($call_data['chain'] ?? $line_item['chain'] ?? get_post_meta($product_id, '_digjy_chain', true)),
            '_digjy_collection_locator' => sanitize_text_field($line_item['collectionLocator'] ?? $call_data['collectionLocator'] ?? get_post_meta($product_id, '_digjy_collection_locator', true)),
            '_digjy_token_id' => sanitize_text_field($on_chain['tokenId'] ?? $delivery['tokenId'] ?? $call_data['tokenId'] ?? get_post_meta($product_id, '_digjy_token_id', true)),
            '_digjy_contract_address' => sanitize_text_field($on_chain['contractAddress'] ?? $delivery['contractAddress'] ?? $call_data['contractAddress'] ?? get_post_meta($product_id, '_digjy_contract_address', true)),
            '_digjy_owner' => sanitize_text_field($on_chain['owner'] ?? $delivery['owner'] ?? $payment['payerAddress'] ?? get_post_meta($product_id, '_digjy_owner', true)),
            '_digjy_txid' => sanitize_text_field($delivery['txId'] ?? $payment['txId'] ?? get_post_meta($product_id, '_digjy_txid', true)),
            '_digjy_onchain_status' => sanitize_text_field($on_chain['status'] ?? $delivery['status'] ?? $payment['status'] ?? get_post_meta($product_id, '_digjy_onchain_status', true)),
            '_digjy_recipient_wallet' => sanitize_text_field(($order['recipient']['walletAddress'] ?? '') ?: get_post_meta($product_id, '_digjy_recipient_wallet', true)),
            '_digjy_metadata_uri' => esc_url_raw($line_item['metadataUri'] ?? $call_data['metadataUri'] ?? get_post_meta($product_id, '_digjy_metadata_uri', true)),
            '_digjy_last_synced_at' => current_time('mysql'),
        ];
        foreach ($meta_updates as $meta_key => $meta_value) {
            if ($meta_value !== '' && $meta_value !== null) {
                update_post_meta($product_id, $meta_key, $meta_value);
            }
        }
        update_post_meta($product_id, '_digjy_last_sync_source_order', $order_id);
        return true;
    }

}
