<?php
if (!defined('ABSPATH')) {
    exit;
}

class Digjy_Stores_Shortcodes {
    private $checkout;
    private $products;
    private $vendors;

    public function __construct($checkout, $products, $vendors) {
        $this->checkout = $checkout;
        $this->products = $products;
        $this->vendors = $vendors;

        add_shortcode('digjy_buy_now', [$this, 'buy_now']);
        add_shortcode('digjy_digital_checkout', [$this, 'digital_checkout']);
        add_shortcode('digjy_crossmint_embedded_card', [$this, 'embedded_card_checkout']);
        add_shortcode('digjy_vendor_dashboard', [$this, 'vendor_dashboard']);
        add_shortcode('digjy_store_list', [$this, 'store_list']);
        add_shortcode('digjy_seller_register', [$this, 'seller_register']);
        add_shortcode('digjy_customer_register', [$this, 'customer_register']);
        add_shortcode('digjy_customer_login', [$this, 'customer_login']);
        add_shortcode('digjy_store_login', [$this, 'store_login']);
        add_shortcode('digjy_my_account', [$this, 'my_account']);
        add_shortcode('digjy_customer_downloads', [$this, 'customer_downloads']);
        add_shortcode('digjy_order_history', [$this, 'order_history']);
        add_shortcode('digjy_product_price', [$this, 'product_price']);
        add_shortcode('digjy_nft_info', [$this, 'nft_info']);
        add_shortcode('digjy_nft_lazy_data', [$this, 'nft_lazy_data']);
        add_shortcode('digjy_nft_minted_data', [$this, 'nft_minted_data']);
        add_shortcode('digjy_contact_store_owner_button', [$this, 'contact_store_owner_button']);
        add_shortcode('digjy_follow_button', [$this, 'follow_button']);
        add_shortcode('digjy_wallet', [$this, 'wallet_shortcode']);
        add_shortcode('digjy_messages', [$this, 'messages_shortcode']);
        add_shortcode('digjy_review_section', [$this, 'review_section']);
        add_shortcode('digjy_product_reviews', [$this, 'review_section']);
        add_shortcode('digjy_seller_product_builder', [$this, 'seller_product_builder']);
        add_shortcode('digjy_realtime_messages', [$this, 'realtime_messages']);
        add_shortcode('digjy_nft_mint_ui', [$this, 'nft_mint_ui']);
        add_shortcode('digjy_digital_product_form', [$this, 'digital_product_form']);
        add_shortcode('digjy_edit_store_form', [$this, 'edit_store_form']);
        add_shortcode('digjy_current_store_url', [$this, 'current_store_url']);
        add_shortcode('digjy_manage_products', [$this, 'manage_products']);
        add_shortcode('digjy_thank_you_downloads', [$this, 'thank_you_downloads']);
        add_shortcode('digjy_dig_list', [$this, 'dig_list']);
        add_shortcode('digjy_recently_viewed', [$this, 'recently_viewed']);
        add_shortcode('digjy_cart', [$this, 'cart_shortcode']);

        add_action('init', [$this, 'register_marketplace_post_types']);
        add_action('init', [$this, 'handle_frontend_product_save']);
        add_action('init', [$this, 'handle_marketplace_forms']);
        add_action('init', [$this, 'handle_digital_product_submission_forms']);
        add_action('init', [$this, 'handle_store_edit_form']);
        add_action('init', [$this, 'handle_manage_products_actions']);
        add_action('wp_ajax_digjy_generate_store_seo', [$this, 'ajax_generate_store_seo']);
        add_action('wp_ajax_digjy_upload_description_media', [$this, 'ajax_upload_description_media']);
    }


    public function register_marketplace_post_types() {
        register_post_type('digjy_message', [
            'labels' => ['name' => __('Messages', 'digjy-stores'), 'singular_name' => __('Message', 'digjy-stores')],
            'public' => false,
            'show_ui' => true,
            'show_in_menu' => 'edit.php?post_type=digjy_store',
            'supports' => ['title', 'editor', 'author'],
            'capability_type' => 'post',
        ]);

        register_post_type('digjy_wallet_tx', [
            'labels' => ['name' => __('Wallet Transactions', 'digjy-stores'), 'singular_name' => __('Wallet Transaction', 'digjy-stores')],
            'public' => false,
            'show_ui' => true,
            'show_in_menu' => 'edit.php?post_type=digjy_store',
            'supports' => ['title', 'editor', 'author'],
            'capability_type' => 'post',
        ]);
    }

    private function wrap_output($html, $classes = '') {
        $classes = trim('digjy-stores-container ' . $classes);
        $settings = Digjy_Stores::get_settings();
        $mode = !empty($settings['shadow_dom_isolation']) ? 'shadow' : 'normal';
        $mode = apply_filters('digjy_stores_isolation_mode', $mode);

        if ('shadow' === $mode) {
            $css = '';
            $css_file = DIGJY_STORES_PATH . 'assets/css/digjy-stores.css';
            if (file_exists($css_file) && is_readable($css_file)) {
                $css = file_get_contents($css_file);
            }
            $host_id = 'digjy-shadow-' . wp_generate_uuid4();
            return '<div id="' . esc_attr($host_id) . '" class="digjy-shadow-host" data-digjy-shadow="1" data-digjy-classes="' . esc_attr($classes) . '"><template><style>' . $css . '</style><div class="' . esc_attr($classes) . '">' . $html . '</div></template></div>';
        }

        return '<div class="' . esc_attr($classes) . '">' . $html . '</div>';
    }


    private function current_user_is_store_owner() {
        if (!is_user_logged_in()) {
            return false;
        }
        $user = wp_get_current_user();
        $roles = (array) $user->roles;
        return current_user_can('manage_options') || in_array('digjy_store_owner', $roles, true) || in_array('digjy_seller', $roles, true);
    }

    private function get_jsdelivr_missing_settings() {
        $settings = Digjy_Stores::get_settings();
        $required = [
            'jsdelivr_github_owner' => __('GitHub Owner', 'digjy-stores'),
            'jsdelivr_github_repo' => __('GitHub Repository', 'digjy-stores'),
            'jsdelivr_github_branch' => __('GitHub Branch', 'digjy-stores'),
            'jsdelivr_github_token' => __('GitHub Token', 'digjy-stores'),
            'jsdelivr_upload_folder' => __('Upload Folder', 'digjy-stores'),
        ];
        $missing = [];
        foreach ($required as $key => $label) {
            if ('' === trim((string) ($settings[$key] ?? ''))) {
                $missing[] = $label;
            }
        }
        return $missing;
    }

    private function get_jsdelivr_settings_notice_html() {
        $missing = $this->get_jsdelivr_missing_settings();
        if (empty($missing)) {
            return '';
        }
        $settings_url = admin_url('edit.php?post_type=digjy_store&page=digjy-stores-settings');
        return '<div class="digjy-error"><strong>' . esc_html__('jsDelivr upload settings are incomplete.', 'digjy-stores') . '</strong><br />' . esc_html__('Missing:', 'digjy-stores') . ' ' . esc_html(implode(', ', $missing)) . '<br /><a class="digjy-btn" href="' . esc_url($settings_url) . '">' . esc_html__('Open Digjy Stores Settings', 'digjy-stores') . '</a></div>';
    }

    private function get_submission_notice_html() {
        $status = sanitize_key($_GET['digjy_submission'] ?? '');
        if (!$status) {
            return '';
        }
        $missing_notice = $this->get_jsdelivr_settings_notice_html();
        $messages = [
            'success' => '<div class="digjy-success">' . esc_html__('Your digital product was submitted successfully.', 'digjy-stores') . '</div>',
            'upload_error' => '<div class="digjy-error">' . esc_html__('The file could not be uploaded to jsDelivr. Please confirm your GitHub/jsDelivr settings and try again.', 'digjy-stores') . '</div>',
            'missing_settings' => $missing_notice ?: '<div class="digjy-error">' . esc_html__('jsDelivr GitHub settings are missing. Please add your GitHub token, owner, repository, branch, and upload folder in Digjy Stores settings.', 'digjy-stores') . '</div>',
            'permission' => '<div class="digjy-error">' . esc_html__('Only store owners can use this form.', 'digjy-stores') . '</div>',
        ];
        return $messages[$status] ?? '';
    }

    private function render_wallet_connect_buttons() {
        return '<div class="digjy-wallet-connect-row"><button type="button" class="digjy-btn digjy-wallet-connect" data-wallet="phantom">' . esc_html__('Connect Phantom Wallet', 'digjy-stores') . '</button><button type="button" class="digjy-btn digjy-wallet-connect" data-wallet="metamask">' . esc_html__('Connect Metamask Wallet', 'digjy-stores') . '</button></div><input type="hidden" name="digjy_wallet_provider" value="" /><input type="hidden" name="digjy_wallet_address" value="" /><p class="digjy-help digjy-wallet-status"></p>';
    }

    private function render_digital_product_submission_form($proof_type = 'none') {
        wp_enqueue_style('digjy-stores');
        wp_enqueue_script('digjy-stores');
        if (!$this->current_user_is_store_owner()) {
            return $this->wrap_output('<div class="digjy-alert">' . esc_html__('Please log in as a store owner to submit products.', 'digjy-stores') . '</div>', 'digjy-shortcode-alert');
        }
        $titles = [
            'none' => __('Sell Digital Product', 'digjy-stores'),
            'poo' => __('DIGITAL PRODUCT with P.O.O.', 'digjy-stores'),
            'poa' => __('DIGITAL PRODUCT with P.O.A.', 'digjy-stores'),
        ];
        $help = [
            'none' => '',
            'poo' => __('Connect Phantom or Metamask to submit a Proof of Ownership product. A $25 admin fee will be recorded for P.O.O. setup.', 'digjy-stores'),
            'poa' => __('Connect Phantom or Metamask to submit a Proof of Authenticity product.', 'digjy-stores'),
        ];
        $proof_type = in_array($proof_type, ['none', 'poo', 'poa'], true) ? $proof_type : 'none';
        ob_start();
        echo $this->get_submission_notice_html();
        $missing_jsdelivr_settings = $this->get_jsdelivr_missing_settings();
        echo '<div class="digjy-card"><h3>' . esc_html($titles[$proof_type]) . '</h3>';
        if (!empty($missing_jsdelivr_settings)) {
            echo $this->get_jsdelivr_settings_notice_html();
        }
        if (!empty($help[$proof_type])) { echo '<p class="digjy-help">' . esc_html($help[$proof_type]) . '</p>'; }
        echo '<form method="post" enctype="multipart/form-data" class="digjy-form-grid digjy-product-submission-form">';
        wp_nonce_field('digjy_submit_product_' . $proof_type, 'digjy_submit_product_nonce');
        echo '<input type="hidden" name="digjy_submission_action" value="submit_product_form" />';
        echo '<input type="hidden" name="digjy_submission_proof_type" value="' . esc_attr($proof_type) . '" />';
        echo '<p><label>' . esc_html__('Upload Featured Image', 'digjy-stores') . '</label><input type="file" name="digjy_submission_featured_image" accept="image/*" /></p>';
        echo '<p><label>' . esc_html__('Product Image Gallery (Optional)', 'digjy-stores') . '</label><input type="file" name="digjy_submission_gallery[]" accept="image/*" multiple /></p>';
        echo '<p><label>' . esc_html__('Upload Video (Optional)', 'digjy-stores') . '</label><input type="file" name="digjy_submission_videos[]" accept="video/*" multiple /></p>';
        echo '<p><label>' . esc_html__('Title', 'digjy-stores') . '</label><input type="text" name="digjy_submission_title" required /></p>';
        echo '<p><label>' . esc_html__('Brief Details', 'digjy-stores') . '</label><textarea name="digjy_submission_brief" rows="3" required></textarea></p>';
        echo '<div class="digjy-description-field"><p><label>' . esc_html__('Description', 'digjy-stores') . '</label><button type="button" class="digjy-btn digjy-add-media-btn" style="margin-left:10px;">' . esc_html__('Add Media', 'digjy-stores') . '</button><input type="file" class="digjy-description-media-input" accept="image/*,video/*,audio/*,.pdf,.zip,.doc,.docx" style="display:none;" /></p><textarea id="digjy_submission_description" name="digjy_submission_description" rows="6" required></textarea><p class="digjy-help digjy-description-media-status"></p></div>';
        $category_terms = get_terms(['taxonomy' => 'digjy_product_category', 'hide_empty' => false]);
        echo '<div class="digjy-two-col"><p><label>' . esc_html__('Price', 'digjy-stores') . '</label><input type="number" step="0.01" min="0" name="digjy_submission_price" required /></p><p><label>' . esc_html__('Category', 'digjy-stores') . '</label><select name="digjy_submission_category" required><option value="">' . esc_html__('Select Category', 'digjy-stores') . '</option>';
        if (!is_wp_error($category_terms)) {
            foreach ($category_terms as $category_term) {
                echo '<option value="' . esc_attr($category_term->term_id) . '">' . esc_html($category_term->name) . '</option>';
            }
        }
        echo '</select></p></div>';
        echo '<p><label>' . esc_html__('Tags', 'digjy-stores') . '</label><input type="text" name="digjy_submission_tags" placeholder="' . esc_attr__('tag-one, tag-two, tag-three', 'digjy-stores') . '" /></p>';
        echo '<p><label>' . esc_html__('Upload Downloadable Files / ZIP Folders', 'digjy-stores') . '</label><input type="file" name="digjy_submission_files[]" accept=".zip,.pdf,.doc,.docx,.txt,.png,.jpg,.jpeg,.gif,.webp,.svg,.mp3,.wav,.mp4,.mov,.m4v,.webm,application/zip,application/x-zip-compressed" multiple required /><span class="digjy-help">' . esc_html__('You can upload regular digital files or ZIP folders/files. Multiple uploads are supported and hosted through jsDelivr.', 'digjy-stores') . '</span></p>';
        echo '<p><label>' . esc_html__('License / Term Agreement', 'digjy-stores') . '</label><textarea name="digjy_submission_license" rows="4" required></textarea></p>';
        echo '<p><label>' . esc_html__('Purchase Note', 'digjy-stores') . '</label><textarea name="digjy_submission_purchase_note" rows="6" placeholder="' . esc_attr__('Add instructions, license details, bonus links, or setup notes that customers receive after purchase.', 'digjy-stores') . '"></textarea><span class="digjy-help">' . esc_html__('This note is delivered to the customer with the digital product after purchase.', 'digjy-stores') . '</span></p>';
        if ('none' !== $proof_type) {
            echo '<div class="digjy-card digjy-proof-wallet-box">';
            echo '<h4>' . esc_html__('Wallet Connection', 'digjy-stores') . '</h4>';
            echo $this->render_wallet_connect_buttons();
            if ('poo' === $proof_type) {
                echo '<p class="digjy-help"><strong>' . esc_html__('Admin Fee:', 'digjy-stores') . '</strong> $25.00</p>';
            }
            echo '</div>';
        }
        echo '<p><button type="submit" class="digjy-btn">' . esc_html__('Submit Product', 'digjy-stores') . '</button></p>';
        echo '</form></div>';
        return $this->wrap_output(ob_get_clean(), 'digjy-shortcode-block');
    }

    public function digital_product_form() { return $this->render_digital_product_submission_form('none'); }
    private function get_description_media_script() {
        return '';
    }

    public function ajax_upload_description_media() {
        if (!is_user_logged_in() || !$this->current_user_is_store_owner()) {
            wp_send_json_error(['message' => __('Only store owners can upload media.', 'digjy-stores')], 403);
        }
        check_ajax_referer('digjy_stores_nonce', 'nonce');
        if (empty($_FILES['media'])) {
            wp_send_json_error(['message' => __('No file was provided.', 'digjy-stores')], 400);
        }
        $upload = $this->upload_file_to_jsdelivr($_FILES['media']);
        if (is_wp_error($upload)) {
            wp_send_json_error(['message' => $upload->get_error_message()], 400);
        }
        wp_send_json_success([
            'url' => esc_url_raw($upload['file_url']),
            'path' => sanitize_text_field($upload['repository_path']),
            'name' => sanitize_file_name($_FILES['media']['name'] ?? 'media'),
            'mime' => sanitize_text_field($_FILES['media']['type'] ?? ''),
        ]);
    }

    private function get_current_store_post() {
        if (!is_user_logged_in()) {
            return null;
        }
        $video_uploads = [];
        if (!empty($_FILES['digjy_submission_videos']) && is_array($_FILES['digjy_submission_videos']['name'] ?? null)) {
            $video_count = count($_FILES['digjy_submission_videos']['name']);
            for ($i = 0; $i < $video_count; $i++) {
                if (empty($_FILES['digjy_submission_videos']['tmp_name'][$i])) {
                    continue;
                }
                $video_file = [
                    'name' => $_FILES['digjy_submission_videos']['name'][$i] ?? '',
                    'type' => $_FILES['digjy_submission_videos']['type'][$i] ?? '',
                    'tmp_name' => $_FILES['digjy_submission_videos']['tmp_name'][$i] ?? '',
                    'error' => $_FILES['digjy_submission_videos']['error'][$i] ?? 0,
                    'size' => $_FILES['digjy_submission_videos']['size'][$i] ?? 0,
                ];
                $video_upload = $this->upload_file_to_jsdelivr($video_file);
                if (is_wp_error($video_upload)) {
                    $status = 'upload_error';
                    if ('digjy_jsdelivr_missing_settings' === $video_upload->get_error_code()) {
                        $status = 'missing_settings';
                    }
                    wp_safe_redirect(add_query_arg('digjy_submission', $status, wp_get_referer() ?: home_url('/'))); exit;
                }
                $video_uploads[] = $video_upload;
            }
        }
        $user_id = get_current_user_id();
        $store_id = (int) get_user_meta($user_id, 'digjy_store_id', true);
        if ($store_id) {
            $store = get_post($store_id);
            if ($store instanceof WP_Post && 'digjy_store' === $store->post_type) {
                return $store;
            }
        }
        $stores = get_posts([
            'post_type' => 'digjy_store',
            'post_status' => ['publish', 'draft', 'pending'],
            'posts_per_page' => 1,
            'author' => $user_id,
        ]);
        return !empty($stores) ? $stores[0] : null;
    }

    private function get_store_form_notice_html() {
        $status = sanitize_key($_GET['digjy_store_updated'] ?? '');
        if (!$status) {
            return '';
        }
        $messages = [
            'success' => '<div class="digjy-success">' . esc_html__('Your store details were updated successfully.', 'digjy-stores') . '</div>',
            'permission' => '<div class="digjy-error">' . esc_html__('Only store owners can edit store details.', 'digjy-stores') . '</div>',
            'missing_store' => '<div class="digjy-error">' . esc_html__('No store was found for this account.', 'digjy-stores') . '</div>',
            'upload_error' => '<div class="digjy-error">' . esc_html__('The store logo could not be uploaded to jsDelivr.', 'digjy-stores') . '</div>',
            'missing_settings' => '<div class="digjy-error">' . esc_html__('jsDelivr GitHub settings are missing. Please update Digjy Stores settings first.', 'digjy-stores') . '</div>',
        ];
        return $messages[$status] ?? '';
    }




    public function handle_manage_products_actions() {
        if (empty($_POST['digjy_manage_products_action']) || 'delete_product' !== sanitize_key($_POST['digjy_manage_products_action'])) {
            return;
        }
        if (!$this->current_user_is_store_owner() || !is_user_logged_in()) {
            digjy_stores_safe_redirect(add_query_arg('digjy_products_notice', 'permission', wp_get_referer() ?: home_url('/')));
        }
        if (empty($_POST['digjy_manage_products_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['digjy_manage_products_nonce'])), 'digjy_manage_products')) {
            digjy_stores_safe_redirect(add_query_arg('digjy_products_notice', 'invalid_nonce', wp_get_referer() ?: home_url('/')));
        }
        $product_id = absint($_POST['digjy_product_id'] ?? 0);
        $product = $product_id ? get_post($product_id) : null;
        if (!$product || 'digjy_product' !== $product->post_type || (int) $product->post_author !== get_current_user_id()) {
            digjy_stores_safe_redirect(add_query_arg('digjy_products_notice', 'not_found', wp_get_referer() ?: home_url('/')));
        }
        wp_trash_post($product_id);
        digjy_stores_safe_redirect(remove_query_arg(['digjy_manage_product_id', 'digjy_product_id'], add_query_arg('digjy_products_notice', 'deleted', wp_get_referer() ?: home_url('/'))));
    }

    private function get_manage_products_notice_html() {
        $status = sanitize_key($_GET['digjy_products_notice'] ?? '');
        if (!$status) {
            return '';
        }
        $messages = [
            'deleted' => '<div class="digjy-success">' . esc_html__('Product deleted successfully.', 'digjy-stores') . '</div>',
            'permission' => '<div class="digjy-error">' . esc_html__('Only store owners can manage products.', 'digjy-stores') . '</div>',
            'invalid_nonce' => '<div class="digjy-error">' . esc_html__('Your session expired. Please try again.', 'digjy-stores') . '</div>',
            'not_found' => '<div class="digjy-error">' . esc_html__('That product could not be found.', 'digjy-stores') . '</div>',
        ];
        return $messages[$status] ?? '';
    }

    public function manage_products($atts = []) {
        wp_enqueue_style('digjy-stores');
        if (!$this->current_user_is_store_owner()) {
            return $this->wrap_output('<div class="digjy-alert">' . esc_html__('Please log in as a store owner to manage your digital products.', 'digjy-stores') . '</div>', 'digjy-shortcode-alert');
        }

        $atts = shortcode_atts([
            'posts_per_page' => 24,
            'show_builder' => 'true',
        ], $atts, 'digjy_manage_products');

        $edit_id = absint($_GET['digjy_manage_product_id'] ?? 0);
        $products = get_posts([
            'post_type' => 'digjy_product',
            'author' => get_current_user_id(),
            'posts_per_page' => max(1, (int) $atts['posts_per_page']),
            'post_status' => ['publish', 'draft', 'pending'],
            'orderby' => 'date',
            'order' => 'DESC',
        ]);

        ob_start();
        echo $this->get_manage_products_notice_html();

        if ($edit_id && filter_var($atts['show_builder'], FILTER_VALIDATE_BOOLEAN)) {
            echo $this->seller_product_builder(['product_id' => $edit_id]);
        }

        echo '<div class="digjy-card"><div class="digjy-manage-products-head"><h3>' . esc_html__('Manage Digital Products', 'digjy-stores') . '</h3><p class="digjy-help">' . esc_html__('View, edit, and delete your digital products from the front end.', 'digjy-stores') . '</p></div>';
        if (!$products) {
            echo '<p>' . esc_html__('No digital products found yet.', 'digjy-stores') . '</p></div>';
            return $this->wrap_output(ob_get_clean(), 'digjy-shortcode-block');
        }

        echo '<div class="digjy-product-grid">';
        foreach ($products as $product) {
            $product_id = (int) $product->ID;
            $price = (float) get_post_meta($product_id, '_digjy_price', true);
            $product_type = (string) get_post_meta($product_id, '_digjy_product_type', true);
            $featured = (string) get_post_meta($product_id, '_digjy_featured_image', true);
            $brief = (string) $product->post_excerpt;
            $status_obj = get_post_status_object($product->post_status);
            $edit_url = add_query_arg('digjy_manage_product_id', $product_id);
            $view_url = get_permalink($product_id);
            echo '<div class="digjy-product-card">';
            echo '<div class="digjy-product-card-media">';
            if ($featured) {
                echo '<img src="' . esc_url($featured) . '" alt="' . esc_attr($product->post_title) . '" />';
            } else {
                echo '<div class="digjy-product-card-placeholder">' . esc_html__('No Image', 'digjy-stores') . '</div>';
            }
            echo '</div>';
            echo '<div class="digjy-product-card-body">';
            echo '<div class="digjy-product-card-top"><h4>' . esc_html($product->post_title) . '</h4><span class="digjy-badge">' . esc_html($status_obj ? $status_obj->label : ucfirst($product->post_status)) . '</span></div>';
            echo '<p class="digjy-product-card-meta"><strong>' . esc_html__('Type:', 'digjy-stores') . '</strong> ' . esc_html($product_type ?: 'regular') . '</p>';
            echo '<p class="digjy-product-card-meta"><strong>' . esc_html__('Price:', 'digjy-stores') . '</strong> ' . esc_html('$' . number_format($price, 2)) . '</p>';
            if ($brief) {
                echo '<p class="digjy-product-card-excerpt">' . esc_html(wp_trim_words($brief, 18)) . '</p>';
            }
            echo '<div class="digjy-product-card-actions">';
            echo '<a class="digjy-btn" href="' . esc_url($view_url) . '">' . esc_html__('View', 'digjy-stores') . '</a>';
            echo '<a class="digjy-btn" href="' . esc_url($edit_url) . '">' . esc_html__('Edit', 'digjy-stores') . '</a>';
            echo '<form method="post" class="digjy-delete-product-form" onsubmit="return confirm(' . wp_json_encode(__('Delete this product?', 'digjy-stores')) . ');">';
            wp_nonce_field('digjy_manage_products', 'digjy_manage_products_nonce');
            echo '<input type="hidden" name="digjy_manage_products_action" value="delete_product" />';
            echo '<input type="hidden" name="digjy_product_id" value="' . esc_attr($product_id) . '" />';
            echo '<button type="submit" class="digjy-btn digjy-btn-secondary">' . esc_html__('Delete', 'digjy-stores') . '</button>';
            echo '</form>';
            echo '</div></div></div>';
        }
        echo '</div></div>';
        return $this->wrap_output(ob_get_clean(), 'digjy-shortcode-block');
    }

    public function current_store_url($atts = []) {
        wp_enqueue_style('digjy-stores');
        if (!$this->current_user_is_store_owner()) {
            return $this->wrap_output('<div class="digjy-alert">' . esc_html__('Please log in as a store owner to view your store URL.', 'digjy-stores') . '</div>', 'digjy-shortcode-alert');
        }

        $atts = shortcode_atts([
            'label' => '',
            'linked' => 'true',
            'class' => 'digjy-store-url-link',
        ], $atts, 'digjy_current_store_url');

        $user_id = get_current_user_id();
        $store_id = (int) get_user_meta($user_id, 'digjy_store_id', true);
        if (!$store_id) {
            $store = get_posts([
                'post_type' => 'digjy_store',
                'posts_per_page' => 1,
                'post_status' => 'publish',
                'author' => $user_id,
                'fields' => 'ids',
            ]);
            if (!empty($store[0])) {
                $store_id = (int) $store[0];
                update_user_meta($user_id, 'digjy_store_id', $store_id);
            }
        }

        if (!$store_id) {
            return $this->wrap_output('<div class="digjy-alert">' . esc_html__('No store was found for your account yet.', 'digjy-stores') . '</div>', 'digjy-shortcode-alert');
        }

        $url = get_permalink($store_id);
        if (!$url) {
            return $this->wrap_output('<div class="digjy-alert">' . esc_html__('Your store URL is not available yet.', 'digjy-stores') . '</div>', 'digjy-shortcode-alert');
        }

        $label = $atts['label'] !== '' ? $atts['label'] : $url;
        $linked = filter_var($atts['linked'], FILTER_VALIDATE_BOOLEAN);
        $html = $linked
            ? '<a class="' . esc_attr($atts['class']) . '" href="' . esc_url($url) . '">' . esc_html($label) . '</a>'
            : '<span class="' . esc_attr($atts['class']) . '">' . esc_html($label) . '</span>';

        return $this->wrap_output('<div class="digjy-store-url">' . $html . '</div>', 'digjy-shortcode-block');
    }

    public function edit_store_form() {
        wp_enqueue_style('digjy-stores');
        wp_enqueue_script('digjy-stores');
        if (!$this->current_user_is_store_owner()) {
            return $this->wrap_output('<div class="digjy-alert">' . esc_html__('Please log in as a store owner to edit your store.', 'digjy-stores') . '</div>', 'digjy-shortcode-alert');
        }
        $store = $this->get_current_store_post();
        if (!$store) {
            return $this->wrap_output('<div class="digjy-alert">' . esc_html__('No store was found for your account.', 'digjy-stores') . '</div>', 'digjy-shortcode-alert');
        }
        $logo = (string) get_post_meta($store->ID, '_digjy_store_logo', true);
        $seo = (string) get_post_meta($store->ID, '_digjy_store_seo', true);
        $x = (string) get_post_meta($store->ID, '_digjy_store_x', true);
        $instagram = (string) get_post_meta($store->ID, '_digjy_store_instagram', true);
        $tiktok = (string) get_post_meta($store->ID, '_digjy_store_tiktok', true);
        $facebook = (string) get_post_meta($store->ID, '_digjy_store_facebook', true);
        ob_start();
        echo $this->get_store_form_notice_html();
        echo '<div class="digjy-card"><h3>' . esc_html__('Edit Store', 'digjy-stores') . '</h3>';
        echo '<form method="post" enctype="multipart/form-data" class="digjy-form-grid digjy-store-edit-form">';
        wp_nonce_field('digjy_edit_store', 'digjy_edit_store_nonce');
        echo '<input type="hidden" name="digjy_store_action" value="edit_store" />';
        echo '<input type="hidden" name="digjy_store_id" value="' . esc_attr($store->ID) . '" />';
        echo '<p><label>' . esc_html__('Store Logo', 'digjy-stores') . '</label><input type="file" name="digjy_store_logo" accept="image/*" />';
        if ($logo) {
            echo '<span class="digjy-help">' . esc_html__('Current Logo:', 'digjy-stores') . ' <a href="' . esc_url($logo) . '" target="_blank" rel="noopener">' . esc_html__('View Logo', 'digjy-stores') . '</a></span>';
        }
        echo '</p>';
        echo '<p><label>' . esc_html__('Store Name', 'digjy-stores') . '</label><input type="text" name="digjy_store_name" value="' . esc_attr($store->post_title) . '" required /></p>';
        echo '<p><label>' . esc_html__('Store Description', 'digjy-stores') . '</label><textarea name="digjy_store_description" rows="6" required>' . esc_textarea($store->post_content) . '</textarea></p>';
        echo '<p><label>' . esc_html__('Store SEO', 'digjy-stores') . '</label><span class="digjy-inline-action"><textarea name="digjy_store_seo" rows="5" class="digjy-store-seo-field">' . esc_textarea($seo) . '</textarea><button type="button" class="digjy-btn digjy-generate-store-seo">' . esc_html__('Generate With AI', 'digjy-stores') . '</button></span><span class="digjy-help">' . esc_html__('Generate top-ranking store page SEO using your store name and description.', 'digjy-stores') . '</span></p>';
        echo '<div class="digjy-two-col">';
        echo '<p><label>' . esc_html__('Add X (Optional)', 'digjy-stores') . '</label><input type="url" name="digjy_store_x" value="' . esc_attr($x) . '" placeholder="https://x.com/yourstore" /></p>';
        echo '<p><label>' . esc_html__('Add Instagram (Optional)', 'digjy-stores') . '</label><input type="url" name="digjy_store_instagram" value="' . esc_attr($instagram) . '" placeholder="https://instagram.com/yourstore" /></p>';
        echo '<p><label>' . esc_html__('Add TikTok (Optional)', 'digjy-stores') . '</label><input type="url" name="digjy_store_tiktok" value="' . esc_attr($tiktok) . '" placeholder="https://tiktok.com/@yourstore" /></p>';
        echo '<p><label>' . esc_html__('Add Facebook (Optional)', 'digjy-stores') . '</label><input type="url" name="digjy_store_facebook" value="' . esc_attr($facebook) . '" placeholder="https://facebook.com/yourstore" /></p>';
        echo '</div>';
        echo '<p><button type="submit" class="digjy-btn">' . esc_html__('Save Store', 'digjy-stores') . '</button></p>';
        echo '</form></div>';
        return $this->wrap_output(ob_get_clean(), 'digjy-shortcode-block');
    }

    public function handle_store_edit_form() {
        if (empty($_POST['digjy_store_action']) || 'edit_store' !== sanitize_text_field(wp_unslash($_POST['digjy_store_action']))) {
            return;
        }
        if (!$this->current_user_is_store_owner()) {
            wp_safe_redirect(add_query_arg('digjy_store_updated', 'permission', wp_get_referer() ?: home_url('/'))); exit;
        }
        if (!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['digjy_edit_store_nonce'] ?? '')), 'digjy_edit_store')) {
            return;
        }
        $store = $this->get_current_store_post();
        if (!$store) {
            wp_safe_redirect(add_query_arg('digjy_store_updated', 'missing_store', wp_get_referer() ?: home_url('/'))); exit;
        }
        $store_id = (int) $store->ID;
        wp_update_post([
            'ID' => $store_id,
            'post_title' => sanitize_text_field(wp_unslash($_POST['digjy_store_name'] ?? '')),
            'post_content' => wp_kses_post(wp_unslash($_POST['digjy_store_description'] ?? '')),
            'post_excerpt' => sanitize_textarea_field(wp_unslash($_POST['digjy_store_seo'] ?? '')),
        ]);
        if (isset($_FILES['digjy_store_logo']) && !empty($_FILES['digjy_store_logo']['tmp_name'])) {
            $upload = $this->upload_file_to_jsdelivr($_FILES['digjy_store_logo']);
            if (is_wp_error($upload)) {
                $status = 'upload_error';
                if ('digjy_jsdelivr_missing_settings' === $upload->get_error_code()) {
                    $status = 'missing_settings';
                }
                wp_safe_redirect(add_query_arg('digjy_store_updated', $status, wp_get_referer() ?: home_url('/'))); exit;
            }
            update_post_meta($store_id, '_digjy_store_logo', esc_url_raw($upload['file_url']));
            update_post_meta($store_id, '_digjy_store_logo_repository_path', sanitize_text_field($upload['repository_path']));
        }
        update_post_meta($store_id, '_digjy_store_seo', sanitize_textarea_field(wp_unslash($_POST['digjy_store_seo'] ?? '')));
        update_post_meta($store_id, '_digjy_store_x', esc_url_raw(wp_unslash($_POST['digjy_store_x'] ?? '')));
        update_post_meta($store_id, '_digjy_store_instagram', esc_url_raw(wp_unslash($_POST['digjy_store_instagram'] ?? '')));
        update_post_meta($store_id, '_digjy_store_tiktok', esc_url_raw(wp_unslash($_POST['digjy_store_tiktok'] ?? '')));
        update_post_meta($store_id, '_digjy_store_facebook', esc_url_raw(wp_unslash($_POST['digjy_store_facebook'] ?? '')));
        update_user_meta(get_current_user_id(), 'digjy_store_id', $store_id);
        wp_safe_redirect(add_query_arg('digjy_store_updated', 'success', wp_get_referer() ?: get_permalink($store_id))); exit;
    }

    public function ajax_generate_store_seo() {
        check_ajax_referer('digjy_stores_nonce', 'nonce');
        if (!$this->current_user_is_store_owner()) {
            wp_send_json_error(['message' => __('Only store owners can generate store SEO.', 'digjy-stores')], 403);
        }
        $settings = Digjy_Stores::get_settings();
        $api_key = trim((string) ($settings['groq_api_key'] ?? ''));
        if (!$api_key) {
            wp_send_json_error(['message' => __('Add your GROQ API key in Digjy Stores settings first.', 'digjy-stores')], 400);
        }
        $store_name = sanitize_text_field(wp_unslash($_POST['store_name'] ?? ''));
        $description = sanitize_textarea_field(wp_unslash($_POST['store_description'] ?? ''));
        if (!$store_name && !$description) {
            wp_send_json_error(['message' => __('Enter your store name or description first.', 'digjy-stores')], 400);
        }
        $prompt = "Write high-converting SEO for a digital marketplace store page. Return only plain text with: SEO Title, Meta Description, SEO Keywords, and Short On-Page SEO Copy. Make it strong, clear, search-focused, and based on this store.\n\nStore Name: {$store_name}\nStore Description: {$description}";
        $response = wp_remote_post('https://api.groq.com/openai/v1/chat/completions', [
            'timeout' => 60,
            'headers' => [
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type' => 'application/json',
            ],
            'body' => wp_json_encode([
                'model' => 'openai/gpt-oss-120b',
                'messages' => [
                    ['role' => 'system', 'content' => 'You are an expert SEO copywriter for digital product marketplace store pages.'],
                    ['role' => 'user', 'content' => $prompt],
                ],
                'temperature' => 0.6,
            ]),
        ]);
        if (is_wp_error($response)) {
            wp_send_json_error(['message' => $response->get_error_message()], 500);
        }
        $body = json_decode(wp_remote_retrieve_body($response), true);
        $content = trim((string) ($body['choices'][0]['message']['content'] ?? ''));
        if (!$content) {
            wp_send_json_error(['message' => __('No SEO text was returned by the AI service.', 'digjy-stores')], 500);
        }
        wp_send_json_success(['seo' => $content]);
    }

    private function upload_file_to_jsdelivr($file) {
        if (empty($file['tmp_name']) || !empty($file['error'])) {
            return new WP_Error('digjy_upload_missing', __('No file was uploaded.', 'digjy-stores'));
        }
        $settings = Digjy_Stores::get_settings();
        $owner = trim((string) ($settings['jsdelivr_github_owner'] ?? ''));
        $repo = trim((string) ($settings['jsdelivr_github_repo'] ?? ''));
        $branch = trim((string) ($settings['jsdelivr_github_branch'] ?? 'main'));
        $token = trim((string) ($settings['jsdelivr_github_token'] ?? ''));
        $folder = trim((string) ($settings['jsdelivr_upload_folder'] ?? 'digjy-products'));
        $missing = $this->get_jsdelivr_missing_settings();
        if (!empty($missing)) {
            return new WP_Error('digjy_jsdelivr_missing_settings', sprintf(__('Missing jsDelivr/GitHub settings: %s.', 'digjy-stores'), implode(', ', $missing)));
        }
        $filename = sanitize_file_name($file['name']);
        $filename = time() . '-' . $filename;
        $path = trim($folder, '/') . '/' . gmdate('Y/m') . '/' . $filename;
        $contents = file_get_contents($file['tmp_name']);
        if (false === $contents) {
            return new WP_Error('digjy_upload_read_failed', __('The uploaded file could not be read.', 'digjy-stores'));
        }
        $endpoint = sprintf('https://api.github.com/repos/%s/%s/contents/%s', rawurlencode($owner), rawurlencode($repo), str_replace('%2F', '/', rawurlencode($path)));
        $response = wp_remote_request($endpoint, [
            'method' => 'PUT',
            'timeout' => 60,
            'headers' => [
                'Authorization' => 'Bearer ' . $token,
                'Accept' => 'application/vnd.github+json',
                'User-Agent' => 'Digjy-Stores',
                'X-GitHub-Api-Version' => '2022-11-28',
            ],
            'body' => wp_json_encode([
                'message' => 'Digjy Stores upload: ' . $filename,
                'content' => base64_encode($contents),
                'branch' => $branch,
            ]),
        ]);
        if (is_wp_error($response)) {
            return $response;
        }
        $code = (int) wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);
        if ($code < 200 || $code >= 300) {
            return new WP_Error('digjy_jsdelivr_upload_failed', isset($body['message']) ? (string) $body['message'] : __('GitHub upload failed.', 'digjy-stores'));
        }
        return [
            'file_url' => sprintf('https://cdn.jsdelivr.net/gh/%s/%s@%s/%s', rawurlencode($owner), rawurlencode($repo), rawurlencode($branch), str_replace('%2F', '/', rawurlencode($path))),
            'repository_path' => $path,
        ];
    }


    private function normalize_uploaded_files($field_name) {
        if (empty($_FILES[$field_name])) {
            return [];
        }
        $files = $_FILES[$field_name];
        $normalized = [];
        if (is_array($files['name'] ?? null)) {
            $count = count($files['name']);
            for ($i = 0; $i < $count; $i++) {
                if (empty($files['name'][$i]) || empty($files['tmp_name'][$i])) {
                    continue;
                }
                $normalized[] = [
                    'name' => $files['name'][$i] ?? '',
                    'type' => $files['type'][$i] ?? '',
                    'tmp_name' => $files['tmp_name'][$i] ?? '',
                    'error' => $files['error'][$i] ?? 0,
                    'size' => $files['size'][$i] ?? 0,
                ];
            }
        } elseif (!empty($files['name']) && !empty($files['tmp_name'])) {
            $normalized[] = $files;
        }
        return $normalized;
    }

    private function upload_multiple_files_to_jsdelivr($field_name) {
        $uploads = [];
        foreach ($this->normalize_uploaded_files($field_name) as $file) {
            $upload = $this->upload_file_to_jsdelivr($file);
            if (is_wp_error($upload)) {
                return $upload;
            }
            $uploads[] = $upload;
        }
        return $uploads;
    }

    public function handle_digital_product_submission_forms() {
        if (empty($_POST['digjy_submission_action']) || 'submit_product_form' !== sanitize_text_field(wp_unslash($_POST['digjy_submission_action']))) {
            return;
        }
        if (!$this->current_user_is_store_owner()) {
            wp_safe_redirect(add_query_arg('digjy_submission', 'permission', wp_get_referer() ?: home_url('/'))); exit;
        }
        $proof_type = sanitize_key(wp_unslash($_POST['digjy_submission_proof_type'] ?? 'none'));
        if (!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['digjy_submit_product_nonce'] ?? '')), 'digjy_submit_product_' . $proof_type)) {
            return;
        }
        $download_uploads = $this->upload_multiple_files_to_jsdelivr('digjy_submission_files');
        if (empty($download_uploads) && !empty($_FILES['digjy_submission_file']['tmp_name'])) {
            $single_upload = $this->upload_file_to_jsdelivr($_FILES['digjy_submission_file']);
            $download_uploads = is_wp_error($single_upload) ? $single_upload : [$single_upload];
        }
        if (empty($download_uploads)) {
            $download_uploads = new WP_Error('digjy_upload_missing', __('Please upload at least one downloadable file or ZIP file.', 'digjy-stores'));
        }
        if (is_wp_error($download_uploads)) {
            $status = 'upload_error';
            if ('digjy_jsdelivr_missing_settings' === $download_uploads->get_error_code()) {
                $status = 'missing_settings';
            }
            wp_safe_redirect(add_query_arg('digjy_submission', $status, wp_get_referer() ?: home_url('/'))); exit;
        }
        $primary_download_upload = $download_uploads[0];
        $featured_image_upload = null;
        if (isset($_FILES['digjy_submission_featured_image']) && !empty($_FILES['digjy_submission_featured_image']['tmp_name'])) {
            $featured_image_upload = $this->upload_file_to_jsdelivr($_FILES['digjy_submission_featured_image']);
            if (is_wp_error($featured_image_upload)) {
                $status = 'upload_error';
                if ('digjy_jsdelivr_missing_settings' === $featured_image_upload->get_error_code()) {
                    $status = 'missing_settings';
                }
                wp_safe_redirect(add_query_arg('digjy_submission', $status, wp_get_referer() ?: home_url('/'))); exit;
            }
        }
        $gallery_uploads = [];
        if (!empty($_FILES['digjy_submission_gallery']) && is_array($_FILES['digjy_submission_gallery']['name'] ?? null)) {
            $gallery_count = count($_FILES['digjy_submission_gallery']['name']);
            for ($i = 0; $i < $gallery_count; $i++) {
                if (empty($_FILES['digjy_submission_gallery']['tmp_name'][$i])) {
                    continue;
                }
                $gallery_file = [
                    'name' => $_FILES['digjy_submission_gallery']['name'][$i] ?? '',
                    'type' => $_FILES['digjy_submission_gallery']['type'][$i] ?? '',
                    'tmp_name' => $_FILES['digjy_submission_gallery']['tmp_name'][$i] ?? '',
                    'error' => $_FILES['digjy_submission_gallery']['error'][$i] ?? 0,
                    'size' => $_FILES['digjy_submission_gallery']['size'][$i] ?? 0,
                ];
                $gallery_upload = $this->upload_file_to_jsdelivr($gallery_file);
                if (is_wp_error($gallery_upload)) {
                    $status = 'upload_error';
                    if ('digjy_jsdelivr_missing_settings' === $gallery_upload->get_error_code()) {
                        $status = 'missing_settings';
                    }
                    wp_safe_redirect(add_query_arg('digjy_submission', $status, wp_get_referer() ?: home_url('/'))); exit;
                }
                $gallery_uploads[] = $gallery_upload;
            }
        }
        $video_uploads = [];
        if (!empty($_FILES['digjy_submission_videos']) && is_array($_FILES['digjy_submission_videos']['name'] ?? null)) {
            $video_count = count($_FILES['digjy_submission_videos']['name']);
            for ($i = 0; $i < $video_count; $i++) {
                if (empty($_FILES['digjy_submission_videos']['tmp_name'][$i])) {
                    continue;
                }
                $video_file = [
                    'name' => $_FILES['digjy_submission_videos']['name'][$i] ?? '',
                    'type' => $_FILES['digjy_submission_videos']['type'][$i] ?? '',
                    'tmp_name' => $_FILES['digjy_submission_videos']['tmp_name'][$i] ?? '',
                    'error' => $_FILES['digjy_submission_videos']['error'][$i] ?? 0,
                    'size' => $_FILES['digjy_submission_videos']['size'][$i] ?? 0,
                ];
                $video_upload = $this->upload_file_to_jsdelivr($video_file);
                if (is_wp_error($video_upload)) {
                    $status = 'upload_error';
                    if ('digjy_jsdelivr_missing_settings' === $video_upload->get_error_code()) {
                        $status = 'missing_settings';
                    }
                    digjy_stores_safe_redirect(add_query_arg('digjy_submission', $status, wp_get_referer() ?: home_url('/')));
                }
                $video_uploads[] = $video_upload;
            }
        }
        $user_id = get_current_user_id();
        $product_id = wp_insert_post([
            'post_type' => 'digjy_product',
            'post_status' => 'publish',
            'post_author' => $user_id,
            'post_title' => sanitize_text_field(wp_unslash($_POST['digjy_submission_title'] ?? '')),
            'post_excerpt' => sanitize_textarea_field(wp_unslash($_POST['digjy_submission_brief'] ?? '')),
            'post_content' => wp_kses_post(wp_unslash($_POST['digjy_submission_description'] ?? '')),
        ]);
        if (!$product_id || is_wp_error($product_id)) {
            wp_safe_redirect(add_query_arg('digjy_submission', 'upload_error', wp_get_referer() ?: home_url('/'))); exit;
        }
        $is_proof = in_array($proof_type, ['poo', 'poa'], true);
        update_post_meta($product_id, '_digjy_price', (float) ($_POST['digjy_submission_price'] ?? 0));
        update_post_meta($product_id, '_digjy_file_url', esc_url_raw($primary_download_upload['file_url']));
        update_post_meta($product_id, '_digjy_file_urls', array_values(array_map(static function ($item) { return esc_url_raw($item['file_url']); }, $download_uploads)));
        update_post_meta($product_id, '_digjy_license', sanitize_textarea_field(wp_unslash($_POST['digjy_submission_license'] ?? '')));
        update_post_meta($product_id, '_digjy_purchase_note', wp_kses_post(wp_unslash($_POST['digjy_submission_purchase_note'] ?? '')));
        update_post_meta($product_id, '_digjy_product_type', $is_proof ? 'minted_digital' : 'regular');
        update_post_meta($product_id, '_digjy_proof_type', $proof_type);
        update_post_meta($product_id, '_digjy_asset_mode', 'poa' === $proof_type ? 'lazy_minted' : ($is_proof ? 'minted' : 'regular'));
        update_post_meta($product_id, '_digjy_repository_path', sanitize_text_field($primary_download_upload['repository_path']));
        update_post_meta($product_id, '_digjy_repository_paths', array_values(array_map(static function ($item) { return sanitize_text_field($item['repository_path']); }, $download_uploads)));
        if ($featured_image_upload && !is_wp_error($featured_image_upload)) {
            update_post_meta($product_id, '_digjy_featured_image', esc_url_raw($featured_image_upload['file_url']));
            update_post_meta($product_id, '_digjy_featured_image_repository_path', sanitize_text_field($featured_image_upload['repository_path']));
            update_post_meta($product_id, '_thumbnail_external_url', esc_url_raw($featured_image_upload['file_url']));
        }
        if (!empty($gallery_uploads)) {
            update_post_meta($product_id, '_digjy_gallery_images', array_values(array_map(static function ($item) { return esc_url_raw($item['file_url']); }, $gallery_uploads)));
            update_post_meta($product_id, '_digjy_gallery_repository_paths', array_values(array_map(static function ($item) { return sanitize_text_field($item['repository_path']); }, $gallery_uploads)));
        }
        if (!empty($video_uploads)) {
            update_post_meta($product_id, '_digjy_video_urls', array_values(array_map(static function ($item) { return esc_url_raw($item['file_url']); }, $video_uploads)));
            update_post_meta($product_id, '_digjy_video_repository_paths', array_values(array_map(static function ($item) { return sanitize_text_field($item['repository_path']); }, $video_uploads)));
        }
        update_post_meta($product_id, '_digjy_wallet_provider', sanitize_text_field(wp_unslash($_POST['digjy_wallet_provider'] ?? '')));
        update_post_meta($product_id, '_digjy_wallet_address', sanitize_text_field(wp_unslash($_POST['digjy_wallet_address'] ?? '')));
        update_post_meta($product_id, '_digjy_admin_fee', 'poo' === $proof_type ? 25 : 0);
        update_post_meta($product_id, '_digjy_chain', $is_proof ? 'solana' : '');
        update_post_meta($product_id, '_digjy_onchain_status', $is_proof ? 'configured' : 'regular');
        $category_id = absint($_POST['digjy_submission_category'] ?? 0);
        if ($category_id) {
            wp_set_object_terms($product_id, [$category_id], 'digjy_product_category', false);
            $term = get_term($category_id, 'digjy_product_category');
            if ($term && !is_wp_error($term)) {
                update_post_meta($product_id, '_digjy_category', $term->name);
                update_post_meta($product_id, '_digjy_category_id', $category_id);
            }
        }
        $tags = sanitize_text_field(wp_unslash($_POST['digjy_submission_tags'] ?? ''));
        if ($tags) {
            wp_set_post_tags($product_id, $tags, false);
        }
        digjy_stores_safe_redirect(add_query_arg('digjy_submission', 'success', wp_get_referer() ?: get_permalink($product_id)));
    }

    public function buy_now($atts) {
        wp_enqueue_style('digjy-stores');
        $atts = shortcode_atts(['product_id' => 0, 'label' => __('Buy Now', 'digjy-stores')], $atts, 'digjy_buy_now');
        $product_id = absint($atts['product_id']);
        if (!$product_id) {
            return '';
        }
        $product_data = $this->get_basic_product_card_data($product_id);
        $product_json = $product_data ? esc_attr(wp_json_encode($product_data)) : '';
        $html = '<span class="digjy-product-context" data-product="' . $product_json . '"></span>';
        $html .= '<button class="digjy-btn digjy-buy-now" data-product-id="' . esc_attr($product_id) . '">' . esc_html($atts['label']) . '</button> ';
        $html .= '<button type="button" class="digjy-btn digjy-save-dig-list" data-product="' . $product_json . '">' . esc_html__('Add To My Dig List', 'digjy-stores') . '</button> ';
        $html .= '<button type="button" class="digjy-btn digjy-save-cart" data-product="' . $product_json . '">' . esc_html__('Add To Cart', 'digjy-stores') . '</button>';
        return $this->wrap_output($html, 'digjy-shortcode-buy-now');
    }

    public function digital_checkout($atts) {
        wp_enqueue_style('digjy-stores');
        wp_enqueue_script('digjy-stores');
        $atts = shortcode_atts(['product_id' => 0], $atts, 'digjy_digital_checkout');
        $product_id = absint($atts['product_id']);
        if (!$product_id) {
            return $this->wrap_output('<div class="digjy-alert">' . esc_html__('Missing product ID.', 'digjy-stores') . '</div>', 'digjy-shortcode-alert');
        }
        $settings = Digjy_Stores::get_settings();
        ob_start(); ?>
        <div class="digjy-card digjy-checkout-shell" data-product-id="<?php echo esc_attr($product_id); ?>">
            <h3><?php esc_html_e('Digital Checkout', 'digjy-stores'); ?></h3>
            <form class="digjy-checkout-form" data-product-id="<?php echo esc_attr($product_id); ?>">
                <div class="digjy-payment-methods">
                    <label class="digjy-pay-option <?php echo (($settings['default_payment_method'] ?? 'solana') === 'card') ? 'active' : ''; ?>"><input type="radio" name="payment_method" value="card" <?php checked(($settings['default_payment_method'] ?? 'solana'), 'card'); ?> /> <?php esc_html_e('Pay with Card', 'digjy-stores'); ?></label>
                    <label class="digjy-pay-option <?php echo (($settings['default_payment_method'] ?? 'solana') === 'solana') ? 'active' : ''; ?>"><input type="radio" name="payment_method" value="solana" <?php checked(($settings['default_payment_method'] ?? 'solana'), 'solana'); ?> /> <?php esc_html_e('Pay with Solana', 'digjy-stores'); ?></label>
                </div>
                <p><label><?php esc_html_e('Buyer Email', 'digjy-stores'); ?></label><input type="email" name="buyer_email" required /></p>
                <p><label><?php esc_html_e('Recipient Wallet (optional)', 'digjy-stores'); ?></label><input type="text" name="recipient_wallet" placeholder="Solana wallet to receive the asset" /></p>
                <div class="digjy-payment-panel digjy-panel-card" data-method="card" <?php echo (($settings['default_payment_method'] ?? 'solana') === 'card') ? '' : 'style="display:none;"'; ?>>
                    <p class="digjy-help"><?php esc_html_e('Use this to create a Crossmint card order. You can also use the dedicated embedded card shortcode for an in-page card component.', 'digjy-stores'); ?></p>
                </div>
                <div class="digjy-payment-panel digjy-panel-solana" data-method="solana" <?php echo (($settings['default_payment_method'] ?? 'solana') === 'solana') ? '' : 'style="display:none;"'; ?>>
                    <p><label><?php esc_html_e('Payer Wallet', 'digjy-stores'); ?></label><input type="text" name="payer_address" placeholder="Solana wallet address" /></p>
                    <p><button type="button" class="digjy-btn-secondary digjy-connect-phantom"><?php esc_html_e('Connect Phantom', 'digjy-stores'); ?></button></p>
                    <p class="digjy-help"><?php esc_html_e('For Solana payments, the plugin will use the serialized transaction returned by Crossmint and ask Phantom to sign and submit it.', 'digjy-stores'); ?></p>
                </div>
                <button type="submit" class="digjy-btn"><?php esc_html_e('Create Checkout', 'digjy-stores'); ?></button>
                <div class="digjy-response"></div>
                <div class="digjy-status-wrap" style="display:none;">
                    <div class="digjy-status-badge"><span class="digjy-status-dot"></span><strong class="digjy-status-code"></strong></div>
                    <p class="digjy-status-label"></p>
                    <div class="digjy-status-meta"></div>
                    <div class="digjy-status-actions">
                        <button type="button" class="digjy-btn digjy-refresh-status"><?php esc_html_e('Refresh Status', 'digjy-stores'); ?></button>
                    </div>
                </div>
            </form>
        </div>
        <?php return $this->wrap_output(ob_get_clean(), 'digjy-shortcode-block');
    }

    public function embedded_card_checkout($atts) {
        wp_enqueue_style('digjy-stores');
        wp_enqueue_script('digjy-stores');
        $atts = shortcode_atts(['product_id' => 0], $atts, 'digjy_crossmint_embedded_card');
        $product_id = absint($atts['product_id']);
        if (!$product_id) {
            return $this->wrap_output('<div class="digjy-alert">' . esc_html__('Missing product ID.', 'digjy-stores') . '</div>', 'digjy-shortcode-alert');
        }
        ob_start();
        ?>
        <div class="digjy-card digjy-embedded-card-shell" data-product-id="<?php echo esc_attr($product_id); ?>">
            <h3><?php esc_html_e('Embedded Card Checkout', 'digjy-stores'); ?></h3>
            <form class="digjy-embedded-card-form" data-product-id="<?php echo esc_attr($product_id); ?>">
                <p><label><?php esc_html_e('Buyer Email', 'digjy-stores'); ?></label><input type="email" name="buyer_email" required /></p>
                <p><label><?php esc_html_e('Recipient Wallet (optional)', 'digjy-stores'); ?></label><input type="text" name="recipient_wallet" placeholder="Solana wallet to receive the asset" /></p>
                <button type="submit" class="digjy-btn"><?php esc_html_e('Load Embedded Card Checkout', 'digjy-stores'); ?></button>
                <div class="digjy-response"></div>
            </form>
            <div class="digjy-embedded-mount"></div>
            <div class="digjy-status-wrap" style="display:none;">
                <div class="digjy-status-badge"><span class="digjy-status-dot"></span><strong class="digjy-status-code"></strong></div>
                <p class="digjy-status-label"></p>
                <div class="digjy-status-meta"></div>
                <div class="digjy-status-actions"><button type="button" class="digjy-btn digjy-refresh-status"><?php esc_html_e('Refresh Status', 'digjy-stores'); ?></button></div>
            </div>
        </div>
        <?php
        return $this->wrap_output(ob_get_clean(), 'digjy-shortcode-block');
    }


    public function customer_register() {
        wp_enqueue_style('digjy-stores');
        if (is_user_logged_in()) {
            return '<div class="digjy-alert digjy-alert-success">' . esc_html__('You are already logged in.', 'digjy-stores') . '</div>';
        }
        ob_start(); ?>
        <form method="post" class="digjy-card digjy-form-grid digjy-account-form">
            <h3><?php esc_html_e('Create Customer Account', 'digjy-stores'); ?></h3>
            <?php wp_nonce_field('digjy_customer_register', 'digjy_customer_register_nonce'); ?>
            <div class="digjy-two-col">
                <p><label><?php esc_html_e('First Name', 'digjy-stores'); ?></label><input type="text" name="first_name" /></p>
                <p><label><?php esc_html_e('Last Name', 'digjy-stores'); ?></label><input type="text" name="last_name" /></p>
            </div>
            <p><label><?php esc_html_e('Username', 'digjy-stores'); ?></label><input type="text" name="username" required /></p>
            <p><label><?php esc_html_e('Email', 'digjy-stores'); ?></label><input type="email" name="email" required /></p>
            <p><label><?php esc_html_e('Password', 'digjy-stores'); ?></label><input type="password" name="password" required /></p>
            <p><button type="submit" class="digjy-btn"><?php esc_html_e('Create Account', 'digjy-stores'); ?></button></p>
        </form>
        <?php return $this->wrap_output(ob_get_clean(), 'digjy-shortcode-block');
    }

    public function store_login() {
        wp_enqueue_style('digjy-stores');
        if (is_user_logged_in()) {
            $user = wp_get_current_user();
            if (in_array('digjy_seller', (array) $user->roles, true) || in_array('digjy_store_owner', (array) $user->roles, true) || current_user_can('manage_options')) {
                return $this->wrap_output('<div class="digjy-alert digjy-alert-success">' . esc_html__('You are already logged in to your store account.', 'digjy-stores') . '</div>', 'digjy-shortcode-alert');
            }
        }
        ob_start(); ?>
        <form method="post" class="digjy-card digjy-form-grid digjy-account-form digjy-store-login-form">
            <h3><?php esc_html_e('Store Login', 'digjy-stores'); ?></h3>
            <?php wp_nonce_field('digjy_store_login', 'digjy_store_login_nonce'); ?>
            <p><label><?php esc_html_e('Username or Email', 'digjy-stores'); ?></label><input type="text" name="log" required /></p>
            <p><label><?php esc_html_e('Password', 'digjy-stores'); ?></label><input type="password" name="pwd" required /></p>
            <p><label><input type="checkbox" name="rememberme" value="forever" /> <?php esc_html_e('Remember me', 'digjy-stores'); ?></label></p>
            <input type="hidden" name="digjy_store_redirect" value="1" />
            <p><button type="submit" class="digjy-btn"><?php esc_html_e('Store Sign In', 'digjy-stores'); ?></button></p>
        </form>
        <?php return $this->wrap_output(ob_get_clean(), 'digjy-shortcode-block');
    }

    public function customer_login() {
        wp_enqueue_style('digjy-stores');
        if (is_user_logged_in()) {
            return '<div class="digjy-alert digjy-alert-success">' . esc_html__('You are already logged in.', 'digjy-stores') . '</div>';
        }
        ob_start(); ?>
        <form method="post" class="digjy-card digjy-form-grid digjy-account-form">
            <h3><?php esc_html_e('Customer Login', 'digjy-stores'); ?></h3>
            <?php wp_nonce_field('digjy_customer_login', 'digjy_customer_login_nonce'); ?>
            <p><label><?php esc_html_e('Username or Email', 'digjy-stores'); ?></label><input type="text" name="log" required /></p>
            <p><label><?php esc_html_e('Password', 'digjy-stores'); ?></label><input type="password" name="pwd" required /></p>
            <p><label><input type="checkbox" name="rememberme" value="forever" /> <?php esc_html_e('Remember me', 'digjy-stores'); ?></label></p>
            <p><button type="submit" class="digjy-btn"><?php esc_html_e('Log In', 'digjy-stores'); ?></button></p>
        </form>
        <?php return $this->wrap_output(ob_get_clean(), 'digjy-shortcode-block');
    }

    public function my_account($atts = []) {
        wp_enqueue_style('digjy-stores');
        wp_enqueue_script('digjy-stores');
        if (!is_user_logged_in()) {
            ob_start();
            echo '<div class="digjy-account-shell">';
            echo '<div class="digjy-card"><h3>' . esc_html__('My Account', 'digjy-stores') . '</h3><p>' . esc_html__('Please log in or create a customer account to continue.', 'digjy-stores') . '</p></div>';
            echo '<div class="digjy-grid digjy-account-auth-grid">';
            echo '<div>' . $this->customer_login() . '</div>';
            echo '<div>' . $this->customer_register() . '</div>';
            echo '</div></div>';
            return ob_get_clean();
        }

        $atts = shortcode_atts(['tab' => 'dashboard'], $atts, 'digjy_my_account');
        $allowed_tabs = ['dashboard', 'orders', 'downloads', 'account-details'];
        $current_tab = isset($_GET['digjy_account_tab']) ? sanitize_key(wp_unslash($_GET['digjy_account_tab'])) : sanitize_key($atts['tab']);
        if (!in_array($current_tab, $allowed_tabs, true)) {
            $current_tab = 'dashboard';
        }

        $user = wp_get_current_user();
        $orders = get_posts(['post_type' => 'digjy_order', 'post_status' => 'publish', 'posts_per_page' => 100, 'meta_key' => '_digjy_buyer_email', 'meta_value' => $user->user_email]);
        $paid_orders = array_filter($orders, function($order) {
            return in_array(get_post_meta($order->ID, '_digjy_order_status', true), ['paid', 'completed'], true);
        });
        $downloads_count = count($paid_orders);
        $spent = 0.0;
        foreach ($orders as $order) {
            $spent += (float) get_post_meta($order->ID, '_digjy_total_amount', true);
            if (!$spent) {
                $spent += (float) get_post_meta($order->ID, '_digjy_product_price', true);
            }
        }

        $base_url = get_permalink();
        if (!$base_url) { $base_url = home_url('/'); }
        $tab_url = function($tab) use ($base_url) { return esc_url(add_query_arg('digjy_account_tab', $tab, $base_url)); };

        ob_start();
        ?>
        <div class="digjy-account-shell">
            <div class="digjy-account-sidebar digjy-card">
                <h3><?php esc_html_e('My Account', 'digjy-stores'); ?></h3>
                <p><?php echo esc_html(sprintf(__('Hello %s', 'digjy-stores'), $user->display_name ?: $user->user_login)); ?></p>
                <nav class="digjy-account-nav">
                    <a class="<?php echo $current_tab === 'dashboard' ? 'active' : ''; ?>" href="<?php echo $tab_url('dashboard'); ?>"><?php esc_html_e('Dashboard', 'digjy-stores'); ?></a>
                    <a class="<?php echo $current_tab === 'orders' ? 'active' : ''; ?>" href="<?php echo $tab_url('orders'); ?>"><?php esc_html_e('Orders', 'digjy-stores'); ?></a>
                    <a class="<?php echo $current_tab === 'downloads' ? 'active' : ''; ?>" href="<?php echo $tab_url('downloads'); ?>"><?php esc_html_e('Downloads', 'digjy-stores'); ?></a>
                    <a class="<?php echo $current_tab === 'account-details' ? 'active' : ''; ?>" href="<?php echo $tab_url('account-details'); ?>"><?php esc_html_e('Account Details', 'digjy-stores'); ?></a>
                    <a href="<?php echo esc_url(wp_logout_url($base_url)); ?>"><?php esc_html_e('Log Out', 'digjy-stores'); ?></a>
                </nav>
            </div>
            <div class="digjy-account-content">
                <?php if ($current_tab === 'dashboard') : ?>
                    <div class="digjy-grid digjy-account-stats">
                        <div class="digjy-card"><h4><?php esc_html_e('Orders', 'digjy-stores'); ?></h4><p class="digjy-stat-number"><?php echo esc_html(count($orders)); ?></p></div>
                        <div class="digjy-card"><h4><?php esc_html_e('Downloads Ready', 'digjy-stores'); ?></h4><p class="digjy-stat-number"><?php echo esc_html($downloads_count); ?></p></div>
                        <div class="digjy-card"><h4><?php esc_html_e('Total Spent', 'digjy-stores'); ?></h4><p class="digjy-stat-number"><?php echo esc_html('$' . number_format($spent, 2)); ?></p></div>
                    </div>
                    <div class="digjy-card">
                        <h3><?php esc_html_e('Welcome to your account', 'digjy-stores'); ?></h3>
                        <p><?php esc_html_e('Use your dashboard to view orders, access downloads, and update your account details.', 'digjy-stores'); ?></p>
                    </div>
                    <?php echo $this->render_recent_account_orders($orders); ?>
                <?php elseif ($current_tab === 'orders') : ?>
                    <?php echo $this->order_history(); ?>
                <?php elseif ($current_tab === 'downloads') : ?>
                    <?php echo $this->customer_downloads(); ?>
                <?php else : ?>
                    <?php echo $this->render_account_details_form($user); ?>
                <?php endif; ?>
            </div>
        </div>
        <?php
        return $this->wrap_output(ob_get_clean(), 'digjy-shortcode-block');
    }

    private function render_recent_account_orders($orders) {
        ob_start();
        echo '<div class="digjy-card"><h3>' . esc_html__('Recent Orders', 'digjy-stores') . '</h3>';
        if (empty($orders)) {
            echo '<p>' . esc_html__('No orders yet.', 'digjy-stores') . '</p></div>';
            return ob_get_clean();
        }
        echo '<table class="digjy-table"><thead><tr><th>' . esc_html__('Order', 'digjy-stores') . '</th><th>' . esc_html__('Status', 'digjy-stores') . '</th><th>' . esc_html__('Payment', 'digjy-stores') . '</th></tr></thead><tbody>';
        foreach (array_slice($orders, 0, 5) as $order) {
            echo '<tr><td>' . esc_html($order->post_title) . '</td><td>' . esc_html(get_post_meta($order->ID, '_digjy_order_status', true)) . '</td><td>' . esc_html(get_post_meta($order->ID, '_digjy_payment_method', true)) . '</td></tr>';
        }
        echo '</tbody></table></div>';
        return ob_get_clean();
    }

    private function render_account_details_form($user) {
        ob_start(); ?>
        <form method="post" class="digjy-card digjy-form-grid digjy-account-form">
            <h3><?php esc_html_e('Account Details', 'digjy-stores'); ?></h3>
            <?php wp_nonce_field('digjy_customer_account', 'digjy_customer_account_nonce'); ?>
            <div class="digjy-two-col">
                <p><label><?php esc_html_e('First Name', 'digjy-stores'); ?></label><input type="text" name="account_first_name" value="<?php echo esc_attr($user->first_name); ?>" /></p>
                <p><label><?php esc_html_e('Last Name', 'digjy-stores'); ?></label><input type="text" name="account_last_name" value="<?php echo esc_attr($user->last_name); ?>" /></p>
            </div>
            <p><label><?php esc_html_e('Email Address', 'digjy-stores'); ?></label><input type="email" name="account_email" value="<?php echo esc_attr($user->user_email); ?>" required /></p>
            <p><label><?php esc_html_e('New Password', 'digjy-stores'); ?></label><input type="password" name="account_password" /></p>
            <p class="digjy-help"><?php esc_html_e('Leave the password field empty if you do not want to change it.', 'digjy-stores'); ?></p>
            <p><button type="submit" class="digjy-btn"><?php esc_html_e('Save Changes', 'digjy-stores'); ?></button></p>
        </form>
        <?php return ob_get_clean();
    }


    public function handle_marketplace_forms() {
        if (!empty($_POST['digjy_message_nonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['digjy_message_nonce'])), 'digjy_send_message')) {
            $this->process_message_submission();
        }
        if (!empty($_POST['digjy_follow_nonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['digjy_follow_nonce'])), 'digjy_toggle_follow')) {
            $this->process_follow_toggle();
        }
        if (!empty($_POST['digjy_wallet_nonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['digjy_wallet_nonce'])), 'digjy_wallet_action')) {
            $this->process_wallet_action();
        }
        if (!empty($_POST['digjy_review_nonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['digjy_review_nonce'])), 'digjy_submit_review')) {
            $this->process_review_submission();
        }
    }

    private function get_store_owner_id_from_context($atts = []) {
        $owner_id = absint($atts['owner_id'] ?? 0);
        if ($owner_id) {
            return $owner_id;
        }
        $store_id = absint($atts['store_id'] ?? 0);
        if ($store_id) {
            $store = get_post($store_id);
            if ($store && 'digjy_store' === $store->post_type) {
                return (int) $store->post_author;
            }
        }
        $product_id = absint($atts['product_id'] ?? 0);
        if ($product_id) {
            $product = get_post($product_id);
            if ($product && 'digjy_product' === $product->post_type) {
                return (int) $product->post_author;
            }
        }
        if (is_singular('digjy_store')) {
            $post = get_post(get_the_ID());
            return $post ? (int) $post->post_author : 0;
        }
        if (is_singular('digjy_product')) {
            $post = get_post(get_the_ID());
            return $post ? (int) $post->post_author : 0;
        }
        return 0;
    }

    private function get_store_for_owner($owner_id) {
        $stores = get_posts(['post_type' => 'digjy_store', 'post_status' => 'publish', 'posts_per_page' => 1, 'author' => absint($owner_id)]);
        return $stores ? $stores[0] : null;
    }

    private function get_following_ids($user_id) {
        $ids = get_user_meta($user_id, 'digjy_following', true);
        return is_array($ids) ? array_map('absint', $ids) : [];
    }

    private function get_follower_ids($owner_id) {
        $ids = get_user_meta($owner_id, 'digjy_followers', true);
        return is_array($ids) ? array_map('absint', $ids) : [];
    }

    private function wallet_get_balance($user_id) {
        return (float) get_user_meta($user_id, 'digjy_wallet_balance', true);
    }

    private function wallet_add_transaction($user_id, $type, $amount, $note = '', $meta = []) {
        $amount = round((float) $amount, 2);
        $tx_id = wp_insert_post([
            'post_type' => 'digjy_wallet_tx',
            'post_status' => 'publish',
            'post_title' => sprintf('%s %s', ucfirst(str_replace('_', ' ', $type)), current_time('mysql')),
            'post_content' => wp_kses_post($note),
            'post_author' => absint($user_id),
        ]);
        if ($tx_id && !is_wp_error($tx_id)) {
            update_post_meta($tx_id, '_digjy_wallet_user_id', absint($user_id));
            update_post_meta($tx_id, '_digjy_wallet_type', sanitize_text_field($type));
            update_post_meta($tx_id, '_digjy_wallet_amount', $amount);
            update_post_meta($tx_id, '_digjy_wallet_meta', wp_json_encode($meta));
        }
        return $tx_id;
    }

    private function process_message_submission() {
        if (!is_user_logged_in()) {
            return;
        }
        $sender_id = get_current_user_id();
        $owner_id = absint($_POST['owner_id'] ?? 0);
        $subject = sanitize_text_field(wp_unslash($_POST['subject'] ?? ''));
        $message = wp_kses_post(wp_unslash($_POST['message'] ?? ''));
        if (!$owner_id || $owner_id === $sender_id || empty($message)) {
            return;
        }
        $post_id = wp_insert_post([
            'post_type' => 'digjy_message',
            'post_status' => 'publish',
            'post_title' => $subject ?: __('Store Message', 'digjy-stores'),
            'post_content' => $message,
            'post_author' => $sender_id,
        ]);
        if ($post_id && !is_wp_error($post_id)) {
            update_post_meta($post_id, '_digjy_message_sender_id', $sender_id);
            update_post_meta($post_id, '_digjy_message_recipient_id', $owner_id);
            update_post_meta($post_id, '_digjy_message_subject', $subject);
            update_post_meta($post_id, '_digjy_message_read', 0);
            update_user_meta($sender_id, 'digjy_last_message_notice', __('Message sent to store owner.', 'digjy-stores'));
        }
        digjy_stores_safe_redirect(wp_get_referer() ?: home_url('/'));
    }

    private function process_follow_toggle() {
        if (!is_user_logged_in()) {
            return;
        }
        $user_id = get_current_user_id();
        $owner_id = absint($_POST['owner_id'] ?? 0);
        if (!$owner_id || $owner_id === $user_id) {
            return;
        }
        $following = $this->get_following_ids($user_id);
        $followers = $this->get_follower_ids($owner_id);
        if (in_array($owner_id, $following, true)) {
            $following = array_values(array_diff($following, [$owner_id]));
            $followers = array_values(array_diff($followers, [$user_id]));
        } else {
            $following[] = $owner_id;
            $followers[] = $user_id;
            $following = array_values(array_unique(array_map('absint', $following)));
            $followers = array_values(array_unique(array_map('absint', $followers)));
        }
        update_user_meta($user_id, 'digjy_following', $following);
        update_user_meta($owner_id, 'digjy_followers', $followers);
        digjy_stores_safe_redirect(wp_get_referer() ?: home_url('/'));
    }

    private function process_wallet_action() {
        if (!is_user_logged_in()) {
            return;
        }
        $user_id = get_current_user_id();
        $action = sanitize_text_field(wp_unslash($_POST['wallet_action'] ?? ''));
        $amount = round((float) ($_POST['amount'] ?? 0), 2);
        if ($amount <= 0) {
            digjy_stores_safe_redirect(wp_get_referer() ?: home_url('/'));
        }
        if ($action === 'deposit') {
            $new_balance = $this->wallet_get_balance($user_id) + $amount;
            update_user_meta($user_id, 'digjy_wallet_balance', $new_balance);
            $this->wallet_add_transaction($user_id, 'deposit', $amount, __('Manual wallet deposit recorded from frontend wallet form.', 'digjy-stores'));
        } elseif ($action === 'withdraw_request') {
            $this->wallet_add_transaction($user_id, 'withdraw_request', -$amount, __('Withdrawal request submitted.', 'digjy-stores'));
        } elseif ($action === 'transfer') {
            $recipient_login = sanitize_text_field(wp_unslash($_POST['recipient'] ?? ''));
            $recipient = get_user_by('login', $recipient_login);
            if (!$recipient && is_email($recipient_login)) {
                $recipient = get_user_by('email', $recipient_login);
            }
            $balance = $this->wallet_get_balance($user_id);
            if ($recipient && $recipient->ID !== $user_id && $balance >= $amount) {
                update_user_meta($user_id, 'digjy_wallet_balance', $balance - $amount);
                update_user_meta($recipient->ID, 'digjy_wallet_balance', $this->wallet_get_balance($recipient->ID) + $amount);
                $this->wallet_add_transaction($user_id, 'transfer_out', -$amount, sprintf(__('Transfer sent to %s.', 'digjy-stores'), $recipient->user_login), ['recipient_id' => $recipient->ID]);
                $this->wallet_add_transaction($recipient->ID, 'transfer_in', $amount, sprintf(__('Transfer received from %s.', 'digjy-stores'), wp_get_current_user()->user_login), ['sender_id' => $user_id]);
            }
        }
        digjy_stores_safe_redirect(wp_get_referer() ?: home_url('/'));
    }

    public function contact_store_owner_button($atts) {
        wp_enqueue_style('digjy-stores');
        $atts = shortcode_atts(['owner_id' => 0, 'store_id' => 0, 'product_id' => 0, 'label' => __('Contact Store Owner', 'digjy-stores')], $atts, 'digjy_contact_store_owner_button');
        $owner_id = $this->get_store_owner_id_from_context($atts);
        if (!$owner_id) {
            return '';
        }
        $owner = get_user_by('id', $owner_id);
        $store = $this->get_store_for_owner($owner_id);
        ob_start();
        echo '<div class="digjy-card digjy-message-card">';
        echo '<button type="button" class="digjy-btn digjy-toggle-message-form" data-target="digjy-message-form-' . esc_attr($owner_id) . '">' . esc_html($atts['label']) . '</button>';
        if ($owner) {
            echo '<p class="digjy-help">' . sprintf(esc_html__('Message %s directly from the marketplace.', 'digjy-stores'), esc_html($owner->display_name)) . '</p>';
        }
        if (!is_user_logged_in()) {
            echo '<p class="digjy-help">' . esc_html__('Please log in to send a message.', 'digjy-stores') . '</p>';
        } else {
            echo '<form method="post" class="digjy-inline-form digjy-message-form" id="digjy-message-form-' . esc_attr($owner_id) . '" style="display:none;">';
            wp_nonce_field('digjy_send_message', 'digjy_message_nonce');
            echo '<input type="hidden" name="owner_id" value="' . esc_attr($owner_id) . '" />';
            echo '<p><label>' . esc_html__('Subject', 'digjy-stores') . '</label><input type="text" name="subject" value="' . esc_attr($store ? sprintf(__('Question about %s', 'digjy-stores'), $store->post_title) : __('Store Question', 'digjy-stores')) . '" /></p>';
            echo '<p><label>' . esc_html__('Message', 'digjy-stores') . '</label><textarea name="message" rows="5" required></textarea></p>';
            echo '<p><button type="submit" class="digjy-btn">' . esc_html__('Send Message', 'digjy-stores') . '</button></p>';
            echo '</form>';
        }
        echo '</div>';
        return $this->wrap_output(ob_get_clean(), 'digjy-shortcode-block');
    }

    public function follow_button($atts) {
        wp_enqueue_style('digjy-stores');
        $atts = shortcode_atts(['owner_id' => 0, 'store_id' => 0, 'product_id' => 0, 'follow_label' => __('Follow', 'digjy-stores'), 'unfollow_label' => __('Unfollow', 'digjy-stores')], $atts, 'digjy_follow_button');
        $owner_id = $this->get_store_owner_id_from_context($atts);
        if (!$owner_id) {
            return '';
        }
        $followers = $this->get_follower_ids($owner_id);
        $following = is_user_logged_in() ? $this->get_following_ids(get_current_user_id()) : [];
        $is_following = is_user_logged_in() && in_array($owner_id, $following, true);
        $label = $is_following ? $atts['unfollow_label'] : $atts['follow_label'];
        ob_start();
        echo '<div class="digjy-card digjy-follow-card">';
        echo '<div class="digjy-follow-meta"><strong>' . esc_html(count($followers)) . '</strong> ' . esc_html__('followers', 'digjy-stores') . '</div>';
        if (is_user_logged_in()) {
            echo '<form method="post" class="digjy-inline-form">';
            wp_nonce_field('digjy_toggle_follow', 'digjy_follow_nonce');
            echo '<input type="hidden" name="owner_id" value="' . esc_attr($owner_id) . '" />';
            echo '<button type="submit" class="digjy-btn">' . esc_html($label) . '</button>';
            echo '</form>';
        } else {
            echo '<p class="digjy-help">' . esc_html__('Log in to follow this store owner.', 'digjy-stores') . '</p>';
        }
        echo '</div>';
        return $this->wrap_output(ob_get_clean(), 'digjy-shortcode-block');
    }

    public function messages_shortcode() {
        wp_enqueue_style('digjy-stores');
        if (!is_user_logged_in()) {
            return '<div class="digjy-alert">' . esc_html__('Please log in to view messages.', 'digjy-stores') . '</div>';
        }
        $user_id = get_current_user_id();
        $messages = get_posts(['post_type' => 'digjy_message', 'post_status' => 'publish', 'posts_per_page' => 50, 'orderby' => 'date', 'order' => 'DESC', 'meta_query' => ['relation' => 'OR', ['key' => '_digjy_message_recipient_id', 'value' => $user_id, 'compare' => '='], ['key' => '_digjy_message_sender_id', 'value' => $user_id, 'compare' => '=']]]);
        ob_start();
        echo '<div class="digjy-card"><h3>' . esc_html__('Marketplace Messages', 'digjy-stores') . '</h3>';
        if (!$messages) {
            echo '<p>' . esc_html__('No messages yet.', 'digjy-stores') . '</p>';
        } else {
            echo '<div class="digjy-message-list">';
            foreach ($messages as $message) {
                $sender = get_user_by('id', (int) get_post_meta($message->ID, '_digjy_message_sender_id', true));
                $recipient = get_user_by('id', (int) get_post_meta($message->ID, '_digjy_message_recipient_id', true));
                echo '<article class="digjy-message-item">';
                echo '<h4>' . esc_html($message->post_title) . '</h4>';
                echo '<p class="digjy-help"><strong>' . esc_html__('From:', 'digjy-stores') . '</strong> ' . esc_html($sender ? $sender->display_name : __('Unknown', 'digjy-stores')) . ' &nbsp; <strong>' . esc_html__('To:', 'digjy-stores') . '</strong> ' . esc_html($recipient ? $recipient->display_name : __('Unknown', 'digjy-stores')) . '</p>';
                echo '<div>' . wp_kses_post(wpautop($message->post_content)) . '</div>';
                echo '</article>';
            }
            echo '</div>';
        }
        echo '</div>';
        return $this->wrap_output(ob_get_clean(), 'digjy-shortcode-block');
    }

    public function wallet_shortcode() {
        wp_enqueue_style('digjy-stores');
        if (!is_user_logged_in()) {
            return '<div class="digjy-alert">' . esc_html__('Please log in to view your wallet.', 'digjy-stores') . '</div>';
        }
        $user_id = get_current_user_id();
        $balance = $this->wallet_get_balance($user_id);
        $transactions = get_posts(['post_type' => 'digjy_wallet_tx', 'post_status' => 'publish', 'posts_per_page' => 20, 'orderby' => 'date', 'order' => 'DESC', 'author' => $user_id]);
        $followers = count($this->get_follower_ids($user_id));
        $following = count($this->get_following_ids($user_id));
        ob_start();
        echo '<div class="digjy-account-shell">';
        echo '<div class="digjy-grid digjy-stats">';
        echo '<div class="digjy-card"><strong>' . esc_html(number_format($balance, 2)) . '</strong><span>' . esc_html__('Wallet Balance', 'digjy-stores') . '</span></div>';
        echo '<div class="digjy-card"><strong>' . esc_html($followers) . '</strong><span>' . esc_html__('Followers', 'digjy-stores') . '</span></div>';
        echo '<div class="digjy-card"><strong>' . esc_html($following) . '</strong><span>' . esc_html__('Following', 'digjy-stores') . '</span></div>';
        echo '</div>';
        echo '<div class="digjy-grid digjy-account-auth-grid">';
        echo '<form method="post" class="digjy-card digjy-wallet-form">';
        wp_nonce_field('digjy_wallet_action', 'digjy_wallet_nonce');
        echo '<h3>' . esc_html__('Add Funds', 'digjy-stores') . '</h3><input type="hidden" name="wallet_action" value="deposit" /><p><label>' . esc_html__('Amount', 'digjy-stores') . '</label><input type="number" step="0.01" min="0.01" name="amount" required /></p><p><button class="digjy-btn" type="submit">' . esc_html__('Add Funds', 'digjy-stores') . '</button></p></form>';
        echo '<form method="post" class="digjy-card digjy-wallet-form">';
        wp_nonce_field('digjy_wallet_action', 'digjy_wallet_nonce');
        echo '<h3>' . esc_html__('Transfer Balance', 'digjy-stores') . '</h3><input type="hidden" name="wallet_action" value="transfer" /><p><label>' . esc_html__('Recipient Username or Email', 'digjy-stores') . '</label><input type="text" name="recipient" required /></p><p><label>' . esc_html__('Amount', 'digjy-stores') . '</label><input type="number" step="0.01" min="0.01" name="amount" required /></p><p><button class="digjy-btn" type="submit">' . esc_html__('Send Transfer', 'digjy-stores') . '</button></p></form>';
        echo '</div>';
        echo '<form method="post" class="digjy-card digjy-wallet-form">';
        wp_nonce_field('digjy_wallet_action', 'digjy_wallet_nonce');
        echo '<h3>' . esc_html__('Withdraw Request', 'digjy-stores') . '</h3><input type="hidden" name="wallet_action" value="withdraw_request" /><p><label>' . esc_html__('Amount', 'digjy-stores') . '</label><input type="number" step="0.01" min="0.01" name="amount" required /></p><p><button class="digjy-btn" type="submit">' . esc_html__('Request Withdrawal', 'digjy-stores') . '</button></p><p class="digjy-help">' . esc_html__('This records a withdrawal request for admin review. It does not auto-payout funds.', 'digjy-stores') . '</p></form>';
        echo '<div class="digjy-card"><h3>' . esc_html__('Recent Wallet Activity', 'digjy-stores') . '</h3>';
        if (!$transactions) {
            echo '<p>' . esc_html__('No wallet activity yet.', 'digjy-stores') . '</p>';
        } else {
            echo '<table class="digjy-table"><thead><tr><th>' . esc_html__('Date', 'digjy-stores') . '</th><th>' . esc_html__('Type', 'digjy-stores') . '</th><th>' . esc_html__('Amount', 'digjy-stores') . '</th></tr></thead><tbody>';
            foreach ($transactions as $tx) {
                echo '<tr><td>' . esc_html(get_the_date('', $tx)) . '</td><td>' . esc_html(get_post_meta($tx->ID, '_digjy_wallet_type', true)) . '</td><td>' . esc_html(number_format((float) get_post_meta($tx->ID, '_digjy_wallet_amount', true), 2)) . '</td></tr>';
            }
            echo '</tbody></table>';
        }
        echo '</div></div>';
        return $this->wrap_output(ob_get_clean(), 'digjy-shortcode-block');
    }


    private function get_product_review_data($product_id) {
        $product_id = absint($product_id);
        $reviews = get_posts([
            'post_type' => 'digjy_review',
            'post_status' => 'publish',
            'posts_per_page' => 100,
            'orderby' => 'date',
            'order' => 'DESC',
            'meta_key' => '_digjy_review_product_id',
            'meta_value' => $product_id,
        ]);
        $total = count($reviews);
        $sum = 0;
        $distribution = [1 => 0, 2 => 0, 3 => 0, 4 => 0, 5 => 0];
        foreach ($reviews as $review) {
            $rating = max(1, min(5, (int) get_post_meta($review->ID, '_digjy_review_rating', true)));
            $sum += $rating;
            $distribution[$rating] = isset($distribution[$rating]) ? $distribution[$rating] + 1 : 1;
        }
        $average = $total ? round($sum / $total, 1) : 0;
        return [
            'reviews' => $reviews,
            'total' => $total,
            'average' => $average,
            'distribution' => $distribution,
        ];
    }

    private function render_star_icons($rating, $interactive = false, $field_name = 'rating') {
        $rating = max(0, min(5, (int) $rating));
        ob_start();
        if ($interactive) {
            echo '<div class="digjy-star-input" role="radiogroup" aria-label="' . esc_attr__('Select a rating', 'digjy-stores') . '">';
            for ($i = 5; $i >= 1; $i--) {
                echo '<input type="radio" id="digjy-rating-' . esc_attr($i) . '" name="' . esc_attr($field_name) . '" value="' . esc_attr($i) . '" ' . checked($i, 5, false) . ' />';
                echo '<label for="digjy-rating-' . esc_attr($i) . '" title="' . esc_attr(sprintf(__('%d stars', 'digjy-stores'), $i)) . '">&#9733;</label>';
            }
            echo '</div>';
        } else {
            echo '<span class="digjy-stars" aria-label="' . esc_attr(sprintf(__('%s out of 5 stars', 'digjy-stores'), number_format_i18n($rating, 1))) . '">';
            for ($i = 1; $i <= 5; $i++) {
                echo '<span class="digjy-star ' . ($i <= round($rating) ? 'filled' : '') . '">&#9733;</span>';
            }
            echo '</span>';
        }
        return ob_get_clean();
    }

    private function user_can_review_product($product_id, $user_id) {
        if (!$product_id || !$user_id) {
            return false;
        }
        $user = get_user_by('id', $user_id);
        if (!$user) {
            return false;
        }
        $orders = get_posts([
            'post_type' => 'digjy_order',
            'post_status' => 'publish',
            'posts_per_page' => 1,
            'meta_query' => [
                'relation' => 'AND',
                ['key' => '_digjy_product_id', 'value' => absint($product_id)],
                ['key' => '_digjy_buyer_email', 'value' => $user->user_email],
            ],
        ]);
        return !empty($orders);
    }

    private function process_review_submission() {
        if (!is_user_logged_in()) {
            return;
        }
        $product_id = absint($_POST['product_id'] ?? 0);
        $product = get_post($product_id);
        if (!$product || 'digjy_product' !== $product->post_type) {
            digjy_stores_safe_redirect(wp_get_referer() ?: home_url('/'));
        }
        $user_id = get_current_user_id();
        $content = wp_kses_post(wp_unslash($_POST['review_content'] ?? ''));
        $title = sanitize_text_field(wp_unslash($_POST['review_title'] ?? ''));
        $rating = max(1, min(5, absint($_POST['rating'] ?? 5)));
        if (!$content) {
            update_user_meta($user_id, 'digjy_last_review_notice', __('Review content is required.', 'digjy-stores'));
            wp_safe_redirect(wp_get_referer() ?: get_permalink($product_id)); exit;
        }
        if (!$this->user_can_review_product($product_id, $user_id) && !current_user_can('manage_options')) {
            update_user_meta($user_id, 'digjy_last_review_notice', __('Only customers who purchased this product can leave a review.', 'digjy-stores'));
            wp_safe_redirect(wp_get_referer() ?: get_permalink($product_id)); exit;
        }
        $existing = get_posts([
            'post_type' => 'digjy_review',
            'post_status' => ['publish', 'pending', 'draft'],
            'posts_per_page' => 1,
            'author' => $user_id,
            'meta_key' => '_digjy_review_product_id',
            'meta_value' => $product_id,
        ]);
        $postarr = [
            'post_type' => 'digjy_review',
            'post_status' => 'publish',
            'post_title' => $title ?: sprintf(__('Review for %s', 'digjy-stores'), $product->post_title),
            'post_content' => $content,
            'post_author' => $user_id,
        ];
        if ($existing) {
            $postarr['ID'] = $existing[0]->ID;
            $review_id = wp_update_post($postarr, true);
        } else {
            $review_id = wp_insert_post($postarr, true);
        }
        if (!is_wp_error($review_id) && $review_id) {
            update_post_meta($review_id, '_digjy_review_product_id', $product_id);
            update_post_meta($review_id, '_digjy_review_store_id', 0);
            update_post_meta($review_id, '_digjy_review_rating', $rating);
            update_user_meta($user_id, 'digjy_last_review_notice', __('Your review has been saved.', 'digjy-stores'));
        }
        wp_safe_redirect(wp_get_referer() ?: get_permalink($product_id)); exit;
    }

    public function review_section($atts) {
        wp_enqueue_style('digjy-stores');
        $atts = shortcode_atts(['product_id' => get_the_ID(), 'show_form' => 'yes'], $atts, 'digjy_review_section');
        $product_id = absint($atts['product_id']);
        if (!$product_id) {
            return '';
        }
        $product = get_post($product_id);
        if (!$product || 'digjy_product' !== $product->post_type) {
            return '';
        }
        $data = $this->get_product_review_data($product_id);
        $notice = '';
        if (is_user_logged_in()) {
            $notice = (string) get_user_meta(get_current_user_id(), 'digjy_last_review_notice', true);
            if ($notice) {
                delete_user_meta(get_current_user_id(), 'digjy_last_review_notice');
            }
        }
        ob_start();
        echo '<div class="digjy-card digjy-review-section">';
        echo '<div class="digjy-review-summary">';
        echo '<div class="digjy-review-average"><strong>' . esc_html(number_format_i18n($data['average'], 1)) . '</strong>' . $this->render_star_icons((int) round($data['average'])) . '<span class="digjy-help">' . esc_html(sprintf(_n('%d review', '%d reviews', $data['total'], 'digjy-stores'), $data['total'])) . '</span></div>';
        echo '<div class="digjy-review-breakdown">';
        for ($i = 5; $i >= 1; $i--) {
            $count = $data['distribution'][$i] ?? 0;
            $percent = $data['total'] ? round(($count / $data['total']) * 100) : 0;
            echo '<div class="digjy-review-row"><span>' . esc_html($i . '★') . '</span><div class="digjy-review-bar"><span style="width:' . esc_attr($percent) . '%"></span></div><span>' . esc_html($count) . '</span></div>';
        }
        echo '</div></div>';
        if ($notice) {
            echo '<div class="digjy-alert-success">' . esc_html($notice) . '</div>';
        }
        if (is_user_logged_in() && $atts['show_form'] !== 'no') {
            $can_review = $this->user_can_review_product($product_id, get_current_user_id()) || current_user_can('manage_options');
            if ($can_review) {
                echo '<form method="post" class="digjy-card digjy-form-grid digjy-review-form">';
                echo '<h3>' . esc_html__('Write a Review', 'digjy-stores') . '</h3>';
                wp_nonce_field('digjy_submit_review', 'digjy_review_nonce');
                echo '<input type="hidden" name="product_id" value="' . esc_attr($product_id) . '" />';
                echo '<p><label>' . esc_html__('Your Rating', 'digjy-stores') . '</label>' . $this->render_star_icons(5, true, 'rating') . '</p>';
                echo '<p><label>' . esc_html__('Review Title', 'digjy-stores') . '</label><input type="text" name="review_title" /></p>';
                echo '<p><label>' . esc_html__('Your Review', 'digjy-stores') . '</label><textarea name="review_content" rows="5" required></textarea></p>';
                echo '<p><button type="submit" class="digjy-btn">' . esc_html__('Submit Review', 'digjy-stores') . '</button></p>';
                echo '</form>';
            } else {
                echo '<p class="digjy-help">' . esc_html__('Only customers who purchased this product can leave a review.', 'digjy-stores') . '</p>';
            }
        } elseif (!is_user_logged_in() && $atts['show_form'] !== 'no') {
            echo '<p class="digjy-help">' . esc_html__('Log in to leave a review.', 'digjy-stores') . '</p>';
        }
        echo '<div class="digjy-review-list">';
        if (!$data['reviews']) {
            echo '<p>' . esc_html__('There are no reviews yet.', 'digjy-stores') . '</p>';
        } else {
            foreach ($data['reviews'] as $review) {
                $author = get_user_by('id', (int) $review->post_author);
                $rating = (int) get_post_meta($review->ID, '_digjy_review_rating', true);
                echo '<article class="digjy-card digjy-review-item">';
                echo '<div class="digjy-review-item-head"><div><strong>' . esc_html($review->post_title) . '</strong><div class="digjy-help">' . esc_html($author ? $author->display_name : __('Verified customer', 'digjy-stores')) . ' · ' . esc_html(get_the_date('', $review)) . '</div></div><div>' . $this->render_star_icons($rating) . '</div></div>';
                echo '<div>' . wp_kses_post(wpautop($review->post_content)) . '</div>';
                echo '</article>';
            }
        }
        echo '</div></div>';
        return $this->wrap_output(ob_get_clean(), 'digjy-shortcode-block');
    }

    public function seller_register() {
        wp_enqueue_style('digjy-stores');
        ob_start(); ?>
        <form method="post" class="digjy-card digjy-form-grid">
            <h3><?php esc_html_e('Open Your Store For Free', 'digjy-stores'); ?></h3>
            <?php wp_nonce_field('digjy_seller_register', 'digjy_seller_register_nonce'); ?>
            <p><label><?php esc_html_e('Store Name', 'digjy-stores'); ?></label><input type="text" name="store_name" required /></p>
            <p><label><?php esc_html_e('Username', 'digjy-stores'); ?></label><input type="text" name="username" required /></p>
            <p><label><?php esc_html_e('Email', 'digjy-stores'); ?></label><input type="email" name="email" required /></p>
            <p><label><?php esc_html_e('Password', 'digjy-stores'); ?></label><input type="password" name="password" required /></p>
            <p><label><?php esc_html_e('Seller Wallet (optional)', 'digjy-stores'); ?></label><input type="text" name="seller_wallet" /></p>
            <p class="digjy-help"><?php esc_html_e('If you leave the wallet empty, Digjy Stores will try to auto-create a Crossmint wallet for the seller when the marketplace account is created.', 'digjy-stores'); ?></p>
            <p><button type="submit" class="digjy-btn"><?php esc_html_e('Create Store', 'digjy-stores'); ?></button></p>
        </form>
        <?php return $this->wrap_output(ob_get_clean(), 'digjy-shortcode-block');
    }

    public function store_list() {
        wp_enqueue_style('digjy-stores');
        $stores = get_posts(['post_type' => 'digjy_store', 'posts_per_page' => 100, 'post_status' => 'publish']);
        ob_start();
        echo '<div class="digjy-grid">';
        foreach ($stores as $store) {
            echo '<article class="digjy-card">';
            echo '<h3><a href="' . esc_url(get_permalink($store)) . '">' . esc_html($store->post_title) . '</a></h3>';
            echo '<p>' . esc_html(wp_trim_words(wp_strip_all_tags($store->post_content), 20)) . '</p>';
            $products = get_posts(['post_type' => 'digjy_product', 'author' => $store->post_author, 'posts_per_page' => 6, 'post_status' => 'publish']);
            if ($products) {
                echo '<div class="digjy-mini-grid">';
                foreach ($products as $product) {
                    echo '<div class="digjy-mini-item"><strong>' . esc_html($product->post_title) . '</strong><br /><span>' . esc_html(number_format((float) get_post_meta($product->ID, '_digjy_price', true), 2)) . '</span></div>';
                }
                echo '</div>';
            }
            echo '</article>';
        }
        echo '</div>';
        return $this->wrap_output(ob_get_clean(), 'digjy-shortcode-block');
    }

    public function vendor_dashboard() {
        wp_enqueue_style('digjy-stores');
        if (!is_user_logged_in()) {
            return '<div class="digjy-alert">' . esc_html__('Please log in to access the vendor dashboard.', 'digjy-stores') . '</div>';
        }
        $user_id = get_current_user_id();
        $products = get_posts(['post_type' => 'digjy_product', 'author' => $user_id, 'posts_per_page' => 100, 'post_status' => ['publish','draft','pending']]);
        $orders = get_posts(['post_type' => 'digjy_order', 'posts_per_page' => 50, 'post_status' => 'publish', 'meta_key' => '_digjy_seller_id', 'meta_value' => $user_id]);
        $earnings = 0.0; $paid_count = 0;
        foreach ($orders as $order) {
            $status = get_post_meta($order->ID, '_digjy_order_status', true);
            if (in_array($status, ['paid', 'completed'], true)) {
                $paid_count++;
                $earnings += (float) get_post_meta($order->ID, '_digjy_seller_amount', true);
            }
        }
        ob_start(); ?>
        <div class="digjy-dashboard">
            <div class="digjy-grid digjy-stats">
                <div class="digjy-card"><strong><?php echo esc_html(count($products)); ?></strong><span><?php esc_html_e('Products', 'digjy-stores'); ?></span></div>
                <div class="digjy-card"><strong><?php echo esc_html(count($orders)); ?></strong><span><?php esc_html_e('Orders', 'digjy-stores'); ?></span></div>
                <div class="digjy-card"><strong><?php echo esc_html($paid_count); ?></strong><span><?php esc_html_e('Paid Orders', 'digjy-stores'); ?></span></div>
                <div class="digjy-card"><strong><?php echo esc_html(number_format($earnings, 2)); ?></strong><span><?php esc_html_e('Seller Earnings', 'digjy-stores'); ?></span></div>
            </div>
            <div class="digjy-grid one-col">
                <div class="digjy-card">
                    <h3><?php esc_html_e('Your Products', 'digjy-stores'); ?></h3>
                    <?php if ($products) : ?>
                        <table class="digjy-table"><thead><tr><th><?php esc_html_e('Product', 'digjy-stores'); ?></th><th><?php esc_html_e('Price', 'digjy-stores'); ?></th><th><?php esc_html_e('Mode', 'digjy-stores'); ?></th></tr></thead><tbody>
                        <?php foreach ($products as $product) : ?>
                            <tr><td><a href="<?php echo esc_url(get_permalink($product)); ?>"><?php echo esc_html($product->post_title); ?></a></td><td><?php echo esc_html(number_format((float) get_post_meta($product->ID, '_digjy_price', true), 2)); ?></td><td><?php echo esc_html(get_post_meta($product->ID, '_digjy_asset_mode', true)); ?></td></tr>
                        <?php endforeach; ?>
                        </tbody></table>
                    <?php else : ?><p><?php esc_html_e('No products yet.', 'digjy-stores'); ?></p><?php endif; ?>
                </div>
            </div>
            <div class="digjy-card">
                <h3><?php esc_html_e('Recent Orders', 'digjy-stores'); ?></h3>
                <table class="digjy-table"><thead><tr><th><?php esc_html_e('Order', 'digjy-stores'); ?></th><th><?php esc_html_e('Buyer', 'digjy-stores'); ?></th><th><?php esc_html_e('Seller Amount', 'digjy-stores'); ?></th><th><?php esc_html_e('Status', 'digjy-stores'); ?></th></tr></thead><tbody>
                <?php foreach ($orders as $order) : ?>
                    <tr><td><?php echo esc_html($order->post_title); ?></td><td><?php echo esc_html(get_post_meta($order->ID, '_digjy_buyer_email', true)); ?></td><td><?php echo esc_html(number_format((float) get_post_meta($order->ID, '_digjy_seller_amount', true), 2)); ?></td><td><?php echo esc_html(get_post_meta($order->ID, '_digjy_order_status', true)); ?></td></tr>
                <?php endforeach; ?>
                </tbody></table>
            </div>
        </div>
        <?php return $this->wrap_output(ob_get_clean(), 'digjy-shortcode-block');
    }

    public function handle_frontend_product_save() {
        if (empty($_POST['digjy_frontend_product_save_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['digjy_frontend_product_save_nonce'])), 'digjy_frontend_product_save')) {
            return;
        }
        if (!is_user_logged_in()) {
            return;
        }
        $user_id = get_current_user_id();
        $product_id = isset($_POST['digjy_frontend_product_id']) ? absint($_POST['digjy_frontend_product_id']) : 0;
        $data = [
            'post_type' => 'digjy_product',
            'post_title' => sanitize_text_field($_POST['digjy_frontend_title'] ?? ''),
            'post_content' => wp_kses_post($_POST['digjy_frontend_content'] ?? ''),
            'post_status' => 'publish',
            'post_author' => $user_id,
        ];
        if ($product_id && get_post_field('post_author', $product_id) == $user_id) {
            $data['ID'] = $product_id;
            $product_id = wp_update_post($data);
        } else {
            $product_id = wp_insert_post($data);
        }
        if ($product_id && !is_wp_error($product_id)) {
            update_post_meta($product_id, '_digjy_price', (float) ($_POST['digjy_frontend_price'] ?? 0));
            update_post_meta($product_id, '_digjy_file_url', esc_url_raw(wp_unslash($_POST['digjy_frontend_file_url'] ?? '')));
            update_post_meta($product_id, '_digjy_sku', sanitize_text_field(wp_unslash($_POST['digjy_frontend_sku'] ?? '')));
            update_post_meta($product_id, '_digjy_license', sanitize_textarea_field(wp_unslash($_POST['digjy_frontend_license'] ?? '')));
            update_post_meta($product_id, '_digjy_product_type', sanitize_key(wp_unslash($_POST['digjy_frontend_product_type'] ?? 'regular')) === 'minted_digital' ? 'minted_digital' : 'regular');
            update_post_meta($product_id, '_digjy_asset_mode', sanitize_text_field(wp_unslash($_POST['digjy_frontend_asset_mode'] ?? 'lazy_minted')));
            update_post_meta($product_id, '_digjy_chain', sanitize_text_field(wp_unslash($_POST['digjy_frontend_chain'] ?? 'solana')));
            update_post_meta($product_id, '_digjy_collection_locator', sanitize_text_field(wp_unslash($_POST['digjy_frontend_collection_locator'] ?? '')));
            update_post_meta($product_id, '_digjy_token_id', sanitize_text_field(wp_unslash($_POST['digjy_frontend_token_id'] ?? '')));
            update_post_meta($product_id, '_digjy_contract_address', sanitize_text_field(wp_unslash($_POST['digjy_frontend_contract_address'] ?? '')));
            update_post_meta($product_id, '_digjy_metadata_uri', esc_url_raw(wp_unslash($_POST['digjy_frontend_metadata_uri'] ?? '')));
            update_post_meta($product_id, '_digjy_recipient_wallet', sanitize_text_field(wp_unslash($_POST['digjy_frontend_recipient_wallet'] ?? '')));
            update_post_meta($product_id, '_digjy_royalty_percent', (float) ($_POST['digjy_frontend_royalty_percent'] ?? 0));
            update_post_meta($product_id, '_digjy_royalty_recipient', sanitize_text_field(wp_unslash($_POST['digjy_frontend_royalty_recipient'] ?? '')));
            update_post_meta($product_id, '_digjy_buyer_creator_royalty_percent', absint($_POST['digjy_frontend_buyer_creator_royalty_percent'] ?? 0));
            update_post_meta($product_id, '_digjy_nft_template_id', sanitize_text_field(wp_unslash($_POST['digjy_frontend_nft_template_id'] ?? '')));
            update_post_meta($product_id, '_digjy_nft_name', sanitize_text_field(wp_unslash($_POST['digjy_frontend_nft_name'] ?? '')));
            update_post_meta($product_id, '_digjy_nft_symbol', sanitize_text_field(wp_unslash($_POST['digjy_frontend_nft_symbol'] ?? '')));
            update_post_meta($product_id, '_digjy_nft_image', esc_url_raw(wp_unslash($_POST['digjy_frontend_nft_image'] ?? '')));
            update_post_meta($product_id, '_digjy_nft_supply', max(1, absint($_POST['digjy_frontend_nft_supply'] ?? 1)));
            update_post_meta($product_id, '_digjy_onchain_status', sanitize_text_field(wp_unslash($_POST['digjy_frontend_onchain_status'] ?? 'configured')));
        }
        digjy_stores_safe_redirect(wp_get_referer() ?: home_url('/'));
    }

    public function customer_downloads() {
        wp_enqueue_style('digjy-stores');
        if (!is_user_logged_in()) {
            return '<div class="digjy-alert">' . esc_html__('Please log in to view your downloads.', 'digjy-stores') . '</div>';
        }
        $user = wp_get_current_user();
        $orders = get_posts(['post_type' => 'digjy_order', 'post_status' => 'publish', 'posts_per_page' => 50, 'meta_key' => '_digjy_buyer_email', 'meta_value' => $user->user_email]);
        ob_start();
        echo '<div class="digjy-grid">';
        foreach ($orders as $order) {
            $status = get_post_meta($order->ID, '_digjy_order_status', true);
            if (!in_array($status, ['paid','completed'], true)) {
                continue;
            }
            echo '<div class="digjy-card"><h4>' . esc_html($order->post_title) . '</h4>';
            echo '<p>' . esc_html__('Status:', 'digjy-stores') . ' ' . esc_html($status) . '</p>';
            $product_id = (int) get_post_meta($order->ID, '_digjy_product_id', true);
            $purchase_note = $product_id ? get_post_meta($product_id, '_digjy_purchase_note', true) : '';
            if (!empty($purchase_note)) {
                echo '<div class="digjy-purchase-note"><strong>' . esc_html__('Purchase Note:', 'digjy-stores') . '</strong><div>' . wpautop(wp_kses_post($purchase_note)) . '</div></div>';
            }
            echo '<p><a class="digjy-btn" href="' . esc_url($this->checkout->get_download_url($order->ID)) . '">' . esc_html__('Download', 'digjy-stores') . '</a></p>';
            echo '</div>';
        }
        echo '</div>';
        return $this->wrap_output(ob_get_clean(), 'digjy-shortcode-block');
    }

    public function order_history() {
        wp_enqueue_style('digjy-stores');
        wp_enqueue_script('digjy-stores');
        if (!is_user_logged_in()) {
            return '<div class="digjy-alert">' . esc_html__('Please log in to view your order history.', 'digjy-stores') . '</div>';
        }
        $user = wp_get_current_user();
        $orders = get_posts(['post_type' => 'digjy_order', 'post_status' => 'publish', 'posts_per_page' => 100, 'meta_key' => '_digjy_buyer_email', 'meta_value' => $user->user_email]);
        ob_start();
        echo '<div class="digjy-grid">';
        foreach ($orders as $order) {
            echo '<div class="digjy-card digjy-order-history-card digjy-checkout-form" data-internal-order-id="' . esc_attr($order->ID) . '">';
            echo '<h4>' . esc_html($order->post_title) . '</h4>';
            echo '<p><strong>' . esc_html__('Payment Method:', 'digjy-stores') . '</strong> ' . esc_html(get_post_meta($order->ID, '_digjy_payment_method', true)) . '</p>';
            echo '<div class="digjy-status-wrap" style="display:block;">';
            echo '<div class="digjy-status-badge"><span class="digjy-status-dot"></span><strong class="digjy-status-code">' . esc_html(get_post_meta($order->ID, '_digjy_order_status', true)) . '</strong></div>';
            echo '<p class="digjy-status-label">' . esc_html(get_post_meta($order->ID, '_digjy_status_label', true)) . '</p>';
            echo '<div class="digjy-status-meta"></div>';
            $product_id = (int) get_post_meta($order->ID, '_digjy_product_id', true);
            $purchase_note = $product_id ? get_post_meta($product_id, '_digjy_purchase_note', true) : '';
            if (!empty($purchase_note) && in_array(get_post_meta($order->ID, '_digjy_order_status', true), ['paid','completed'], true)) {
                echo '<div class="digjy-purchase-note"><strong>' . esc_html__('Purchase Note:', 'digjy-stores') . '</strong><div>' . wpautop(wp_kses_post($purchase_note)) . '</div></div>';
            }
            echo '<div class="digjy-status-actions">';
            echo '<button type="button" class="digjy-btn digjy-refresh-status">' . esc_html__('Refresh Status', 'digjy-stores') . '</button>';
            $download_url = $this->checkout->get_download_url($order->ID);
            if ($download_url && in_array(get_post_meta($order->ID, '_digjy_order_status', true), ['paid','completed'], true)) {
                echo ' <a class="digjy-btn" href="' . esc_url($download_url) . '">' . esc_html__('Download', 'digjy-stores') . '</a>';
            }
            echo '</div></div></div>';
        }
        echo '</div>';
        return $this->wrap_output(ob_get_clean(), 'digjy-shortcode-block');
    }

    public function product_price($atts) {
        $atts = shortcode_atts(['product_id' => get_the_ID(), 'currency_symbol' => '$'], $atts, 'digjy_product_price');
        $price = Digjy_Stores_Products::get_price(absint($atts['product_id']));
        return '<span class="digjy-price">' . esc_html($atts['currency_symbol'] . number_format($price, 2)) . '</span>';
    }

    public function nft_info($atts) {
        $atts = shortcode_atts(['product_id' => get_the_ID(), 'type' => 'all'], $atts, 'digjy_nft_info');
        return $this->render_nft_info(absint($atts['product_id']), sanitize_text_field($atts['type']));
    }

    public function nft_lazy_data($atts) {
        $atts = shortcode_atts(['product_id' => get_the_ID()], $atts, 'digjy_nft_lazy_data');
        return $this->render_nft_info(absint($atts['product_id']), 'lazy');
    }

    public function nft_minted_data($atts) {
        $atts = shortcode_atts(['product_id' => get_the_ID()], $atts, 'digjy_nft_minted_data');
        return $this->render_nft_info(absint($atts['product_id']), 'minted');
    }

    private function render_nft_info($product_id, $type = 'all') {
        wp_enqueue_style('digjy-stores');
        if (!$product_id) { return ''; }
        $meta = Digjy_Stores_Products::get_asset_meta($product_id);
        $show_lazy = in_array($type, ['all','lazy'], true);
        $show_minted = in_array($type, ['all','minted'], true);
        ob_start();
        echo '<div class="digjy-card digjy-nft-data">';
        echo '<h4>' . esc_html__('NFT Information', 'digjy-stores') . '</h4>';
        if ($show_lazy) {
            echo '<div class="digjy-nft-block"><h5>' . esc_html__('Lazy Mint Data', 'digjy-stores') . '</h5><ul>';
            echo '<li><strong>Mode:</strong> ' . esc_html($meta['asset_mode']) . '</li>';
            echo '<li><strong>Chain:</strong> ' . esc_html($meta['chain']) . '</li>';
            echo '<li><strong>Collection Locator:</strong> ' . esc_html($meta['collection_locator']) . '</li>';
            echo '<li><strong>Recipient Wallet:</strong> ' . esc_html($meta['recipient_wallet']) . '</li>';
            echo '<li><strong>Metadata URI:</strong> ' . esc_html($meta['metadata_uri']) . '</li>';
            echo '<li><strong>On-chain Status:</strong> ' . esc_html($meta['onchain_status']) . '</li>';
            echo '</ul></div>';
        }
        if ($show_minted) {
            echo '<div class="digjy-nft-block"><h5>' . esc_html__('Minted Asset Data', 'digjy-stores') . '</h5><ul>';
            echo '<li><strong>Token ID:</strong> ' . esc_html($meta['token_id']) . '</li>';
            echo '<li><strong>Contract / Mint Address:</strong> ' . esc_html($meta['contract_address']) . '</li>';
            echo '<li><strong>Owner:</strong> ' . esc_html($meta['owner']) . '</li>';
            echo '<li><strong>Transaction ID:</strong> ' . esc_html($meta['txid']) . '</li>';
            echo '<li><strong>On-chain Status:</strong> ' . esc_html($meta['onchain_status']) . '</li>';
            echo '<li><strong>Chain:</strong> ' . esc_html($meta['chain']) . '</li>';
            echo '</ul></div>';
        }
        echo '</div>';
        return $this->wrap_output(ob_get_clean(), 'digjy-shortcode-block');
    }

    public function seller_product_builder($atts = []) {
        wp_enqueue_style('digjy-stores');
        if (!is_user_logged_in()) {
            return $this->wrap_output('<div class="digjy-alert">' . esc_html__('Please log in as a store owner to manage products.', 'digjy-stores') . '</div>', 'digjy-shortcode-alert');
        }
        $user = wp_get_current_user();
        $roles = (array) $user->roles;
        if (!in_array('digjy_store_owner', $roles, true) && !in_array('digjy_seller', $roles, true) && !current_user_can('manage_options')) {
            return $this->wrap_output('<div class="digjy-alert">' . esc_html__('Only store owners can access the product builder.', 'digjy-stores') . '</div>', 'digjy-shortcode-alert');
        }
        $atts = shortcode_atts(['product_id' => 0], $atts, 'digjy_seller_product_builder');
        $product_id = absint($atts['product_id'] ?: ($_GET['digjy_product_id'] ?? 0));
        $product = $product_id ? get_post($product_id) : null;
        if ($product && ((int) $product->post_author !== get_current_user_id()) && !current_user_can('manage_options')) {
            $product = null; $product_id = 0;
        }
        $meta = $product_id ? Digjy_Stores_Products::get_asset_meta($product_id) : ['product_type'=>'regular','price'=>'','file_url'=>'','license'=>'','sku'=>'','asset_mode'=>'lazy_minted','chain'=>'solana','collection_locator'=>'','token_id'=>'','contract_address'=>'','owner'=>'','txid'=>'','onchain_status'=>'','recipient_wallet'=>'','metadata_uri'=>'','last_synced_at'=>''];
        ob_start();
        echo '<div class="digjy-card"><h3>' . esc_html($product_id ? __('Update Product', 'digjy-stores') : __('Add Product', 'digjy-stores')) . '</h3>';
        echo '<form method="post" class="digjy-form-grid digjy-seller-builder">';
        wp_nonce_field('digjy_frontend_product_save', 'digjy_frontend_product_save_nonce');
        echo '<input type="hidden" name="digjy_frontend_product_id" value="' . esc_attr($product_id) . '" />';
        echo '<div class="digjy-two-col"><p><label>' . esc_html__('Product Title', 'digjy-stores') . '</label><input type="text" name="digjy_frontend_title" value="' . esc_attr($product ? $product->post_title : '') . '" required /></p><p><label>' . esc_html__('Product Type', 'digjy-stores') . '</label><select name="digjy_frontend_product_type"><option value="regular" ' . selected($meta['product_type'], 'regular', false) . '>' . esc_html__('Regular Digital Product', 'digjy-stores') . '</option><option value="minted_digital" ' . selected($meta['product_type'], 'minted_digital', false) . '>' . esc_html__('Mint Digital Product', 'digjy-stores') . '</option></select></p></div>';
        echo '<p><label>' . esc_html__('Description', 'digjy-stores') . '</label><textarea name="digjy_frontend_content" rows="6">' . esc_textarea($product ? $product->post_content : '') . '</textarea></p>';
        echo '<div class="digjy-two-col"><p><label>' . esc_html__('Price', 'digjy-stores') . '</label><input type="number" step="0.01" min="0" name="digjy_frontend_price" value="' . esc_attr($meta['price']) . '" required /></p><p><label>' . esc_html__('SKU', 'digjy-stores') . '</label><input type="text" name="digjy_frontend_sku" value="' . esc_attr($meta['sku']) . '" /></p></div>';
        echo '<p><label>' . esc_html__('Download URL', 'digjy-stores') . '</label><input type="url" name="digjy_frontend_file_url" value="' . esc_attr($meta['file_url']) . '" /></p>';
        echo '<p><label>' . esc_html__('License / Terms', 'digjy-stores') . '</label><textarea name="digjy_frontend_license" rows="4">' . esc_textarea($meta['license']) . '</textarea></p>';
        echo '<h4>' . esc_html__('Mint / NFT Setup', 'digjy-stores') . '</h4>';
        echo '<div class="digjy-two-col"><p><label>' . esc_html__('Asset Mode', 'digjy-stores') . '</label><select name="digjy_frontend_asset_mode"><option value="lazy_minted" ' . selected($meta['asset_mode'], 'lazy_minted', false) . '>Lazy Minted</option><option value="minted" ' . selected($meta['asset_mode'], 'minted', false) . '>Already Minted</option><option value="both" ' . selected($meta['asset_mode'], 'both', false) . '>Supports Both</option></select></p><p><label>' . esc_html__('Chain', 'digjy-stores') . '</label><input type="text" name="digjy_frontend_chain" value="' . esc_attr($meta['chain']) . '" /></p></div>';
        echo '<div class="digjy-two-col"><p><label>' . esc_html__('Collection Locator', 'digjy-stores') . '</label><input type="text" name="digjy_frontend_collection_locator" value="' . esc_attr($meta['collection_locator']) . '" /></p><p><label>' . esc_html__('Token ID', 'digjy-stores') . '</label><input type="text" name="digjy_frontend_token_id" value="' . esc_attr($meta['token_id']) . '" /></p></div>';
        echo '<div class="digjy-two-col"><p><label>' . esc_html__('Contract / Mint Address', 'digjy-stores') . '</label><input type="text" name="digjy_frontend_contract_address" value="' . esc_attr($meta['contract_address']) . '" /></p><p><label>' . esc_html__('Metadata URI', 'digjy-stores') . '</label><input type="url" name="digjy_frontend_metadata_uri" value="' . esc_attr($meta['metadata_uri']) . '" /></p></div>';
        echo '<div class="digjy-two-col"><p><label>' . esc_html__('Recipient Wallet', 'digjy-stores') . '</label><input type="text" name="digjy_frontend_recipient_wallet" value="' . esc_attr($meta['recipient_wallet']) . '" /></p><p><label>' . esc_html__('Royalty %', 'digjy-stores') . '</label><input type="number" step="0.01" min="0" max="100" name="digjy_frontend_royalty_percent" value="' . esc_attr(get_post_meta($product_id, '_digjy_royalty_percent', true)) . '" /></p></div>';
        echo '<div class="digjy-two-col"><p><label>' . esc_html__('Royalty Recipient Wallet', 'digjy-stores') . '</label><input type="text" name="digjy_frontend_royalty_recipient" value="' . esc_attr(get_post_meta($product_id, '_digjy_royalty_recipient', true)) . '" /></p><p><label>' . esc_html__('Buyer Creator Royalty Percent', 'digjy-stores') . '</label><input type="number" step="1" min="0" max="100" name="digjy_frontend_buyer_creator_royalty_percent" value="' . esc_attr(get_post_meta($product_id, '_digjy_buyer_creator_royalty_percent', true)) . '" /></p></div>';
        echo '<div class="digjy-two-col"><p><label>' . esc_html__('NFT Template ID', 'digjy-stores') . '</label><input type="text" name="digjy_frontend_nft_template_id" value="' . esc_attr(get_post_meta($product_id, '_digjy_nft_template_id', true)) . '" /></p><p><label>' . esc_html__('NFT Name', 'digjy-stores') . '</label><input type="text" name="digjy_frontend_nft_name" value="' . esc_attr(get_post_meta($product_id, '_digjy_nft_name', true)) . '" /></p></div>';
        echo '<div class="digjy-two-col"><p><label>' . esc_html__('NFT Symbol', 'digjy-stores') . '</label><input type="text" name="digjy_frontend_nft_symbol" value="' . esc_attr(get_post_meta($product_id, '_digjy_nft_symbol', true)) . '" /></p><p><label>' . esc_html__('NFT Image URL', 'digjy-stores') . '</label><input type="url" name="digjy_frontend_nft_image" value="' . esc_attr(get_post_meta($product_id, '_digjy_nft_image', true)) . '" /></p></div>';
        echo '<p><label>' . esc_html__('NFT Supply', 'digjy-stores') . '</label><input type="number" min="1" step="1" name="digjy_frontend_nft_supply" value="' . esc_attr(get_post_meta($product_id, '_digjy_nft_supply', true) ?: 1) . '" /></p>';
        echo '<p><button type="submit" class="digjy-btn">' . esc_html($product_id ? __('Save Product', 'digjy-stores') : __('Create Product', 'digjy-stores')) . '</button></p>';
        echo '</form></div>';
        $products = get_posts(['post_type' => 'digjy_product', 'author' => get_current_user_id(), 'posts_per_page' => 50, 'post_status' => ['publish', 'draft', 'pending']]);
        echo '<div class="digjy-card"><h3>' . esc_html__('Your Product Builder Library', 'digjy-stores') . '</h3>';
        if ($products) {
            echo '<table class="digjy-table"><thead><tr><th>' . esc_html__('Product', 'digjy-stores') . '</th><th>' . esc_html__('Type', 'digjy-stores') . '</th><th>' . esc_html__('Price', 'digjy-stores') . '</th><th>' . esc_html__('Action', 'digjy-stores') . '</th></tr></thead><tbody>';
            foreach ($products as $p) {
                echo '<tr><td>' . esc_html($p->post_title) . '</td><td>' . esc_html(get_post_meta($p->ID, '_digjy_product_type', true) ?: 'regular') . '</td><td>' . esc_html(number_format((float) get_post_meta($p->ID, '_digjy_price', true), 2)) . '</td><td><a class="digjy-btn" href="' . esc_url(add_query_arg('digjy_product_id', $p->ID, get_permalink())) . '">' . esc_html__('Edit', 'digjy-stores') . '</a></td></tr>';
            }
            echo '</tbody></table>';
        } else {
            echo '<p>' . esc_html__('No seller products yet.', 'digjy-stores') . '</p>';
        }
        echo '</div>';
        return $this->wrap_output(ob_get_clean(), 'digjy-shortcode-block');
    }

    private function get_message_conversations($user_id) {
        $messages = get_posts(['post_type' => 'digjy_message', 'post_status' => 'publish', 'posts_per_page' => 200, 'orderby' => 'date', 'order' => 'DESC', 'meta_query' => ['relation' => 'OR', ['key' => '_digjy_message_recipient_id', 'value' => $user_id], ['key' => '_digjy_message_sender_id', 'value' => $user_id]]]);
        $out = [];
        foreach ($messages as $m) {
            $sender = (int) get_post_meta($m->ID, '_digjy_message_sender_id', true);
            $recipient = (int) get_post_meta($m->ID, '_digjy_message_recipient_id', true);
            $other = $sender === $user_id ? $recipient : $sender;
            if (!$other || isset($out[$other])) { continue; }
            $u = get_user_by('id', $other);
            $out[$other] = ['user_id' => $other, 'name' => $u ? $u->display_name : __('Unknown', 'digjy-stores'), 'snippet' => wp_trim_words(wp_strip_all_tags($m->post_content), 8)];
        }
        return array_values($out);
    }

    public function realtime_messages($atts = []) {
        wp_enqueue_style('digjy-stores');
        wp_enqueue_script('digjy-stores');
        if (!is_user_logged_in()) {
            return $this->wrap_output('<div class="digjy-alert">' . esc_html__('Please log in to access messages.', 'digjy-stores') . '</div>', 'digjy-shortcode-alert');
        }
        $conversations = $this->get_message_conversations(get_current_user_id());
        $atts = shortcode_atts(['user_id' => 0], $atts, 'digjy_realtime_messages');
        $active = absint($atts['user_id'] ?: ($_GET['digjy_dm_user'] ?? ($conversations ? $conversations[0]['user_id'] : 0)));
        ob_start();
        echo '<div class="digjy-dm-shell" data-active-user="' . esc_attr($active) . '">';
        echo '<div class="digjy-card digjy-dm-sidebar"><h3>' . esc_html__('Messages', 'digjy-stores') . '</h3><div class="digjy-dm-conversations">';
        if (!$conversations) {
            echo '<p>' . esc_html__('No conversations yet.', 'digjy-stores') . '</p>';
        }
        foreach ($conversations as $conv) {
            echo '<button type="button" class="digjy-dm-conversation' . ($active === $conv['user_id'] ? ' active' : '') . '" data-user-id="' . esc_attr($conv['user_id']) . '"><strong>' . esc_html($conv['name']) . '</strong><span>' . esc_html($conv['snippet']) . '</span></button>';
        }
        echo '</div></div>';
        echo '<div class="digjy-card digjy-dm-main"><div class="digjy-dm-thread"></div><form class="digjy-dm-form"><input type="hidden" name="recipient_id" value="' . esc_attr($active) . '" /><textarea name="message" rows="3" placeholder="' . esc_attr__('Write a message…', 'digjy-stores') . '"></textarea><button type="submit" class="digjy-btn">' . esc_html__('Send', 'digjy-stores') . '</button></form></div></div>';
        return $this->wrap_output(ob_get_clean(), 'digjy-shortcode-block');
    }

    public function nft_mint_ui($atts = []) {
        wp_enqueue_style('digjy-stores');
        $atts = shortcode_atts(['product_id' => 0], $atts, 'digjy_nft_mint_ui');
        $product_id = absint($atts['product_id'] ?: ($_GET['digjy_product_id'] ?? 0));
        if (!$product_id) {
            return $this->seller_product_builder(['product_id' => 0]);
        }
        $product = get_post($product_id);
        if (!$product || 'digjy_product' !== $product->post_type) { return ''; }
        ob_start();
        echo '<div class="digjy-card"><h3>' . esc_html__('NFT Mint UI + Royalties', 'digjy-stores') . '</h3>';
        echo '<p class="digjy-help">' . esc_html__('This product is configured for Crossmint-ready mint metadata and royalty settings. Save these fields in the seller product builder, then use checkout to sell the mint-enabled asset.', 'digjy-stores') . '</p>';
        echo '<div class="digjy-mini-grid">';
        $items = [
            __('Product Type', 'digjy-stores') => get_post_meta($product_id, '_digjy_product_type', true),
            __('Collection Locator', 'digjy-stores') => get_post_meta($product_id, '_digjy_collection_locator', true),
            __('Royalty %', 'digjy-stores') => get_post_meta($product_id, '_digjy_royalty_percent', true),
            __('Royalty Recipient', 'digjy-stores') => get_post_meta($product_id, '_digjy_royalty_recipient', true),
            __('Buyer Creator Royalty %', 'digjy-stores') => get_post_meta($product_id, '_digjy_buyer_creator_royalty_percent', true),
            __('Template ID', 'digjy-stores') => get_post_meta($product_id, '_digjy_nft_template_id', true),
        ];
        foreach ($items as $label => $value) {
            echo '<div class="digjy-mini-item"><strong>' . esc_html($label) . '</strong><br />' . esc_html((string) $value ?: '—') . '</div>';
        }
        echo '</div>';
        echo '<p><a class="digjy-btn" href="' . esc_url(add_query_arg('digjy_product_id', $product_id, get_permalink())) . '">' . esc_html__('Open Product Builder', 'digjy-stores') . '</a></p></div>';
        return $this->wrap_output(ob_get_clean(), 'digjy-shortcode-block');
    }


    private function marketplace_page_url($key, $fallback = '') {
        $settings = Digjy_Stores::get_settings();
        $url = !empty($settings[$key]) ? esc_url_raw($settings[$key]) : '';
        return $url ?: ($fallback ? esc_url_raw($fallback) : home_url('/'));
    }

    private function get_basic_product_card_data($product_id) {
        $product = get_post($product_id);
        if (!$product || 'digjy_product' !== $product->post_type) {
            return null;
        }
        $image = get_post_meta($product_id, '_digjy_featured_image', true);
        if (!$image && has_post_thumbnail($product_id)) {
            $image = get_the_post_thumbnail_url($product_id, 'medium');
        }
        return [
            'id' => (int) $product_id,
            'title' => get_the_title($product_id),
            'url' => get_permalink($product_id),
            'image' => $image ?: '',
            'price' => (float) get_post_meta($product_id, '_digjy_price', true),
            'excerpt' => get_post_meta($product_id, '_digjy_brief_details', true) ?: get_the_excerpt($product_id),
        ];
    }

    private function render_marketplace_saved_products_ui($type, $title, $empty_message) {
        wp_enqueue_style('digjy-stores');
        wp_enqueue_script('digjy-stores');
        $checkout_url = $this->marketplace_page_url('checkout_page_url', home_url('/checkout/'));
        $cart_url = $this->marketplace_page_url('cart_page_url', home_url('/my-cart/'));
        ob_start();
        echo '<div class="digjy-card digjy-saved-products-ui" data-digjy-list-type="' . esc_attr($type) . '" data-checkout-url="' . esc_url($checkout_url) . '" data-cart-url="' . esc_url($cart_url) . '">';
        echo '<div class="digjy-dig-list-header">';
        echo '<div><h3>' . esc_html($title) . '</h3><p class="digjy-help digjy-dig-list-subtitle">' . esc_html__('Keep track of digital products you want to revisit, compare, or purchase later.', 'digjy-stores') . '</p></div>';
        echo '<div class="digjy-dig-list-count" aria-live="polite">0</div>';
        echo '</div>';
        echo '<div class="digjy-dig-list-toolbar">';
        echo '<input type="search" class="digjy-input digjy-dig-list-search" placeholder="' . esc_attr__('Search saved products...', 'digjy-stores') . '" aria-label="' . esc_attr__('Search saved products', 'digjy-stores') . '" />';
        echo '<select class="digjy-input digjy-dig-list-sort" aria-label="' . esc_attr__('Sort saved products', 'digjy-stores') . '"><option value="recent">' . esc_html__('Recently Saved', 'digjy-stores') . '</option><option value="price_low">' . esc_html__('Price: Low to High', 'digjy-stores') . '</option><option value="price_high">' . esc_html__('Price: High to Low', 'digjy-stores') . '</option><option value="az">' . esc_html__('Title A-Z', 'digjy-stores') . '</option></select>';
        echo '<button type="button" class="digjy-btn digjy-share-list">' . esc_html__('Share List', 'digjy-stores') . '</button>';
        if ($type === 'dig_list') {
            echo '<button type="button" class="digjy-btn digjy-move-all-to-cart">' . esc_html__('Add All To Cart', 'digjy-stores') . '</button>';
        }
        echo '<button type="button" class="digjy-btn digjy-clear-list">' . esc_html__('Clear', 'digjy-stores') . '</button>';
        echo '</div>';
        echo '<div class="digjy-dig-list-share-panel digjy-alert" style="display:none;"><strong>' . esc_html__('Shareable List Link:', 'digjy-stores') . '</strong><input type="text" class="digjy-input digjy-share-url" readonly /><button type="button" class="digjy-btn digjy-copy-share-url">' . esc_html__('Copy Link', 'digjy-stores') . '</button></div>';
        echo '<div class="digjy-saved-products-grid digjy-grid" data-empty-message="' . esc_attr($empty_message) . '"></div>';
        echo '<div class="digjy-saved-products-empty digjy-alert" style="display:none;">' . esc_html($empty_message) . '</div>';
        echo '</div>';
        return $this->wrap_output(ob_get_clean(), 'digjy-shortcode-block digjy-marketplace-page');
    }

    public function thank_you_downloads($atts = []) {
        wp_enqueue_style('digjy-stores');
        wp_enqueue_script('digjy-stores');
        if (!is_user_logged_in()) {
            return $this->wrap_output('<div class="digjy-alert">' . esc_html__('Please log in to view your purchase downloads and notes.', 'digjy-stores') . '</div>', 'digjy-shortcode-alert');
        }
        $settings = Digjy_Stores::get_settings();
        $order_id = absint($_GET['digjy_order_id'] ?? $_GET['order_id'] ?? 0);
        $user = wp_get_current_user();
        $args = [
            'post_type' => 'digjy_order',
            'post_status' => 'publish',
            'posts_per_page' => $order_id ? 1 : 20,
            'meta_key' => '_digjy_buyer_email',
            'meta_value' => $user->user_email,
        ];
        if ($order_id) {
            $args['p'] = $order_id;
            unset($args['meta_key'], $args['meta_value']);
        }
        $orders = get_posts($args);
        ob_start();
        echo '<div class="digjy-card"><h3>' . esc_html__('Thank You For Your Purchase', 'digjy-stores') . '</h3>';
        echo '<p class="digjy-help">' . esc_html__('Your digital downloads and purchase notes are shown below after payment is completed.', 'digjy-stores') . '</p></div>';
        echo '<div class="digjy-grid">';
        foreach ($orders as $order) {
            if ($order_id) {
                $buyer_id = (int) get_post_meta($order->ID, '_digjy_order_user_id', true);
                $buyer_email = get_post_meta($order->ID, '_digjy_buyer_email', true);
                if ($buyer_id && $buyer_id !== get_current_user_id() && $buyer_email !== $user->user_email && !current_user_can('manage_options')) {
                    continue;
                }
            }
            $status = get_post_meta($order->ID, '_digjy_order_status', true);
            echo '<div class="digjy-card"><h4>' . esc_html($order->post_title) . '</h4>';
            echo '<p><strong>' . esc_html__('Status:', 'digjy-stores') . '</strong> ' . esc_html($status ?: __('Pending', 'digjy-stores')) . '</p>';
            $product_id = (int) get_post_meta($order->ID, '_digjy_product_id', true);
            $purchase_note = $product_id ? get_post_meta($product_id, '_digjy_purchase_note', true) : '';
            if (in_array($status, ['paid','completed'], true)) {
                $download_url = $this->checkout->get_download_url($order->ID);
                if ($download_url) {
                    echo '<p><a class="digjy-btn" href="' . esc_url($download_url) . '">' . esc_html__('Download Digital Product', 'digjy-stores') . '</a></p>';
                }
                if (!empty($purchase_note)) {
                    echo '<div class="digjy-purchase-note"><strong>' . esc_html__('Purchase Note:', 'digjy-stores') . '</strong><div>' . wpautop(wp_kses_post($purchase_note)) . '</div></div>';
                }
            } else {
                echo '<p class="digjy-help">' . esc_html__('Downloads and purchase notes unlock after payment is completed.', 'digjy-stores') . '</p>';
            }
            echo '</div>';
        }
        echo '</div>';
        return $this->wrap_output(ob_get_clean(), 'digjy-shortcode-block digjy-thank-you-downloads');
    }

    public function dig_list($atts = []) {
        return $this->render_marketplace_saved_products_ui('dig_list', __('My Dig List', 'digjy-stores'), __('Your Dig List is empty. Save digital products you want to revisit later.', 'digjy-stores'));
    }

    public function recently_viewed($atts = []) {
        return $this->render_marketplace_saved_products_ui('recently_viewed', __('Recently Viewed', 'digjy-stores'), __('You have not viewed any Digjy products yet.', 'digjy-stores'));
    }

    public function cart_shortcode($atts = []) {
        return $this->render_marketplace_saved_products_ui('cart', __('My Cart', 'digjy-stores'), __('Your cart is empty.', 'digjy-stores'));
    }

}
