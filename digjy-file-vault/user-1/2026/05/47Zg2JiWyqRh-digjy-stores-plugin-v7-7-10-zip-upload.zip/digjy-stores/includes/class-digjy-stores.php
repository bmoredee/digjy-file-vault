<?php
if (!defined('ABSPATH')) {
    exit;
}

require_once DIGJY_STORES_PATH . 'includes/class-digjy-stores-admin.php';
require_once DIGJY_STORES_PATH . 'includes/class-digjy-stores-vendors.php';
require_once DIGJY_STORES_PATH . 'includes/class-digjy-stores-products.php';
require_once DIGJY_STORES_PATH . 'includes/class-digjy-stores-checkout.php';
require_once DIGJY_STORES_PATH . 'includes/class-digjy-stores-shortcodes.php';
require_once DIGJY_STORES_PATH . 'includes/class-digjy-stores-sync.php';
require_once DIGJY_STORES_PATH . 'includes/class-digjy-stores-elementor.php';
require_once DIGJY_STORES_PATH . 'includes/class-digjy-stores-api.php';
require_once DIGJY_STORES_PATH . 'includes/class-digjy-stores-upgrades.php';

class Digjy_Stores {
    private static $instance = null;
    public $admin;
    public $vendors;
    public $products;
    public $checkout;
    public $shortcodes;
    public $sync;
    public $elementor;
    public $api;
    public $upgrades;

    public static function instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function __construct() {
        add_action('init', [$this, 'load_textdomain']);
        add_action('init', [$this, 'register_roles']);
        add_action('plugins_loaded', [$this, 'init_components']);
        add_action('init', [$this, 'register_assets']);
        add_action('admin_enqueue_scripts', [$this, 'admin_register_assets']);
    }

    public function load_textdomain() {
        load_plugin_textdomain('digjy-stores', false, dirname(plugin_basename(DIGJY_STORES_FILE)) . '/languages');
    }

    public function init_components() {
        $this->admin = new Digjy_Stores_Admin();
        $this->vendors = new Digjy_Stores_Vendors();
        $this->products = new Digjy_Stores_Products();
        $this->checkout = new Digjy_Stores_Checkout();
        $this->shortcodes = new Digjy_Stores_Shortcodes($this->checkout, $this->products, $this->vendors);
        $this->sync = new Digjy_Stores_Sync($this->checkout);
        $this->elementor = new Digjy_Stores_Elementor();
        $this->api = new Digjy_Stores_API();
        $this->upgrades = new Digjy_Stores_Upgrades();
    }



    public function resolve_store_root_request($query) {
        if (is_admin() || !$query->is_main_query()) {
            return;
        }
        $slug = get_query_var('digjy_store_slug');
        if (empty($slug)) {
            return;
        }
        $slug = sanitize_title_for_query($slug);
        if (!$slug) {
            return;
        }
        // Respect real pages/posts/attachments if they already own the slug.
        if (get_page_by_path($slug, OBJECT, ['page', 'post', 'attachment'])) {
            return;
        }
        $store = get_page_by_path($slug, OBJECT, 'digjy_store');
        if (!$store) {
            return;
        }
        $query->set('post_type', 'digjy_store');
        $query->set('name', $slug);
        $query->set('digjy_store_slug', null);
    }

    public function register_assets() {
        if (wp_style_is('digjy-stores', 'registered') && wp_script_is('digjy-stores', 'registered')) {
            return;
        }

        wp_register_style('digjy-stores', DIGJY_STORES_URL . 'assets/css/digjy-stores.css', [], DIGJY_STORES_VERSION);
        wp_register_script('digjy-stores', DIGJY_STORES_URL . 'assets/js/digjy-stores.js', ['jquery'], DIGJY_STORES_VERSION, true);
        wp_localize_script('digjy-stores', 'DigjyStores', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce'   => wp_create_nonce('digjy_stores_nonce'),
            'pollInterval' => 4000,
            'currentUserId' => get_current_user_id(),
            'crossmintClientApiKey' => self::get_settings()['crossmint_client_api_key'] ?? '',
            'solanaRpcUrl' => self::get_settings()['solana_rpc_url'] ?? 'https://api.mainnet-beta.solana.com',
            'i18n'    => [
                'creatingCheckout' => __('Creating checkout...', 'digjy-stores'),
                'checkoutFailed'   => __('Checkout failed.', 'digjy-stores'),
                'markingPaid'      => __('Marking order as paid...', 'digjy-stores'),
                'saved'            => __('Saved.', 'digjy-stores'),
                'checkingStatus'   => __('Checking payment status...', 'digjy-stores'),
                'connectWallet'    => __('Connect your Solana wallet and complete the payment.', 'digjy-stores'),
                'cardReady'        => __('Card checkout created. Continue with card payment.', 'digjy-stores'),
                'walletRequired'   => __('A Solana wallet address is required for Solana payments.', 'digjy-stores'),
                'embeddedInitFailed' => __('Unable to load Crossmint embedded checkout.', 'digjy-stores'),
                'phantomRequired' => __('Phantom wallet was not found in this browser.', 'digjy-stores'),
                'signingTransaction' => __('Requesting wallet signature...', 'digjy-stores'),
                'submittingTransaction' => __('Submitting signed Solana transaction...', 'digjy-stores'),
            ],
        ]);
    }


    public function admin_register_assets($hook = '') {
        if (!is_admin()) {
            return;
        }

        $allowed_hooks = [
            'toplevel_page_digjy-stores',
            'digjy-stores_page_digjy-stores-shortcodes',
            'digjy-stores_page_digjy-stores-ledger',
            'digjy-stores_page_digjy-stores-sync',
        ];

        if (!in_array($hook, $allowed_hooks, true)) {
            return;
        }

        $this->register_assets();
    }

    public function register_roles() {
        $store_owner_caps = [
            'read' => true,
            'upload_files' => true,
            'edit_posts' => true,
            'delete_posts' => true,
            'publish_posts' => true,
            'edit_published_posts' => true,
        ];

        add_role('digjy_store_owner', __('Digjy Store Owner', 'digjy-stores'), $store_owner_caps);
        add_role('digjy_customer', __('Digjy Customer', 'digjy-stores'), [
            'read' => true,
        ]);

        // Backward compatibility for older installs that used digjy_seller.
        add_role('digjy_seller', __('Digjy Seller', 'digjy-stores'), $store_owner_caps);

        foreach (['digjy_store_owner', 'digjy_seller'] as $role_name) {
            $role = get_role($role_name);
            if ($role) {
                foreach (array_keys($store_owner_caps) as $cap) {
                    $role->add_cap($cap);
                }
            }
        }

        $customer = get_role('digjy_customer');
        if ($customer) {
            $customer->add_cap('read');
        }
    }

    public static function activate() {
        $plugin = self::instance();
        $plugin->register_roles();
        require_once DIGJY_STORES_PATH . 'includes/class-digjy-stores-products.php';
        require_once DIGJY_STORES_PATH . 'includes/class-digjy-stores-vendors.php';
        require_once DIGJY_STORES_PATH . 'includes/class-digjy-stores-checkout.php';
        require_once DIGJY_STORES_PATH . 'includes/class-digjy-stores-sync.php';
        require_once DIGJY_STORES_PATH . 'includes/class-digjy-stores-elementor.php';
        require_once DIGJY_STORES_PATH . 'includes/class-digjy-stores-api.php';
        require_once DIGJY_STORES_PATH . 'includes/class-digjy-stores-upgrades.php';
        self::migrate_roles();
        Digjy_Stores_Products::register_post_types();
        Digjy_Stores_Vendors::register_post_types();
        Digjy_Stores_Checkout::register_download_endpoint();
        Digjy_Stores_Checkout::register_webhook_endpoint();
        Digjy_Stores_Sync::register_post_types();
        Digjy_Stores_API::register_post_types();
        Digjy_Stores_Upgrades::register_post_types();
        Digjy_Stores_Sync::schedule();
        flush_rewrite_rules();
    }


    public static function migrate_roles() {
        $users = get_users([
            'role' => 'digjy_seller',
            'fields' => ['ID'],
            'number' => -1,
        ]);

        foreach ($users as $user_obj) {
            $user = new WP_User($user_obj->ID);
            $user->add_role('digjy_store_owner');
        }

        $customer_users = get_users([
            'role__in' => ['subscriber'],
            'meta_key' => 'digjy_customer_created',
            'fields' => ['ID'],
            'number' => -1,
        ]);

        foreach ($customer_users as $user_obj) {
            $user = new WP_User($user_obj->ID);
            $user->add_role('digjy_customer');
        }
    }

    public static function deactivate() {
        Digjy_Stores_Sync::unschedule();
        flush_rewrite_rules();
    }

    public static function get_settings() {
        $defaults = [
            'groq_api_key' => '',
            'crossmint_api_key' => '',
            'crossmint_client_api_key' => '',
            'crossmint_environment' => 'production',
            'crossmint_collection_locator' => '',
            'marketplace_wallet' => '',
            'marketplace_commission' => 10,
            'seller_commission' => 90,
            'currency' => 'usdc',
            'card_currency' => 'usd',
            'default_payment_method' => 'solana',
            'download_expiry_days' => 7,
            'download_limit' => 5,
            'webhook_secret' => '',
            'auto_create_wallets' => 1,
            'shadow_dom_isolation' => 1,
            'asset_detection_engine' => 1,
            'wallet_chain_type' => 'solana',
            'solana_rpc_url' => 'https://api.mainnet-beta.solana.com',
            'jsdelivr_github_owner' => '',
            'jsdelivr_github_repo' => '',
            'jsdelivr_github_branch' => 'main',
            'jsdelivr_github_token' => '',
            'jsdelivr_upload_folder' => 'digjy-products',
            'checkout_page_url' => '',
            'thank_you_page_url' => '',
            'dig_list_page_url' => '',
            'recently_viewed_page_url' => '',
            'cart_page_url' => '',
        ];

        return wp_parse_args(get_option('digjy_stores_settings', []), $defaults);
    }
}
