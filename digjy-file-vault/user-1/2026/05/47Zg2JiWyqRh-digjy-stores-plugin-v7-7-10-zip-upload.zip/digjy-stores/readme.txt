=== Digjy Stores ===
Contributors: digjy
Tags: marketplace, multivendor, digital downloads, crossmint, solana, nft
Requires at least: 6.0
Tested up to: 6.5
Stable tag: 6.0.0
License: GPLv2 or later

Digjy Stores creates a multi-vendor digital marketplace with frontend seller registration, storefronts, protected downloads, payout ledger export, Crossmint checkout scaffolding, card vs Solana payment selection, and status polling.


Version 6 adds a webhook event log, admin sync center, scheduled Crossmint order sync, and automatic product metadata sync from related order payloads.


Version 6.1.0
- Added Elementor compatibility layer
- Added Digjy Stores Elementor widget category
- Added native Elementor widget wrapper for plugin shortcodes
- Improved asset loading for Elementor editor and frontend
