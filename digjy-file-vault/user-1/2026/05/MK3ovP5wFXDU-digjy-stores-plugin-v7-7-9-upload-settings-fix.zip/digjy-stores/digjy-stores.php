<?php
/**
 * Plugin Name: Digjy Stores
 * Plugin URI: https://www.digjy.com/
 * Description: Multi-vendor digital marketplace plugin for WordPress with vendor stores, commissions, frontend dashboards, protected downloads, payout ledger, and Crossmint headless checkout integration.
 * Version: 7.7.9
 * Author: Digjy
 * License: GPL2+
 * Text Domain: digjy-stores
 */

if (!defined('ABSPATH')) {
    exit;
}

define('DIGJY_STORES_VERSION', '7.7.9');
define('DIGJY_STORES_FILE', __FILE__);
define('DIGJY_STORES_PATH', plugin_dir_path(__FILE__));
define('DIGJY_STORES_URL', plugin_dir_url(__FILE__));

require_once DIGJY_STORES_PATH . 'includes/class-digjy-stores.php';


function digjy_stores_clean_output_buffers() {
    while (ob_get_level() > 0) {
        @ob_end_clean();
    }
}

function digjy_stores_safe_redirect($url) {
    digjy_stores_clean_output_buffers();
    wp_safe_redirect($url);
    exit;
}

function digjy_stores() {
    return Digjy_Stores::instance();
}

register_activation_hook(__FILE__, ['Digjy_Stores', 'activate']);
register_deactivation_hook(__FILE__, ['Digjy_Stores', 'deactivate']);

digjy_stores();
