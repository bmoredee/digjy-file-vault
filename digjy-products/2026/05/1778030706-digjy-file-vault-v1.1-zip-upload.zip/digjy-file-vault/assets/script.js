jQuery(function($){
  const $form = $('#digjy-vault-upload-form');
  const $grid = $('#digjy-vault-grid');
  const $message = $('#digjy-vault-message');

  function showMessage(text, type){
    $message.removeClass('success error').addClass(type).text(text).show();
  }

  function refreshGrid(html){
    $grid.html(html);
  }

  $form.on('submit', function(e){
    e.preventDefault();
    const fileInput = $('#digjy-vault-file')[0];
    if(!fileInput.files.length){
      showMessage('Choose one or more files first. ZIP files are supported.', 'error');
      return;
    }
    const data = new FormData();
    data.append('action', 'digjy_file_vault_upload');
    data.append('nonce', DigjyFileVault.nonce);
    Array.from(fileInput.files).forEach(function(file){
      data.append('vault_files[]', file);
    });

    const $button = $form.find('button[type=submit]');
    $button.prop('disabled', true).text(fileInput.files.length > 1 ? 'Uploading files...' : 'Uploading...');

    $.ajax({
      url: DigjyFileVault.ajaxUrl,
      method: 'POST',
      data,
      processData: false,
      contentType: false
    }).done(function(res){
      if(res.success){
        showMessage(res.data.message, 'success');
        refreshGrid(res.data.html);
        $form[0].reset();
      } else {
        showMessage(res.data && res.data.message ? res.data.message : 'Upload failed.', 'error');
      }
    }).fail(function(xhr){
      const text = xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message ? xhr.responseJSON.data.message : 'Upload failed.';
      showMessage(text, 'error');
    }).always(function(){
      $button.prop('disabled', false).text('Upload Files / ZIP');
    });
  });

  $(document).on('click', '.digjy-delete-btn', function(){
    if(!confirm('Delete this file?')) return;
    const id = $(this).data('id');
    const $btn = $(this);
    $btn.prop('disabled', true).text('Deleting...');

    $.post(DigjyFileVault.ajaxUrl, {
      action: 'digjy_file_vault_delete',
      nonce: DigjyFileVault.nonce,
      file_id: id
    }).done(function(res){
      if(res.success){
        showMessage(res.data.message, 'success');
        refreshGrid(res.data.html);
      } else {
        showMessage(res.data && res.data.message ? res.data.message : 'Delete failed.', 'error');
      }
    }).fail(function(xhr){
      const text = xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message ? xhr.responseJSON.data.message : 'Delete failed.';
      showMessage(text, 'error');
    }).always(function(){
      $btn.prop('disabled', false).text('Delete');
    });
  });

  $(document).on('click', '.digjy-copy-btn', function(){
    const text = $(this).data('copy');
    navigator.clipboard.writeText(text).then(() => {
      showMessage('URL copied.', 'success');
    }).catch(() => {
      showMessage('Could not copy the URL.', 'error');
    });
  });
});
