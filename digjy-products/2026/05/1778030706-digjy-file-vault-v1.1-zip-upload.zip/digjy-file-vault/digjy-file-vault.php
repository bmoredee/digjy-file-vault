<?php
/*
Plugin Name: Digjy File Vault
Description: Frontend file vault for WordPress users with per-user uploads, view/delete controls, and jsDelivr-backed file URLs via a GitHub repository.
Version: 1.1.0
Author: OpenAI
*/

if (!defined('ABSPATH')) {
    exit;
}

class Digjy_File_Vault {
    const VERSION = '1.1.0';
    const TABLE = 'digjy_file_vault';
    const OPTION = 'digjy_file_vault_settings';
    const NONCE = 'digjy_file_vault_nonce';

    public function __construct() {
        register_activation_hook(__FILE__, [$this, 'activate']);
        add_action('admin_menu', [$this, 'admin_menu']);
        add_action('admin_init', [$this, 'register_settings']);
        add_shortcode('digjy_file_vault', [$this, 'shortcode']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_assets']);

        add_action('wp_ajax_digjy_file_vault_upload', [$this, 'ajax_upload']);
        add_action('wp_ajax_digjy_file_vault_delete', [$this, 'ajax_delete']);
        add_action('wp_ajax_digjy_file_vault_list', [$this, 'ajax_list']);

        add_action('init', [$this, 'handle_public_routes']);
    }

    public function activate() {
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE;
        $charset_collate = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE {$table} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT UNSIGNED NOT NULL,
            github_path VARCHAR(255) NOT NULL,
            github_sha VARCHAR(255) NOT NULL,
            original_name VARCHAR(255) NOT NULL,
            mime_type VARCHAR(120) NOT NULL,
            size_bytes BIGINT UNSIGNED NOT NULL DEFAULT 0,
            jsdelivr_url TEXT NOT NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY user_id (user_id)
        ) {$charset_collate};";
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    public function admin_menu() {
        add_options_page(
            'Digjy File Vault',
            'Digjy File Vault',
            'manage_options',
            'digjy-file-vault',
            [$this, 'settings_page']
        );
    }

    public function register_settings() {
        register_setting(self::OPTION, self::OPTION, [$this, 'sanitize_settings']);

        add_settings_section(
            'digjy_file_vault_main',
            'GitHub + jsDelivr Settings',
            function () {
                echo '<p>jsDelivr cannot receive direct uploads by itself. This plugin uploads files to a GitHub repository through the GitHub API, then serves them through jsDelivr CDN URLs.</p>';
            },
            'digjy-file-vault'
        );

        $fields = [
            'github_owner' => 'GitHub Owner',
            'github_repo' => 'GitHub Repository',
            'github_branch' => 'GitHub Branch',
            'github_token' => 'GitHub Personal Access Token',
            'base_directory' => 'Base Directory in Repo',
            'allowed_mimes' => 'Allowed MIME Types (comma separated)',
            'max_file_size_mb' => 'Max File Size (MB)',
        ];

        foreach ($fields as $key => $label) {
            add_settings_field(
                $key,
                $label,
                [$this, 'render_field'],
                'digjy-file-vault',
                'digjy_file_vault_main',
                ['key' => $key, 'label' => $label]
            );
        }
    }

    public function sanitize_settings($input) {
        $output = [];
        $output['github_owner'] = sanitize_text_field($input['github_owner'] ?? '');
        $output['github_repo'] = sanitize_text_field($input['github_repo'] ?? '');
        $output['github_branch'] = sanitize_text_field($input['github_branch'] ?? 'main');
        $output['github_token'] = sanitize_text_field($input['github_token'] ?? '');
        $output['base_directory'] = trim(sanitize_text_field($input['base_directory'] ?? 'digjy-file-vault'), '/');
        $output['allowed_mimes'] = sanitize_text_field($input['allowed_mimes'] ?? 'image/jpeg,image/png,image/webp,image/gif,application/pdf,application/zip,application/x-zip-compressed,multipart/x-zip,application/x-compressed,application/octet-stream,text/plain,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document');
        $output['max_file_size_mb'] = max(1, absint($input['max_file_size_mb'] ?? 20));
        return $output;
    }

    public function render_field($args) {
        $settings = $this->get_settings();
        $key = $args['key'];
        $value = $settings[$key] ?? '';
        $type = $key === 'github_token' ? 'password' : ($key === 'max_file_size_mb' ? 'number' : 'text');
        printf(
            '<input type="%1$s" class="regular-text" name="%2$s[%3$s]" value="%4$s" %5$s />',
            esc_attr($type),
            esc_attr(self::OPTION),
            esc_attr($key),
            esc_attr($value),
            $type === 'number' ? 'min="1" step="1"' : ''
        );
    }

    public function settings_page() {
        ?>
        <div class="wrap">
            <h1>Digjy File Vault</h1>
            <form method="post" action="options.php">
                <?php
                settings_fields(self::OPTION);
                do_settings_sections('digjy-file-vault');
                submit_button();
                ?>
            </form>
            <p><strong>Shortcode:</strong> <code>[digjy_file_vault]</code></p>
        </div>
        <?php
    }

    private function get_settings() {
        $defaults = [
            'github_owner' => '',
            'github_repo' => '',
            'github_branch' => 'main',
            'github_token' => '',
            'base_directory' => 'digjy-file-vault',
            'allowed_mimes' => 'image/jpeg,image/png,image/webp,image/gif,application/pdf,application/zip,application/x-zip-compressed,multipart/x-zip,application/x-compressed,application/octet-stream,text/plain,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'max_file_size_mb' => 20,
        ];
        return wp_parse_args(get_option(self::OPTION, []), $defaults);
    }

    public function enqueue_assets() {
        if (!is_user_logged_in()) {
            return;
        }
        wp_register_style('digjy-file-vault', plugins_url('assets/style.css', __FILE__), [], self::VERSION);
        wp_register_script('digjy-file-vault', plugins_url('assets/script.js', __FILE__), ['jquery'], self::VERSION, true);
        wp_localize_script('digjy-file-vault', 'DigjyFileVault', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce(self::NONCE),
        ]);
    }

    public function shortcode() {
        if (!is_user_logged_in()) {
            return '<div class="digjy-vault-login">Please log in to access your file vault.</div>';
        }

        wp_enqueue_style('digjy-file-vault');
        wp_enqueue_script('digjy-file-vault');

        ob_start();
        ?>
        <div class="digjy-vault-wrap">
            <div class="digjy-vault-header">
                <div>
                    <h2>Digjy File Vault</h2>
                    <p>Upload files, ZIP folders, view, copy URLs, and delete only your own media.</p>
                </div>
            </div>

            <form id="digjy-vault-upload-form" class="digjy-vault-upload" enctype="multipart/form-data">
                <input type="file" name="vault_files[]" id="digjy-vault-file" multiple accept="image/*,.pdf,.zip,.txt,.doc,.docx,application/zip,application/x-zip-compressed" required />
                <button type="submit">Upload Files / ZIP</button>
            </form>

            <div id="digjy-vault-message" class="digjy-vault-message" style="display:none;"></div>
            <div id="digjy-vault-grid" class="digjy-vault-grid"><?php echo $this->render_cards(get_current_user_id()); ?></div>
        </div>
        <?php
        return ob_get_clean();
    }

    private function render_cards($user_id) {
        $files = $this->get_user_files($user_id);
        if (empty($files)) {
            return '<div class="digjy-vault-empty">No files uploaded yet.</div>';
        }

        ob_start();
        foreach ($files as $file) {
            $is_image = strpos($file->mime_type, 'image/') === 0;
            $view_url = add_query_arg('digjy_vault_view', (int) $file->id, home_url('/'));
            $download_url = add_query_arg('digjy_vault_download', (int) $file->id, home_url('/'));
            ?>
            <div class="digjy-vault-card" data-id="<?php echo (int) $file->id; ?>">
                <div class="digjy-vault-thumb">
                    <?php if ($is_image): ?>
                        <img src="<?php echo esc_url($file->jsdelivr_url); ?>" alt="<?php echo esc_attr($file->original_name); ?>" />
                    <?php else: ?>
                        <div class="digjy-vault-file-icon"><?php echo esc_html(strtoupper(pathinfo($file->original_name, PATHINFO_EXTENSION) ?: 'FILE')); ?></div>
                    <?php endif; ?>
                </div>
                <div class="digjy-vault-card-body">
                    <h3 title="<?php echo esc_attr($file->original_name); ?>"><?php echo esc_html($file->original_name); ?></h3>
                    <p><?php echo esc_html(size_format((int) $file->size_bytes, 2)); ?> • <?php echo esc_html($file->mime_type); ?></p>

                    <label>View URL</label>
                    <div class="digjy-vault-url-row">
                        <input type="text" readonly value="<?php echo esc_url($view_url); ?>" />
                        <button class="digjy-copy-btn" type="button" data-copy="<?php echo esc_attr($view_url); ?>">Copy</button>
                    </div>

                    <label>Download URL</label>
                    <div class="digjy-vault-url-row">
                        <input type="text" readonly value="<?php echo esc_url($download_url); ?>" />
                        <button class="digjy-copy-btn" type="button" data-copy="<?php echo esc_attr($download_url); ?>">Copy</button>
                    </div>

                    <div class="digjy-vault-actions">
                        <a href="<?php echo esc_url($view_url); ?>" target="_blank" rel="noopener">View</a>
                        <a href="<?php echo esc_url($download_url); ?>">Download</a>
                        <button class="digjy-delete-btn" type="button" data-id="<?php echo (int) $file->id; ?>">Delete</button>
                    </div>
                </div>
            </div>
            <?php
        }
        return ob_get_clean();
    }

    private function get_user_files($user_id) {
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE;
        return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$table} WHERE user_id = %d ORDER BY created_at DESC", $user_id));
    }

    public function ajax_list() {
        $this->validate_ajax_request();
        wp_send_json_success(['html' => $this->render_cards(get_current_user_id())]);
    }

    public function ajax_upload() {
        $this->validate_ajax_request();

        $settings = $this->get_settings();
        $this->assert_github_is_configured($settings);

        $files = $this->normalize_uploaded_files();
        if (empty($files)) {
            wp_send_json_error(['message' => 'No files received.'], 400);
        }

        $user_id = get_current_user_id();
        $uploaded_count = 0;
        foreach ($files as $file) {
            $result = $this->process_single_upload($file, $settings, $user_id);
            if (is_wp_error($result)) {
                wp_send_json_error(['message' => $result->get_error_message()], 400);
            }
            $uploaded_count++;
        }

        wp_send_json_success([
            'message' => $uploaded_count === 1 ? 'File uploaded successfully.' : $uploaded_count . ' files uploaded successfully.',
            'html' => $this->render_cards($user_id),
        ]);
    }

    private function normalize_uploaded_files() {
        if (!empty($_FILES['vault_files']) && is_array($_FILES['vault_files']['name'])) {
            $files = [];
            foreach ($_FILES['vault_files']['name'] as $index => $name) {
                if ($name === '') {
                    continue;
                }
                $files[] = [
                    'name' => $_FILES['vault_files']['name'][$index],
                    'type' => $_FILES['vault_files']['type'][$index] ?? '',
                    'tmp_name' => $_FILES['vault_files']['tmp_name'][$index] ?? '',
                    'error' => $_FILES['vault_files']['error'][$index] ?? UPLOAD_ERR_NO_FILE,
                    'size' => $_FILES['vault_files']['size'][$index] ?? 0,
                ];
            }
            return $files;
        }

        if (!empty($_FILES['vault_file']) && isset($_FILES['vault_file']['tmp_name'])) {
            return [$_FILES['vault_file']];
        }

        return [];
    }

    private function process_single_upload($file, $settings, $user_id) {
        if (!empty($file['error'])) {
            return new WP_Error('digjy_upload_error', 'Upload failed with error code ' . absint($file['error']) . '.');
        }

        $max_bytes = ((int) $settings['max_file_size_mb']) * 1024 * 1024;
        if ((int) $file['size'] > $max_bytes) {
            return new WP_Error('digjy_file_too_large', sanitize_file_name($file['name']) . ' exceeds the max allowed size.');
        }

        $filename = sanitize_file_name($file['name']);
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        $mime = $this->detect_mime_type($file['tmp_name'], $file['type'], $ext);
        $allowed = array_filter(array_map('trim', explode(',', (string) $settings['allowed_mimes'])));

        if (!in_array($mime, $allowed, true) && !($ext === 'zip' && $this->is_zip_mime_allowed($allowed))) {
            return new WP_Error('digjy_disallowed_type', $filename . ' is not an allowed file type. ZIP files are supported when ZIP MIME types are enabled in settings.');
        }

        $contents = file_get_contents($file['tmp_name']);
        if ($contents === false) {
            return new WP_Error('digjy_read_failed', 'Could not read ' . $filename . '.');
        }

        $safe_name = wp_unique_filename('', sanitize_title(pathinfo($filename, PATHINFO_FILENAME)) . ($ext ? '.' . $ext : ''));
        $github_path = trim($settings['base_directory'], '/') . '/user-' . $user_id . '/' . gmdate('Y/m') . '/' . wp_generate_password(12, false, false) . '-' . $safe_name;

        $upload = $this->github_upload($settings, $github_path, $contents, 'Upload via Digjy File Vault');
        if (is_wp_error($upload)) {
            return $upload;
        }

        global $wpdb;
        $table = $wpdb->prefix . self::TABLE;
        $inserted = $wpdb->insert($table, [
            'user_id' => $user_id,
            'github_path' => $github_path,
            'github_sha' => $upload['content']['sha'] ?? '',
            'original_name' => $filename,
            'mime_type' => $mime,
            'size_bytes' => (int) $file['size'],
            'jsdelivr_url' => $this->build_jsdelivr_url($settings, $github_path),
            'created_at' => current_time('mysql', 1),
        ], ['%d','%s','%s','%s','%s','%d','%s','%s']);

        if (!$inserted) {
            return new WP_Error('digjy_db_failed', $filename . ' uploaded, but the database record could not be saved.');
        }

        return true;
    }

    private function detect_mime_type($tmp_name, $reported_type, $ext) {
        $mime = sanitize_mime_type($reported_type);
        if (function_exists('wp_check_filetype_and_ext')) {
            $checked = wp_check_filetype_and_ext($tmp_name, basename($tmp_name . '.' . $ext));
            if (!empty($checked['type'])) {
                $mime = sanitize_mime_type($checked['type']);
            }
        }
        if ($ext === 'zip' && (empty($mime) || $mime === 'application/octet-stream')) {
            $mime = 'application/zip';
        }
        return $mime ?: 'application/octet-stream';
    }

    private function is_zip_mime_allowed($allowed) {
        return (bool) array_intersect($allowed, [
            'application/zip',
            'application/x-zip-compressed',
            'multipart/x-zip',
            'application/x-compressed',
            'application/octet-stream',
        ]);
    }

    public function ajax_delete() {
        $this->validate_ajax_request();
        $file_id = absint($_POST['file_id'] ?? 0);
        if (!$file_id) {
            wp_send_json_error(['message' => 'Invalid file ID.'], 400);
        }

        global $wpdb;
        $table = $wpdb->prefix . self::TABLE;
        $record = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id = %d AND user_id = %d", $file_id, get_current_user_id()));
        if (!$record) {
            wp_send_json_error(['message' => 'File not found.'], 404);
        }

        $settings = $this->get_settings();
        $this->assert_github_is_configured($settings);

        $deleted = $this->github_delete($settings, $record->github_path, $record->github_sha, 'Delete via Digjy File Vault');
        if (is_wp_error($deleted)) {
            wp_send_json_error(['message' => $deleted->get_error_message()], 500);
        }

        $wpdb->delete($table, ['id' => $file_id, 'user_id' => get_current_user_id()], ['%d','%d']);
        wp_send_json_success([
            'message' => 'File deleted successfully.',
            'html' => $this->render_cards(get_current_user_id()),
        ]);
    }

    private function validate_ajax_request() {
        if (!is_user_logged_in()) {
            wp_send_json_error(['message' => 'You must be logged in.'], 403);
        }
        check_ajax_referer(self::NONCE, 'nonce');
    }

    private function assert_github_is_configured($settings) {
        if (empty($settings['github_owner']) || empty($settings['github_repo']) || empty($settings['github_branch']) || empty($settings['github_token'])) {
            wp_send_json_error(['message' => 'The plugin is not fully configured yet. Add the GitHub owner, repo, branch, and token in Settings > Digjy File Vault.'], 400);
        }
    }

    private function github_upload($settings, $path, $contents, $message) {
        $endpoint = sprintf(
            'https://api.github.com/repos/%s/%s/contents/%s',
            rawurlencode($settings['github_owner']),
            rawurlencode($settings['github_repo']),
            str_replace('%2F', '/', rawurlencode($path))
        );

        $response = wp_remote_request($endpoint, [
            'method'  => 'PUT',
            'headers' => [
                'Authorization' => 'Bearer ' . $settings['github_token'],
                'Accept'        => 'application/vnd.github+json',
                'User-Agent'    => 'Digjy-File-Vault/' . self::VERSION,
            ],
            'body'    => wp_json_encode([
                'message' => $message,
                'content' => base64_encode($contents),
                'branch'  => $settings['github_branch'],
            ]),
            'timeout' => 60,
        ]);

        if (is_wp_error($response)) {
            return $response;
        }

        $code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);
        if ($code < 200 || $code >= 300) {
            return new WP_Error('github_upload_failed', $body['message'] ?? 'GitHub upload failed.');
        }
        return $body;
    }

    private function github_delete($settings, $path, $sha, $message) {
        $endpoint = sprintf(
            'https://api.github.com/repos/%s/%s/contents/%s',
            rawurlencode($settings['github_owner']),
            rawurlencode($settings['github_repo']),
            str_replace('%2F', '/', rawurlencode($path))
        );

        $response = wp_remote_request($endpoint, [
            'method'  => 'DELETE',
            'headers' => [
                'Authorization' => 'Bearer ' . $settings['github_token'],
                'Accept'        => 'application/vnd.github+json',
                'User-Agent'    => 'Digjy-File-Vault/' . self::VERSION,
            ],
            'body'    => wp_json_encode([
                'message' => $message,
                'sha'     => $sha,
                'branch'  => $settings['github_branch'],
            ]),
            'timeout' => 60,
        ]);

        if (is_wp_error($response)) {
            return $response;
        }

        $code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);
        if ($code < 200 || $code >= 300) {
            return new WP_Error('github_delete_failed', $body['message'] ?? 'GitHub delete failed.');
        }
        return $body;
    }

    private function build_jsdelivr_url($settings, $path) {
        return sprintf(
            'https://cdn.jsdelivr.net/gh/%s/%s@%s/%s',
            rawurlencode($settings['github_owner']),
            rawurlencode($settings['github_repo']),
            rawurlencode($settings['github_branch']),
            str_replace('%2F', '/', rawurlencode($path))
        );
    }

    public function handle_public_routes() {
        if (isset($_GET['digjy_vault_view'])) {
            $this->serve_file(absint($_GET['digjy_vault_view']), false);
        }
        if (isset($_GET['digjy_vault_download'])) {
            $this->serve_file(absint($_GET['digjy_vault_download']), true);
        }
    }

    private function serve_file($file_id, $force_download = false) {
        if (!$file_id) {
            return;
        }

        global $wpdb;
        $table = $wpdb->prefix . self::TABLE;
        $record = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", $file_id));
        if (!$record) {
            wp_die('File not found.', 'File not found', ['response' => 404]);
        }

        if (!is_user_logged_in() || ((int) $record->user_id !== (int) get_current_user_id() && !current_user_can('manage_options'))) {
            wp_die('You do not have permission to access this file.', 'Forbidden', ['response' => 403]);
        }

        if ($force_download) {
            $response = wp_remote_get($record->jsdelivr_url, ['timeout' => 60, 'stream' => false]);
            if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) {
                wp_die('Could not download file.', 'Download error', ['response' => 502]);
            }
            header('Content-Type: ' . $record->mime_type);
            header('Content-Disposition: attachment; filename="' . rawurlencode($record->original_name) . '"');
            echo wp_remote_retrieve_body($response);
            exit;
        }

        wp_redirect($record->jsdelivr_url);
        exit;
    }
}

new Digjy_File_Vault();
